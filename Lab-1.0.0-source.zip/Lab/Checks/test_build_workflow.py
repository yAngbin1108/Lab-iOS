#!/usr/bin/env python3
"""
测试约定：Checks/ 下的每个 test_*.py 都必须在 .github/workflows/build.yml
里被真正调用（`run: python3 Checks/xxx.py`），避免出现写了测试却从不执行的情况。

同时反向检查：workflow 里引用的 Tests 脚本必须真实存在。
"""

import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORKFLOW = os.path.join(ROOT, ".github", "workflows", "build.yml")
TESTS_DIR = os.path.join(ROOT, "Checks")

errors = []


def main():
    if not os.path.exists(WORKFLOW):
        print("❌ 找不到 .github/workflows/build.yml")
        return 1

    with open(WORKFLOW, encoding="utf-8") as f:
        workflow = f.read()

    # workflow 里被调用的测试脚本
    invoked = set(re.findall(r"python3\s+(Checks/[A-Za-z0-9_./-]+\.py)", workflow))

    # 磁盘上的测试脚本
    on_disk = set()
    if os.path.isdir(TESTS_DIR):
        for name in sorted(os.listdir(TESTS_DIR)):
            if name.startswith("test_") and name.endswith(".py"):
                on_disk.add(f"Checks/{name}")

    for path in sorted(on_disk):
        if path not in invoked:
            errors.append(f"{path} 存在于仓库中，但 build.yml 从未调用它")

    for path in sorted(invoked):
        if not os.path.exists(os.path.join(ROOT, path)):
            errors.append(f"build.yml 调用了不存在的脚本 {path}")

    # validate_structure.py 不是 test_ 前缀，但也应该被调用
    if "Checks/validate_structure.py" not in invoked:
        errors.append("build.yml 未调用 Checks/validate_structure.py")

    print(f"workflow 调用测试脚本：{len(invoked)} 个")
    for p in sorted(invoked):
        print(f"   - {p}")
    print(f"仓库中 test_*.py：{len(on_disk)} 个")

    if errors:
        print()
        print(f"❌ 发现 {len(errors)} 个问题：")
        for e in errors:
            print("   -", e)
        return 1

    print()
    print("✅ Workflow 与测试脚本完全对应")
    return 0


if __name__ == "__main__":
    sys.exit(main())
