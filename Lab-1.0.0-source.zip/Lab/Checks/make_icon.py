#!/usr/bin/env python3
"""
从一张源图生成 Lab 的 App Icon 全套变体。

用法：
    python3 Checks/make_icon.py <源图路径>

会写入：
    Lab/other/media.xcassets/AppIcon.appiconset/square.png           （主图标）
    Lab/other/media.xcassets/AppIcon.appiconset/square-dark 1.png    （深色外观）
    Lab/other/media.xcassets/AppIcon.appiconset/out.png              （着色外观）
    Lab.png                                                          （仓库展示图）
    Lab/assets/Lab.png                                               （同上的副本）

为什么需要这个脚本：
    Contents.json 引用的是**固定文件名**。如果只手工替换 square.png，
    深色模式与「着色」外观下仍会露出旧图标。三个变体必须一起更新。

    另外 iOS 的 App Icon 要求：
      · 1024×1024 正方形
      · 不含 alpha 通道（否则上传会被拒）
      · PNG 格式
    本脚本用 ffmpeg 强制 rgb24 像素格式来保证无透明通道，
    并在最后校验尺寸、alpha 与 Contents.json 的一致性。

    以后换 logo 只需要重跑这一条命令，不用手工处理三种外观。
"""

import json
import os
import shutil
import struct
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ICONSET = os.path.join(ROOT, "Lab", "other", "media.xcassets", "AppIcon.appiconset")

# (输出文件, ffmpeg 滤镜) —— 三种外观各自的处理方式
VARIANTS = [
    ("square.png",         "scale=1024:1024:flags=lanczos"),
    # 深色外观：整体压暗一档，保留层次
    ("square-dark 1.png",  "scale=1024:1024:flags=lanczos,"
                           "curves=all='0/0 0.5/0.42 1/0.9'"),
    # 着色外观：按系统灰度权重去饱和
    ("out.png",            "scale=1024:1024:flags=lanczos,"
                           "colorchannelmixer="
                           "rr=0.45:rg=0.30:rb=0.25:"
                           "gr=0.45:gg=0.30:gb=0.25:"
                           "br=0.45:bg=0.30:bb=0.25"),
]


def die(msg):
    print(f"❌ {msg}")
    sys.exit(1)


def png_size(path):
    with open(path, "rb") as f:
        head = f.read(24)
    if head[:8] != b"\x89PNG\r\n\x1a\n":
        return None
    return struct.unpack(">II", head[16:24])


def has_alpha(path):
    """检查 PNG 是否带 alpha 通道（颜色类型 4 或 6）"""
    with open(path, "rb") as f:
        f.seek(25)
        color_type = ord(f.read(1))
    return color_type in (4, 6)


def render(src, name, filters):
    out = os.path.join(ICONSET, name)
    cmd = [
        "ffmpeg", "-v", "error", "-y",
        "-i", src,
        "-vf", filters,
        "-pix_fmt", "rgb24",   # 强制无 alpha
        out,
    ]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        die(f"生成 {name} 失败：{r.stderr.strip()}")
    return out


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        die("缺少参数：源图路径")

    src = os.path.abspath(sys.argv[1])
    if not os.path.exists(src):
        die(f"源图不存在：{src}")
    if not shutil.which("ffmpeg"):
        die("未找到 ffmpeg。macOS 可执行：brew install ffmpeg")
    if not os.path.isdir(ICONSET):
        die(f"图标目录不存在：{ICONSET}")

    print(f"源图：{src}\n")
    print("【生成 App Icon 变体】")

    for name, filters in VARIANTS:
        out = render(src, name, filters)
        size = png_size(out)
        if size != (1024, 1024):
            die(f"{name} 尺寸异常：{size}（应为 (1024, 1024)）")
        if has_alpha(out):
            die(f"{name} 含 alpha 通道，iOS 会拒绝")
        kb = os.path.getsize(out) // 1024
        print(f"  ✅ {name:22} 1024x1024  {kb} KB  无 alpha")

    print("\n【仓库展示图】")
    hero = os.path.join(ROOT, "Lab.png")
    r = subprocess.run(
        ["ffmpeg", "-v", "error", "-y", "-i", src,
         "-vf", "scale=512:512:flags=lanczos", "-pix_fmt", "rgb24", hero],
        capture_output=True, text=True
    )
    if r.returncode != 0:
        die(f"生成 Lab.png 失败：{r.stderr.strip()}")
    print(f"  ✅ Lab.png  512x512  {os.path.getsize(hero) // 1024} KB")

    assets_dir = os.path.join(ROOT, "Lab", "assets")
    if os.path.isdir(assets_dir):
        shutil.copy2(hero, os.path.join(assets_dir, "Lab.png"))
        print("  ✅ Lab/assets/Lab.png 已同步")

    print("\n【Contents.json 一致性】")
    with open(os.path.join(ICONSET, "Contents.json"), encoding="utf-8") as f:
        cfg = json.load(f)

    actual = {n for n in os.listdir(ICONSET) if n.endswith(".png")}
    ok = True
    for img in cfg["images"]:
        fn = img.get("filename")
        present = fn in actual
        print(f"  {'✅' if present else '❌'} {fn}")
        if not present:
            ok = False

    if not ok:
        die("Contents.json 引用了不存在的文件，Xcode 构建会失败")

    print("\n全部完成。记得把新图标提交进仓库。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
