#!/usr/bin/env python3
"""
上传前自检 —— 用来确认你传到 GitHub 的文件是完整的。

用法（在仓库根目录下跑）：
    python3 Checks/preflight.py

为什么需要这个：
    GitHub 网页分批上传时，漏掉一两个文件很常见，尤其是：
      · Lab.xcodeproj/xcshareddata/xcschemes/Lab.xcscheme（漏了必失败）
      · .github/workflows/build.yml（漏了不会触发编译）
      · Lab/Info.plist（漏了编译失败）

    与其等 10 分钟让 CI 报错，不如上传后在本地/网页上先跑一遍这个。

    没有 Python 环境也行 —— 直接照着下面的清单在网页上数一遍即可。
"""

import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# 必须存在的关键文件。缺任何一个都会导致构建失败。
CRITICAL = [
    ("Lab.xcodeproj/project.pbxproj", "工程文件本体"),
    ("Lab.xcodeproj/xcshareddata/xcschemes/Lab.xcscheme",
     "共享 scheme，缺了 xcodebuild -scheme 直接失败"),
    ("Lab/Info.plist", "应用配置文件"),
    ("Lab/Lab-Bridging-Header.h", "Swift ↔ ObjC 桥接头，缺了内核代码全部找不到"),
    ("Lab/Lab.swift", "程序入口，含 @main"),
    ("Config/Lab.entitlements", "私有权限声明，缺了 ldid 注入会失败"),
    ("Lab/kexploit/darksword.m", "内核漏洞利用主体"),
    ("Lab/Analyzer/Core/LabAppModel.swift", "分析模块全局状态"),
    ("LICENSE", "AGPL 许可证，分发必须保留"),
]

# 「最好存在」的文件。
# 为什么和 CRITICAL 分开：如果你走的是「只传 zip」的流程，
# workflow 文件是单独上传到仓库根目录的，**本来就不在 zip 里**。
# 把它算成致命错误会让自检误报，反而掩盖真正的问题。
RECOMMENDED = [
    (".github/workflows/build.yml",
     "Actions 配置。走「只传 zip」流程时它单独放在仓库根目录，不在源码包里"),
    (".github/workflows/build-from-zip.yml",
     "从压缩包编译用的 workflow，同上"),
]

# 目录 -> 期望的文件数。数量对不上说明传漏了。
EXPECTED_COUNTS = {
    "Lab": 166,
    "Lab.xcodeproj": 4,
    "Checks": 4,
    "Config": 1,
    "scripts": 1,
    ".github": 4,
}

# 关键子目录也必须存在
CRITICAL_DIRS = [
    "Lab/kexploit/TaskRop",
    "Lab/kexploit/pe",
    "Lab/Analyzer/Core",
    "Lab/Analyzer/Modules",
    "Lab/views/fm",
    "Lab/views/app",
    "Lab/lib/choma",
]

errors = []
warnings = []


def main():
    print("Lab 上传前自检")
    print("=" * 52)
    print(f"检查目录：{ROOT}")
    print()

    # 1. 关键文件
    print("【关键文件】")
    for rel, why in CRITICAL:
        path = os.path.join(ROOT, rel)
        ok = os.path.exists(path)
        print(f"  {'✅' if ok else '❌'} {rel}")
        if not ok:
            errors.append(f"缺少 {rel} —— {why}")
    print()

    # 1b. 推荐文件（不致命）
    if os.path.exists(os.path.join(ROOT, ".github")):
        print("【Workflow 文件】")
        for rel, why in RECOMMENDED:
            path = os.path.join(ROOT, rel)
            ok = os.path.exists(path)
            if ok:
                print(f"  ✅ {rel}")
        if not any(os.path.exists(os.path.join(ROOT, r)) for r, _ in RECOMMENDED):
            print("  ℹ️  仓库里没有 workflow 文件")
            print("      如果你是从压缩包编译（build-from-zip.yml 在仓库根目录跑），")
            print("      这是正常的 —— workflow 不在源码包里。")
        print()

    # 2. 关键目录
    print("【关键目录】")
    for rel in CRITICAL_DIRS:
        path = os.path.join(ROOT, rel)
        ok = os.path.isdir(path)
        print(f"  {'✅' if ok else '❌'} {rel}/")
        if not ok:
            errors.append(f"缺少目录 {rel}/")
    print()

    # 3. 文件数量
    print("【文件数量】")
    for rel, expected in EXPECTED_COUNTS.items():
        path = os.path.join(ROOT, rel)
        if not os.path.isdir(path):
            print(f"  ❌ {rel}/ 不存在")
            errors.append(f"{rel}/ 不存在")
            continue

        actual = 0
        for _, _, files in os.walk(path):
            actual += len(files)

        match = actual == expected
        symbol = "✅" if match else "⚠️"
        print(f"  {symbol} {rel}/ 实际 {actual} 个，预期 {expected} 个")
        if not match:
            warnings.append(
                f"{rel}/ 文件数不符（{actual} vs {expected}）—— "
                f"少了说明传漏，多了说明误传了构建产物"
            )
    print()

    # 4. scheme 里的 UUID 是否和 pbxproj 对得上
    print("【工程内部引用】")
    scheme = os.path.join(ROOT, "Lab.xcodeproj", "xcshareddata", "xcschemes", "Lab.xcscheme")
    pbx = os.path.join(ROOT, "Lab.xcodeproj", "project.pbxproj")
    if os.path.exists(scheme) and os.path.exists(pbx):
        with open(scheme, encoding="utf-8") as f:
            scheme_text = f.read()
        with open(pbx, encoding="utf-8") as f:
            pbx_text = f.read()

        import re
        ids = set(re.findall(r'BlueprintIdentifier = "([0-9A-F]{24})"', scheme_text))
        ok = True
        for i in ids:
            found = i in pbx_text
            print(f"  {'✅' if found else '❌'} scheme 引用的 target {i}")
            if not found:
                errors.append(f"scheme 引用的 target {i} 在 project.pbxproj 中不存在")
                ok = False
        if ok and not ids:
            warnings.append("scheme 里没有找到 BlueprintIdentifier")
    print()

    # 5. 常见误传检查
    print("【误传检查】")
    junk = []
    for base, dirs, files in os.walk(ROOT):
        for d in list(dirs):
            if d in ("build", "DerivedData", "__pycache__"):
                junk.append(os.path.relpath(os.path.join(base, d), ROOT))
        for f in files:
            if f.endswith((".ipa", ".pyc", ".xcuserstate")):
                junk.append(os.path.relpath(os.path.join(base, f), ROOT))

    if junk:
        print(f"  ⚠️  发现 {len(junk)} 个不该上传的构建产物/缓存：")
        for j in junk[:10]:
            print(f"      {j}")
        warnings.append("仓库里有构建产物或缓存，建议删掉（会让仓库变大且每次 diff 很乱）")
    else:
        print("  ✅ 没有误传构建产物")
    print()

    # 结果
    print("=" * 52)
    if warnings:
        print(f"⚠️  警告 {len(warnings)} 条：")
        for w in warnings:
            print(f"   - {w}")
        print()

    if errors:
        print(f"❌ 有 {len(errors)} 个致命问题，先修好再触发编译：")
        for e in errors:
            print(f"   - {e}")
        return 1

    print("✅ 自检通过，可以触发 GitHub Actions 编译了")
    print()
    print("   提醒：编译完成后在 Actions 页面底部的 Artifacts 下载 Lab-ipa")
    return 0


if __name__ == "__main__":
    sys.exit(main())
