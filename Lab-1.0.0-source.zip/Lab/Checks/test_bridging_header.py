#!/usr/bin/env python3
"""
桥接头一致性检查。

这是合并后最容易出问题的地方：删掉一个 .m 实现但忘了删桥接头里的声明，
或者桥接头 import 了一个已经被删掉的头文件。

后者在编译期报错，错误信息很难定位；前者更糟 —— 编译能过，
要到链接期才炸，而且报错指向桥接头而不是真正的原因。

实测有效：本脚本在合并后抓到两条「有声明无实现」的函数
（LabClearIconCache、test），这两条如果留在桥接头里，
Actions 会在链接阶段失败。
"""

import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
APP_DIR = os.path.join(ROOT, "Lab")
BRIDGE = os.path.join(APP_DIR, "Lab-Bridging-Header.h")

# 只有声明、没有实现也合法的头文件（纯类型 / 宏 / 内联定义）
HEADER_ONLY_OK = {
    "IconServices.h",
    "privateapi.h",
    "compat.h",
    "exc.h",
    "pac.h",
    "thread.h",
    "vm.h",
    "xpaci.h",
    "offsets.h",
    "dyld_cache_format.h",
    "fixup-chains.h",
    "arm64.h",
    "MachOByteOrder.h",
    "sbx.h",
    "vnode.h",
    "vfs.h",
    "apfs.h",
    "rc.h",
}

# 这些函数由系统或运行时提供，不需要工程内有实现
EXTERNAL_FUNCS = set()

errors = []
warnings = []


def rel(p):
    return os.path.relpath(p, ROOT)


def find_all(name):
    found = []
    for base, _, files in os.walk(APP_DIR):
        if name in files:
            found.append(os.path.join(base, name))
    return found


def all_impl_sources():
    sources = []
    for base, _, files in os.walk(APP_DIR):
        for name in files:
            if name.endswith((".m", ".c", ".mm")):
                sources.append(os.path.join(base, name))
    return sources


def main():
    if not os.path.exists(BRIDGE):
        print("❌ 找不到 Lab-Bridging-Header.h")
        return 1

    with open(BRIDGE, encoding="utf-8") as f:
        header = f.read()

    imports = re.findall(r'#import\s+"([^"]+)"', header)
    print(f"桥接头 import 了 {len(imports)} 个头文件")
    print()

    for name in imports:
        hits = find_all(name)
        if not hits:
            errors.append(f"桥接头 import 的 {name} 在工程中不存在")
            continue

        base_name = name[:-2]
        impls = find_all(base_name + ".m") + find_all(base_name + ".c")
        if not impls and name not in HEADER_ONLY_OK:
            warnings.append(f"{name} 没有对应的 .m/.c 实现"
                            f"（若确为纯声明头请加入 HEADER_ONLY_OK）")

    # 桥接头声明的 C 函数必须有定义
    func_pattern = re.compile(
        r"^\s*(?:void|long|int|bool|BOOL|uint\w+_t|const char \s*\*)\s+"
        r"(\w+)\s*\([^)]*\)\s*;",
        re.MULTILINE,
    )
    funcs = func_pattern.findall(header)

    if funcs:
        print(f"桥接头声明了 {len(funcs)} 个 C 函数：")
        impl_sources = all_impl_sources()
        impl_text = []
        for path in impl_sources:
            try:
                with open(path, encoding="utf-8") as f:
                    impl_text.append(f.read())
            except (UnicodeDecodeError, OSError):
                continue
        blob = "\n".join(impl_text)

        for fn in funcs:
            if fn in EXTERNAL_FUNCS:
                print(f"  ⏭  {fn}（外部提供，跳过）")
                continue
            defined = re.search(r"\b" + re.escape(fn) + r"\s*\(", blob) is not None
            print(f"  {'✅' if defined else '❌'} {fn}")
            if not defined:
                errors.append(
                    f"桥接头声明的函数 {fn} 在任何 .m/.c 中都找不到定义，链接会失败"
                )
        print()

    if warnings:
        print(f"⚠️  警告 {len(warnings)} 条：")
        for w in warnings:
            print("   -", w)
        print()

    if errors:
        print(f"❌ 错误 {len(errors)} 条：")
        for e in errors:
            print("   -", e)
        return 1

    print("✅ 桥接头一致性检查通过")
    return 0


if __name__ == "__main__":
    sys.exit(main())
