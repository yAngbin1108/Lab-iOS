#!/usr/bin/env python3
"""
Lab 工程结构自检。

在没有 Xcode / iOS SDK 的环境里无法真正编译，这个脚本挡住能挡的部分：
  1. Swift 文件括号 / 引号配平，非法控制字节
  2. 跨文件**顶层**类型重名（invalid redeclaration）
  3. macOS 专属 API（iOS SDK 里不存在，误用直接编译失败）
  4. project.pbxproj 的构建设置是否有会直接导致失败的已知错误
  5. entitlements 是否可解析
"""

import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
APP_DIR = os.path.join(ROOT, "Lab")

FORBIDDEN_SYMBOLS = [
    ("SecTaskCreateFromSelf", "macOS Security 框架专属"),
    ("SecTaskCopyValueForEntitlement", "macOS Security 框架专属"),
    ("NSWorkspace", "macOS 专属"),
    ("NSSavePanel", "macOS 专属"),
    ("NSOpenPanel", "macOS 专属"),
    ("import AppKit", "macOS 专属框架"),
]

errors = []
warnings = []
stats = {}


def swift_files():
    for base, _, files in os.walk(APP_DIR):
        for name in sorted(files):
            if name.endswith(".swift"):
                yield os.path.join(base, name)


def rel(path):
    return os.path.relpath(path, ROOT)


def strip_comments_and_strings(source):
    """抹掉注释与字符串内容，返回可做括号配平的文本。"""
    out = []
    i = 0
    n = len(source)
    state = "code"
    block_depth = 0
    unterminated = False

    while i < n:
        ch = source[i]
        nxt = source[i + 1] if i + 1 < n else ""

        if state == "code":
            if ch == "/" and nxt == "/":
                state = "line_comment"; i += 2; continue
            if ch == "/" and nxt == "*":
                state = "block_comment"; block_depth = 1; i += 2; continue
            if ch == '"':
                if source[i:i + 3] == '"""':
                    state = "multiline_string"; out.append('"'); i += 3; continue
                state = "string"; out.append('"'); i += 1; continue
            out.append(ch); i += 1; continue

        if state == "line_comment":
            if ch == "\n":
                state = "code"; out.append("\n")
            i += 1; continue

        if state == "block_comment":
            if ch == "/" and nxt == "*":
                block_depth += 1; i += 2; continue
            if ch == "*" and nxt == "/":
                block_depth -= 1; i += 2
                if block_depth == 0:
                    state = "code"
                continue
            i += 1; continue

        if state == "string":
            if ch == "\\":
                i += 2; continue
            if ch == '"':
                state = "code"
            elif ch == "\n":
                unterminated = True; state = "code"
            i += 1; continue

        if state == "multiline_string":
            if source[i:i + 3] == '"""':
                backslashes = 0
                j = i - 1
                while j >= 0 and source[j] == "\\":
                    backslashes += 1; j -= 1
                if backslashes % 2 == 0:
                    state = "code"; i += 3; continue
            i += 1; continue

    if state == "string":
        unterminated = True
    return "".join(out), unterminated


def check_string_interpolation(path, source):
    """
    检查字符串插值 \\( ... ) 的括号是否配平。

    这是 validate_structure 原先的一个盲区：
    strip_comments_and_strings 会把字符串**内容**整体丢掉，
    所以字符串插值内部的不平衡它看不到。

    实测触发的真实 bug：
        lines.append("  相同：\\(result.identical.count}")
                                                   ^ 应该是 )
    这一个字符导致整个 Swift 文件编译失败，并且因为类型索引丢失，
    级联报出上百条 "missing import of defining module 'Combine'" 的噪音 ——
    真正的原因被淹没在噪音里，极难定位。

    规则：在插值里，括号必须配平，且不能出现未配对的 '}'。
    """
    i = 0
    n = len(source)
    line = 1

    while i < n:
        ch = source[i]

        if ch == "\n":
            line += 1
            i += 1
            continue

        # 注释直接跳过
        if ch == "/" and i + 1 < n:
            if source[i + 1] == "/":
                while i < n and source[i] != "\n":
                    i += 1
                continue
            if source[i + 1] == "*":
                i += 2
                depth = 1
                while i < n and depth > 0:
                    if source[i] == "\n":
                        line += 1
                    if source[i] == "/" and i + 1 < n and source[i + 1] == "*":
                        depth += 1
                        i += 2
                        continue
                    if source[i] == "*" and i + 1 < n and source[i + 1] == "/":
                        depth -= 1
                        i += 2
                        continue
                    i += 1
                continue

        # 多行字符串：跳过（内部的 \(...) 也做检查更稳妥，但先保证不误伤）
        if source[i:i + 3] == '"""':
            i += 3
            while i < n and source[i:i + 3] != '"""':
                if source[i] == "\n":
                    line += 1
                i += 1
            i += 3
            continue

        # 单行字符串
        if ch == '"':
            start_line = line
            i += 1
            while i < n and source[i] != '"':
                # 转义序列
                if source[i] == "\\":
                    # 字符串插值 \(
                    if i + 1 < n and source[i + 1] == "(":
                        interp_line = line
                        i += 2
                        depth = 1
                        while i < n and depth > 0:
                            cur = source[i]
                            if cur == "\n":
                                line += 1
                            elif cur == "(":
                                depth += 1
                            elif cur == ")":
                                depth -= 1
                                if depth == 0:
                                    i += 1
                                    break
                            elif cur == "}":
                                # 在插值里遇到未配对的 } → 几乎肯定是把 ) 写成了 }
                                errors.append(
                                    f"{rel(path)}:{interp_line}: 字符串插值 "
                                    f"\\(...) 未闭合，遇到 '}}' —— "
                                    f"很可能把 ')' 误写成 '}}'"
                                )
                                return
                            elif cur == "\\" and i + 1 < n:
                                i += 2
                                continue
                            i += 1
                        continue
                    i += 2
                    continue
                if source[i] == "\n":
                    line += 1
                i += 1
            i += 1
            continue

        i += 1


def check_view_body_collision():
    """
    View 里不能有名为 `body` 的存储属性。

    实测触发的真实 bug：
        struct LabNoticeCard: View {
            let title: String
            let body: String      // ← 与 SwiftUI 的 var body: some View 冲突
    报错：invalid redeclaration of 'body'

    这类错误编译器会直接指出，但发现得晚（要等 CI 跑几分钟）。
    这里提前拦下。
    """
    pattern = re.compile(
        r"(?:struct|class)\s+(\w+)\s*:\s*[^{]*\bView\b[^{]*\{",
        re.DOTALL,
    )
    # 找出所有 body 声明，再逐个判断类型。
    # 不能用 (?!some\s+View) 这种负向断言 —— 正则会回溯，
    # 让后面的 [^\n{=]+ 跳过 \"some\" 继续匹配，断言形同虚设（实测踩过）。
    prop = re.compile(r"^[ \t]+(?:let|var)\s+body\s*:\s*([^\n]+)", re.MULTILINE)

    for path in swift_files():
        with open(path, encoding="utf-8") as f:
            source = f.read()
        stripped, _ = strip_comments_and_strings(source)

        for m in pattern.finditer(stripped):
            # 取这个类型的大括号范围
            start = m.end() - 1
            depth = 0
            i = start
            while i < len(stripped):
                if stripped[i] == "{":
                    depth += 1
                elif stripped[i] == "}":
                    depth -= 1
                    if depth == 0:
                        break
                i += 1
            body_text = stripped[start:i]

            for pm in prop.finditer(body_text):
                declared_type = pm.group(1).strip()

                # `some View` 是 View 协议要求的正常写法，跳过。
                # 只有**其它类型**的 body 才冲突。
                if declared_type.startswith("some View"):
                    continue
                # 计算属性里的 body 通常还会带 { 或 = 结束，一并排除
                if declared_type.startswith("{"):
                    continue

                line = stripped[:start + pm.start()].count("\n") + 1
                errors.append(
                    f"{rel(path)}:{line}: 声明了 'body: {declared_type}'，"
                    f"会和 SwiftUI 的 `var body: some View` 冲突"
                    f"（invalid redeclaration of 'body'），请改名"
                )


def check_ios26_api_usage():
    """
    检测 iOS 26 SDK 专属 API 的使用。

    这些 API 本身没问题（源码里有 #available 保护），但要求构建环境
    必须带 iOS 26 SDK。这个检查的作用是**提醒**，不是报错 ——
    真正的拦截在 workflow 的 Xcode 选择步骤里。
    """
    ios26_apis = [
        ("glassEffect", "iOS 26 的液态玻璃效果"),
        ("GlassEffectContainer", "iOS 26 液态玻璃容器"),
    ]
    hits = []
    for path in swift_files():
        with open(path, encoding="utf-8") as f:
            source = f.read()
        for api, desc in ios26_apis:
            if api in source:
                hits.append((rel(path), api, desc))

    if hits:
        print(f"ℹ️  检测到 iOS 26 专属 API（需要 iOS 26 SDK 构建）：")
        for path, api, desc in hits:
            print(f"     {path} → {api}（{desc}）")
        print()


def check_combine_import():
    """
    声明了 ObservableObject / @Published 的文件必须显式 `import Combine`。

    为什么不能只靠 `import SwiftUI`：
    实测踩过的坑 —— 4 个 ViewModel 只 import 了 SwiftUI，
    在 CI 上编译报：
        type 'XxxViewModel' does not conform to protocol 'ObservableObject'
        initializer 'init(wrappedValue:)' is not available due to missing
        import of defining module 'Combine'
    并且因为类型索引丢失，级联出 273 条同名噪音错误。
    而同项目里显式 import Combine 的文件（DiagnosticsManager、LabAppModel）
    完全正常 —— 所以这不是「SwiftUI 一定会转发」能保证的。

    显式导入是零成本的，加上就永远不会踩这个坑。
    """
    needs_combine = re.compile(r"\b(?:ObservableObject|@Published|@ObservedObject|@StateObject)\b")

    for path in swift_files():
        with open(path, encoding="utf-8") as f:
            source = f.read()
        stripped, _ = strip_comments_and_strings(source)

        if not needs_combine.search(stripped):
            continue
        if re.search(r"^import\s+Combine\b", source, re.MULTILINE):
            continue

        # 找到第一个用到 Combine 的行号
        m = needs_combine.search(stripped)
        line = stripped[:m.start()].count("\n") + 1
        errors.append(
            f"{rel(path)}:{line}: 使用了 ObservableObject/@Published 但没有 "
            f"显式 `import Combine`，编译期会报 missing import of defining module 'Combine'"
        )


def check_balance(path, source):
    stripped, unterminated = strip_comments_and_strings(source)
    if unterminated:
        errors.append(f"{rel(path)}: 存在未闭合的字符串字面量")

    pairs = {"(": ")", "[": "]", "{": "}"}
    closing = {v: k for k, v in pairs.items()}
    stack = []
    line = 1
    for ch in stripped:
        if ch == "\n":
            line += 1
        elif ch in pairs:
            stack.append((ch, line))
        elif ch in closing:
            if not stack:
                errors.append(f"{rel(path)}:{line}: 多余的 '{ch}'")
                return
            opener, oline = stack.pop()
            if pairs[opener] != ch:
                errors.append(f"{rel(path)}:{line}: '{ch}' 与第 {oline} 行的 '{opener}' 不匹配")
                return
    if stack:
        opener, oline = stack[-1]
        errors.append(f"{rel(path)}: 第 {oline} 行的 '{opener}' 未闭合")


def check_control_bytes(path, raw):
    for i, byte in enumerate(raw):
        if byte < 0x09 or 0x0B <= byte <= 0x0C or 0x0E <= byte <= 0x1F:
            line = raw[:i].count(b"\n") + 1
            errors.append(f"{rel(path)}:{line}: 非法控制字节 0x{byte:02X}")
            return


def check_forbidden(path, source):
    stripped, _ = strip_comments_and_strings(source)
    for symbol, reason in FORBIDDEN_SYMBOLS:
        for m in re.finditer(re.escape(symbol), stripped):
            line = stripped[:m.start()].count("\n") + 1
            errors.append(f"{rel(path)}:{line}: 使用了 {symbol}（{reason}），iOS 上编译失败")


def check_duplicate_types():
    """
    检测**顶层**类型重名。

    难点：Swift 里嵌套类型也匹配同样的正则，靠缩进判断不可靠
    （文件可能整体有额外缩进）。这里用大括号深度追踪：
    只有在大括号深度为 0 时出现的类型声明才算顶层。

    实测有效：LabMgr.swift 内嵌的 `struct AppInfo`（缩进 4 空格）
    在修复前被误报为与 PartyUI 的 `enum AppInfo` 冲突。
    """
    pattern = re.compile(
        r"(?:public\s+|internal\s+|private\s+|fileprivate\s+)?(?:final\s+)?"
        r"(struct|class|enum|actor|protocol)\s+([A-Za-z_]\w*)"
    )
    seen = {}
    for path in swift_files():
        with open(path, encoding="utf-8") as f:
            source = f.read()
        stripped, _ = strip_comments_and_strings(source)

        depth = 0
        depths = []
        for ch in stripped:
            depths.append(depth)
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth = max(0, depth - 1)

        for m in pattern.finditer(stripped):
            if depths[m.start()] != 0:
                continue  # 嵌套类型
            kind, name = m.group(1), m.group(2)
            line = stripped[:m.start()].count("\n") + 1
            if name in seen:
                pk, pp, pl = seen[name]
                errors.append(
                    f"{rel(path)}:{line}: 顶层类型 '{name}' 重复声明"
                    f"（已在 {rel(pp)}:{pl} 声明为 {pk}）"
                )
            else:
                seen[name] = (kind, path, line)
    return len(seen)


def check_pbxproj():
    proj = os.path.join(ROOT, "Lab.xcodeproj", "project.pbxproj")
    if not os.path.exists(proj):
        errors.append("缺少 Lab.xcodeproj/project.pbxproj")
        return

    with open(proj, encoding="utf-8") as f:
        content = f.read()

    for token in ["rootObject", "PBXProject", "PBXNativeTarget"]:
        if token not in content:
            errors.append(f"project.pbxproj 缺少 {token}")

    if content.count("{") != content.count("}"):
        errors.append(f"project.pbxproj 大括号不配平 "
                      f"({content.count('{')} vs {content.count('}')})")
    if content.count("(") != content.count(")"):
        errors.append(f"project.pbxproj 小括号不配平 "
                      f"({content.count('(')} vs {content.count(')')})")

    # 已知历史 bug：CURRENT_PROJECT_VERSION 被写成 "Release"
    for m in re.finditer(r"CURRENT_PROJECT_VERSION = ([^;]+);", content):
        value = m.group(1).strip()
        if not value.isdigit():
            errors.append(f"CURRENT_PROJECT_VERSION 不是数字（值为 {value}），会构建失败")

    # 部署目标不该是未来版本
    for m in re.finditer(r"IPHONEOS_DEPLOYMENT_TARGET = ([\d.]+);", content):
        major = int(float(m.group(1)))
        if major > 19:
            errors.append(f"IPHONEOS_DEPLOYMENT_TARGET = {m.group(1)} 疑似笔误，会构建失败")

    # 引用的路径必须存在
    for m in re.finditer(r"path = ([^;]+); sourceTree = (?:<group>|SOURCE_ROOT);", content):
        p = m.group(1).strip().strip('"')
        if p.startswith("$") or p.endswith(".app"):
            continue
        if "/" not in p:
            continue
        candidates = [os.path.join(ROOT, p), os.path.join(APP_DIR, p)]
        if not any(os.path.exists(c) for c in candidates):
            warnings.append(f"pbxproj 引用的路径不存在：{p}")

    scheme = os.path.join(ROOT, "Lab.xcodeproj", "xcshareddata", "xcschemes", "Lab.xcscheme")
    if not os.path.exists(scheme):
        errors.append("没有共享 scheme Lab.xcscheme，CI 里 xcodebuild -scheme 会失败")


def check_entitlements():
    ent = os.path.join(ROOT, "Config", "Lab.entitlements")
    if not os.path.exists(ent):
        errors.append("缺少 Config/Lab.entitlements")
        return
    with open(ent, encoding="utf-8") as f:
        content = f.read()
    if content.count("<dict>") != content.count("</dict>"):
        errors.append("entitlements 的 <dict> 不配平")
    if content.count("<array>") != content.count("</array>"):
        errors.append("entitlements 的 <array> 不配平")
    if "platform-application" not in content:
        warnings.append("entitlements 缺少 platform-application，伪签名后仍可能被沙盒拦截")


def main():
    if not os.path.isdir(APP_DIR):
        errors.append("缺少 Lab/ 源码目录")
        return report()

    files = list(swift_files())
    if not files:
        errors.append("没有找到任何 .swift 源文件")
        return report()

    for path in files:
        with open(path, "rb") as f:
            raw = f.read()
        check_control_bytes(path, raw)
        with open(path, encoding="utf-8") as f:
            source = f.read()
        check_balance(path, source)
        check_string_interpolation(path, source)
        check_forbidden(path, source)
        stats[rel(path)] = {"lines": source.count("\n") + 1}

    stats["_types"] = check_duplicate_types()
    check_view_body_collision()
    check_combine_import()
    check_ios26_api_usage()
    check_pbxproj()
    check_entitlements()
    return report()


def report():
    file_count = len([k for k in stats if k != "_types"])
    total_lines = sum(s["lines"] for k, s in stats.items() if k != "_types")
    print(f"扫描 Swift 文件：{file_count} 个，共 {total_lines} 行")
    if "_types" in stats:
        print(f"顶层类型：{stats['_types']} 个")
    print()

    if warnings:
        print(f"⚠️  警告 {len(warnings)} 条：")
        for w in warnings:
            print("   -", w)
        print()

    if errors:
        print(f"❌ 错误 {len(errors)} 条：")
        for e in errors:
            print("   -", e)
        return 1

    print("✅ 结构自检通过")
    return 0


if __name__ == "__main__":
    sys.exit(main())
