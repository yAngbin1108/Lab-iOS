#!/bin/bash
# ---------------------------------------------------------------------------
# 本地编译脚本 —— 产出给 ESign / AltStore 自签的未签名 IPA
#
# 用法：
#   ./scripts/build_ipa.sh              # Release
#   ./scripts/build_ipa.sh --debug      # Debug
#
# 说明：
#   lara 的内核漏洞利用（DarkSword + sbx_escape）是运行时逃出沙盒、
#   挣取权限，**不依赖安装时预注入的私有 entitlements**。
#   所以打包时剥掉所有签名，产出一个干净未签名 IPA，
#   交给 ESign / AltStore 用你的 Apple ID 重新签名后安装。
# ---------------------------------------------------------------------------
set -euo pipefail

CONFIGURATION="Release"

for arg in "$@"; do
  case "$arg" in
    --debug)    CONFIGURATION="Debug" ;;
    --release)  CONFIGURATION="Release" ;;
    *) echo "未知参数: $arg"; exit 1 ;;
  esac
done

APP="Lab"

echo "[*] $APP 构建脚本 —— 配置 $CONFIGURATION"
echo

rm -rf build/
mkdir -p build

echo "[*] 编译中…"
xcodebuild \
  -project "$APP.xcodeproj" \
  -scheme "$APP" \
  -configuration "$CONFIGURATION" \
  -sdk iphoneos \
  -destination 'generic/platform=iOS' \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY="" \
  archive \
  -archivePath "$PWD/build/$APP.xcarchive" \
  -derivedDataPath "$PWD/build/DerivedData"

APP_PATH="$PWD/build/$APP.xcarchive/Products/Applications/$APP.app"
if [ ! -d "$APP_PATH" ]; then
  echo "[!] 归档中未找到 $APP.app"
  find "$PWD/build" -maxdepth 4 -type d | head -40
  exit 1
fi

rm -rf "$PWD/build/Payload"
mkdir -p "$PWD/build/Payload"
cp -R "$APP_PATH" "$PWD/build/Payload/"

TARGET_APP="$PWD/build/Payload/$APP.app"
plutil -replace UIFileSharingEnabled -bool YES "$TARGET_APP/Info.plist" || true

echo "[*] 剥离签名…"
codesign --remove "$TARGET_APP" || true
rm -rf "$TARGET_APP/_CodeSignature"
rm -f "$TARGET_APP/embedded.mobileprovision"

echo "[*] 打包中…"
(cd "$PWD/build" && /usr/bin/zip -qry "$APP.ipa" Payload)

echo
echo "构建成功"
echo "IPA 位置：build/$APP.ipa（$(du -h "$PWD/build/$APP.ipa" | cut -f1)）"
echo
echo "这个 IPA 是未签名裸包。用 ESign / AltStore 以你的 Apple ID 重新签名后安装。"
exit 0