#!/bin/bash
# ---------------------------------------------------------------------------
# 本地编译脚本
#
# 用法：
#   ./scripts/build_ipa.sh              # Release + ldid 伪签名（TrollStore 用）
#   ./scripts/build_ipa.sh --debug      # Debug 构建
#   ./scripts/build_ipa.sh --no-ldid    # 不注入私有 entitlements
#
# 需要：Xcode 16+、ldid（brew install ldid）
# ---------------------------------------------------------------------------
set -euo pipefail

CONFIGURATION="Release"
USE_LDID=1

for arg in "$@"; do
  case "$arg" in
    --debug)    CONFIGURATION="Debug" ;;
    --release)  CONFIGURATION="Release" ;;
    --no-ldid)  USE_LDID=0 ;;
    *) echo "未知参数: $arg"; exit 1 ;;
  esac
done

APP="Lab"
ENTITLEMENTS="Config/Lab.entitlements"

echo "[*] $APP 构建脚本 —— 配置 $CONFIGURATION，ldid 注入 $USE_LDID"
echo

rm -rf build/
mkdir -p build

echo "[*] 编译中…"
xcodebuild \
  -project "$APP.xcodeproj" \
  -scheme "$APP" \
  -configuration "$CONFIGURATION" \
  -sdk iphoneos \
  -destination 'generic/platform=iOS' \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY="" \
  CODE_SIGN_ENTITLEMENTS="$ENTITLEMENTS" \
  archive \
  -archivePath "$PWD/build/$APP.xcarchive" \
  -derivedDataPath "$PWD/build/DerivedData"

APP_PATH="$PWD/build/$APP.xcarchive/Products/Applications/$APP.app"
if [ ! -d "$APP_PATH" ]; then
  echo "[!] 归档中未找到 $APP.app"
  find "$PWD/build" -maxdepth 4 -type d | head -40
  exit 1
fi

rm -rf "$PWD/build/Payload"
mkdir -p "$PWD/build/Payload"
cp -R "$APP_PATH" "$PWD/build/Payload/"

plutil -replace UIFileSharingEnabled -bool YES \
  "$PWD/build/Payload/$APP.app/Info.plist" || true

BIN="$PWD/build/Payload/$APP.app/$APP"

if [ "$USE_LDID" = "1" ]; then
  if ! command -v ldid >/dev/null 2>&1; then
    echo "[!] 未安装 ldid。请执行：brew install ldid" >&2
    echo "    或加 --no-ldid 跳过注入（但内核功能将不可用）" >&2
    exit 1
  fi

  echo "[*] 注入私有 entitlements…"
  ldid -S"$ENTITLEMENTS" "$BIN"
  ldid -e "$BIN" | head -20

  echo
  echo "======================================================================"
  echo " 产物带私有 entitlements，只能用 TrollStore 类安装器安装。"
  echo " 用普通开发者证书重签会剥离这些权限，内核功能将不可用。"
  echo "======================================================================"
else
  echo "[*] 已跳过 ldid 注入 —— 内核功能将不可用（应用会自动检测）"
fi

echo
echo "[*] 打包中…"
(cd "$PWD/build" && /usr/bin/zip -qry "$APP.ipa" Payload)

echo
echo "构建成功"
echo "IPA 位置：build/$APP.ipa（$(du -h "$PWD/build/$APP.ipa" | cut -f1)）"
exit 0
