//
//  Lab.swift
//  Lab
//
//  合并后的应用入口。
//
//  标签页构成（来自两条设计线）：
//    · 内核工具（源自 lara，DarkSword 半越狱）—— 内容 / 文件 / 日志
//    · 分析工具（本工程新增）—— 差异分析 / 本地化 / 应用分析 / 运行监控 / 能力检测
//
//  注意：本应用同时包含内核漏洞利用代码，属于**越狱工具**而非纯分析工具。
//  使用前请阅读 README「风险」一节。
//

import SwiftUI
import UniformTypeIdentifiers

enum taboptions {
    case applying, files, logs
    case toolbox
    case icons
}

let g_isunsupported: Bool = isunsupported()
var weonadebugbuild_pjbweouttahereexclamationmark: Bool = false

@main
struct Lab: App {
    @StateObject private var mgr = LabMgr.shared
    @Environment(\.scenePhase) var scenephase
    @AppStorage("selectedMethod") private var selectedMethod: method = .hybrid
    @AppStorage("keepAlive") private var keepalive: Bool = false
    @AppStorage("showFMInTabs") private var showfmintabs: Bool = true
    @AppStorage("logsdisplaymode") private var logsdisplaymode: logsdisplaymode = .toolbar
    @State private var selectedtab: taboptions = .applying

    init() {
        #if DEBUG
        weonadebugbuild_pjbweouttahereexclamationmark = true
        #endif

        // 修复文档选择器在部分签名方式下的回调断裂问题
        let fixMethod = class_getInstanceMethod(
            UIDocumentPickerViewController.self,
            #selector(UIDocumentPickerViewController.fix_init(forOpeningContentTypes:asCopy:))
        )!
        let origMethod = class_getInstanceMethod(
            UIDocumentPickerViewController.self,
            #selector(UIDocumentPickerViewController.init(forOpeningContentTypes:asCopy:))
        )!
        method_exchangeImplementations(origMethod, fixMethod)

        if keepalive {
            toggleka()
        }

        globallogger.capture()
    }

    var body: some Scene {
        WindowGroup {
            TabView(selection: $selectedtab) {
                // ===== 内核工具 =====
                ContentView()
                    .tabItem {
                        Label("内核", systemImage: "wrench.and.screwdriver.fill")
                    }
                    .tag(taboptions.applying)

                if showfmintabs {
                    SantanderView(startPath: "/")
                        .tabItem {
                            Label("文件", systemImage: "folder.fill")
                        }
                        .tag(taboptions.files)
                }

                if logsdisplaymode == .tabs {
                    LogsView(logger: globallogger)
                        .tabItem {
                            Label("日志", systemImage: "terminal")
                        }
                        .tag(taboptions.logs)
                }

                // ===== 分析工具 =====
                // 五个分析模块收进「工具箱」一页。
                // 原因：TabView 超过 5 个标签会被系统折叠成 More 列表，
                // 而之前 .tabItem 只给了图标没给文字，导致 More 页只有图标没有标题。
                ToolboxView()
                    .environmentObject(LabAppModel.shared)
                    .tabItem {
                        Label("工具箱", systemImage: "square.grid.2x2")
                    }
                    .tag(taboptions.toolbox)

                // ===== 图标主题 =====
                // 移植自 lara 的 DarkBoard（源出 Cowabunga）。
                // 走「直接替换 App bundle 内图标文件」的路径，不注入 SpringBoard，
                // 所以不会影响桌面进程稳定性；代价是改动 App 签名，用完需还原。
                DarkBoardView()
                    .tabItem {
                        Label("图标", systemImage: "paintpalette.fill")
                    }
                    .tag(taboptions.icons)
            }
            .environmentObject(mgr)
            .overlay {
                if mgr.showrespring {
                    respringview()
                        .brightness(-1.0)
                        .ignoresSafeArea()
                }
            }
            .sheet(isPresented: Binding(
                get: { logsdisplaymode == .toolbar && mgr.showLogs },
                set: { mgr.showLogs = $0 }
            )) {
                LogsView(logger: globallogger)
            }
            .onAppear {
                // 内核能力状态由 CapabilitiesView 实时读取 LabMgr，
                // 不在这里拍快照（否则会出现「内核页显示成功、
                // 能力页显示不可用」的矛盾）。

                if !isunsupported() {
                    init_offsets()
                    offsets_init()
                    mgr.hasOffsets = emergencyfixfunctiontobereplacedlateronquestionmark()
                } else {
                    Alertinator.shared.alert(
                        title: "本设备不受支持",
                        body: "当前设备暂不支持 Lab 的内核功能。可能原因：\n"
                            + "- iOS 版本不在支持范围内（支持 iOS 16.0 - iOS 18.7.1）\n"
                            + "- 设备带有 MIE 保护（A19+ 或 M5+）\n"
                            + "- 当前有调试器附加\n\n"
                            + "分析类功能不受影响，仍可正常使用。",
                        actionLabel: "退出应用",
                        action: { exitinator() }
                    )
                }
            }
            .onChange(of: scenephase, perform: handleScenePhase)
        }
    }

    private func handleScenePhase(_ phase: ScenePhase) {
        switch phase {
        case .inactive, .background:
            handlebg()
        case .active:
            break
        @unknown default:
            break
        }
    }

    private func handlebg() {
        // RemoteCall 功能已移除，这里只做普通的后台保活
        guard keepalive else { return }

        var bgTask: UIBackgroundTaskIdentifier = .invalid
        bgTask = UIApplication.shared.beginBackgroundTask(withName: "LabKeepAlive") {
            self.endbgtask(&bgTask)
        }
    }

    private func endbgtask(_ task: inout UIBackgroundTaskIdentifier) {
        if task != .invalid {
            UIApplication.shared.endBackgroundTask(task)
            task = .invalid
        }
    }
}

// MARK: - 文档选择器修复

/// 交换 init 实现，让 asCopy 强制为 true。
///
/// 背景：iOS 17.5.x 的 UIDocumentPickerViewController 在 asCopy: false 时
/// 会返回一个安全作用域外的 URL，普通签名应用读它会被沙盒拒绝。
/// 强制 asCopy 让系统先把文件拷进沙盒，避免读不到内容。
extension UIDocumentPickerViewController {
    @objc func fix_init(
        forOpeningContentTypes contentTypes: [UTType],
        asCopy: Bool
    ) -> UIDocumentPickerViewController {
        return fix_init(forOpeningContentTypes: contentTypes, asCopy: true)
    }
}

// MARK: - 让字符串可以当错误抛出

/// LabMgr 里有多处 `throw "..."` 的写法，依赖这个扩展。
/// 如果删掉它，会报 "thrown expression type 'String' does not conform to 'Error'"。
extension String: @retroactive Error {}
