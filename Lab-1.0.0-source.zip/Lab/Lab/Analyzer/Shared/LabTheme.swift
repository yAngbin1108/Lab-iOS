//
//  LabTheme.swift
//  iOS Lab
//
//  统一的深色主题与卡片式视觉规范。
//

import SwiftUI

enum LabTheme {

    // MARK: - 颜色

    static let background = Color(red: 0.043, green: 0.047, blue: 0.059)
    static let card = Color(red: 0.086, green: 0.094, blue: 0.114)
    static let cardAlt = Color(red: 0.125, green: 0.137, blue: 0.165)
    static let stroke = Color.white.opacity(0.08)

    static let accent = Color(red: 0.361, green: 0.647, blue: 0.980)
    static let success = Color(red: 0.290, green: 0.808, blue: 0.510)
    static let warning = Color(red: 0.965, green: 0.706, blue: 0.278)
    static let danger = Color(red: 0.949, green: 0.400, blue: 0.400)

    static let primaryText = Color.white.opacity(0.94)
    static let secondaryText = Color.white.opacity(0.55)

    // MARK: - 尺寸

    static let cornerRadius: CGFloat = 16
    static let pagePadding: CGFloat = 16
    static let sectionSpacing: CGFloat = 18
}

// MARK: - 通用按钮样式

struct LabPrimaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.subheadline.weight(.semibold))
            .foregroundStyle(Color.black.opacity(0.9))
            .padding(.vertical, 12)
            .padding(.horizontal, 18)
            .background(LabTheme.accent.opacity(configuration.isPressed ? 0.7 : 1))
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
    }
}

struct LabSecondaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.subheadline.weight(.medium))
            .foregroundStyle(LabTheme.primaryText)
            .padding(.vertical, 12)
            .padding(.horizontal, 18)
            .background(LabTheme.cardAlt.opacity(configuration.isPressed ? 0.6 : 1))
            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .stroke(LabTheme.stroke, lineWidth: 1)
            )
    }
}

// MARK: - 卡片

struct LabCard<Content: View>: View {
    let title: String?
    let icon: String?
    @ViewBuilder let content: Content

    init(title: String? = nil, icon: String? = nil, @ViewBuilder content: () -> Content) {
        self.title = title
        self.icon = icon
        self.content = content()
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            if let title {
                HStack(spacing: 8) {
                    if let icon {
                        Image(systemName: icon)
                            .font(.subheadline)
                            .foregroundStyle(LabTheme.accent)
                    }
                    Text(title)
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(LabTheme.primaryText)
                }
            }
            content
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(LabTheme.card)
        .clipShape(RoundedRectangle(cornerRadius: LabTheme.cornerRadius, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: LabTheme.cornerRadius, style: .continuous)
                .stroke(LabTheme.stroke, lineWidth: 1)
        )
    }
}

// MARK: - 区块标题

struct LabSectionHeader: View {
    let title: String
    let subtitle: String
    let icon: String

    var body: some View {
        HStack(alignment: .top, spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .fill(LabTheme.accent.opacity(0.15))
                Image(systemName: icon)
                    .font(.title3)
                    .foregroundStyle(LabTheme.accent)
            }
            .frame(width: 48, height: 48)

            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.title3.weight(.bold))
                    .foregroundStyle(LabTheme.primaryText)
                Text(subtitle)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer()
        }
    }
}

// MARK: - 键值行

struct InfoRow: View {
    let label: String
    let value: String
    var monospaced: Bool = false

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Text(label)
                .font(.caption)
                .foregroundStyle(.secondary)
                .frame(width: 88, alignment: .leading)
            Text(value)
                .font(monospaced ? .caption.monospaced() : .caption)
                .foregroundStyle(LabTheme.primaryText)
                .textSelection(.enabled)
                .frame(maxWidth: .infinity, alignment: .leading)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.vertical, 6)
    }
}

// MARK: - 统计块

struct StatTile: View {
    let title: String
    let value: String
    let tint: Color

    var body: some View {
        VStack(spacing: 4) {
            Text(value)
                .font(.title3.weight(.bold).monospacedDigit())
                .foregroundStyle(tint)
            Text(title)
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
        .background(tint.opacity(0.1))
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
    }
}

// MARK: - 提示卡

struct LabNoticeCard: View {
    let title: String
    /// 属性名不能用 body —— 会和 SwiftUI 的 `var body: some View` 冲突，
    /// 编译报 invalid redeclaration of 'body'。
    let message: String

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 6) {
                Image(systemName: "info.circle")
                    .font(.caption)
                    .foregroundStyle(LabTheme.secondaryText)
                Text(title)
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(LabTheme.secondaryText)
            }
            Text(message)
                .font(.caption2)
                .foregroundStyle(LabTheme.secondaryText)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(LabTheme.cardAlt.opacity(0.5))
        .clipShape(RoundedRectangle(cornerRadius: LabTheme.cornerRadius, style: .continuous))
    }
}

// MARK: - 消息卡

struct LabMessageCard: View {
    let level: LogLevel
    let title: String
    let message: String

    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: symbol)
                .font(.subheadline)
                .foregroundStyle(tint)
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(tint)
                Text(message)
                    .font(.caption2)
                    .foregroundStyle(LabTheme.primaryText)
                    .fixedSize(horizontal: false, vertical: true)
            }
          Spacer()
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(tint.opacity(0.1))
        .clipShape(RoundedRectangle(cornerRadius: LabTheme.cornerRadius, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: LabTheme.cornerRadius, style: .continuous)
                .stroke(tint.opacity(0.25), lineWidth: 1)
        )
    }

    private var tint: Color {
        switch level {
        case .info: return LabTheme.accent
        case .success: return LabTheme.success
        case .warning: return LabTheme.warning
        case .error: return LabTheme.danger
        }
    }

    private var symbol: String {
        switch level {
        case .info: return "info.circle.fill"
        case .success: return "checkmark.circle.fill"
        case .warning: return "exclamationmark.triangle.fill"
        case .error: return "xmark.octagon.fill"
        }
    }
}

// MARK: - 进度卡

struct LabProgressCard: View {
    let progress: Double
    let message: String

    var body: some View {
        LabCard(title: "处理中", icon: "hourglass") {
            VStack(alignment: .leading, spacing: 10) {
                ProgressView(value: min(max(progress, 0), 1))
                    .tint(LabTheme.accent)
                HStack {
                    Text(message)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(2)
                    Spacer()
                    Text("\(Int(min(max(progress, 0), 1) * 100))%")
                        .font(.caption.monospacedDigit())
                        .foregroundStyle(.secondary)
                }
            }
        }
    }
}

// MARK: - 分享面板

import UIKit

struct ShareSheetView: UIViewControllerRepresentable {
    let items: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
