//
//  DocumentPicker.swift
//  Lab
//
//  原生 UIDocumentPickerViewController 的 SwiftUI 封装。
//
//  为什么不用 SwiftUI 的 `.fileImporter`：
//    1. `.fileImporter` 底层同样走 UIDocumentPickerViewController，
//       而 Lab 启动时对 `UIDocumentPickerViewController.init` 做了
//       method swizzle（lara 上游修文档选择器 bug 用），两者叠加可能
//       导致「点了没反应」。
//    2. `.fileImporter` 的 allowedContentTypes 对 `.ipa` 这种非系统注册
//       类型支持不好，文件会被灰掉。
//
//  改用显式封装后，可以：
//    · 用 `asCopy: true` 让系统先把文件拷进沙盒，避免安全作用域问题
//    · 传 `[.item]` 接受任何文件，扩展名在解析阶段自己校验
//    · 直接拿到 URL，不经过 SwiftUI 的异步桥接
//

import SwiftUI
import UIKit
import UniformTypeIdentifiers

struct DocumentPicker: UIViewControllerRepresentable {

    /// 允许的类型。默认接受任何文件（扩展名在业务层校验）。
    var contentTypes: [UTType] = [.item]
    /// 一次是否可选多个
    var allowsMultiple: Bool = false
    /// 选完回调。空数组表示用户取消。
    var onPick: ([URL]) -> Void

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        // asCopy: true —— 让系统把文件复制到 App 自己的沙盒里。
        // 这样即使不持有安全作用域访问权，也能稳定读到文件内容，
        // 避免「选完读不出内容」这类问题。
        let picker = UIDocumentPickerViewController(
            forOpeningContentTypes: contentTypes,
            asCopy: true
        )
        picker.delegate = context.coordinator
        picker.allowsMultipleSelection = allowsMultiple
        picker.shouldShowFileExtensions = true
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(onPick: onPick)
    }

    final class Coordinator: NSObject, UIDocumentPickerDelegate {

        private let onPick: ([URL]) -> Void

        init(onPick: @escaping ([URL]) -> Void) {
            self.onPick = onPick
        }

        func documentPicker(
            _ controller: UIDocumentPickerViewController,
            didPickDocumentsAt urls: [URL]
        ) {
            onPick(urls)
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            onPick([])
        }
    }
}
