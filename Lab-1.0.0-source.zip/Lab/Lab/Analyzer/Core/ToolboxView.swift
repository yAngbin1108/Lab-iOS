//
//  ToolboxView.swift
//  Lab
//
//  分析工具的入口页 —— 卡片网格布局。
//
//  为什么要这一页：
//    iOS 的 TabView 超过 5 个标签会自动折叠成系统生成的 "More" 列表，
//    而那个列表只显示我们给 .tabItem 的内容。之前 .tabItem 里只放了
//    Image(systemName:) 没放文字，导致 More 页出现「只有图标、没有标题」
//    的空列表。
//
//    把五个分析模块收进这一个页面，底部就只剩内核 / 文件 / 日志 / 工具箱
//    四个主标签，不再触发系统的 More 折叠，同时也让每个功能的用途一目了然。
//

import SwiftUI

/// 工具箱里的一个功能入口
struct ToolboxItem: Identifiable {
    let id: String
    let title: String
    let subtitle: String
    let icon: String
    let tint: Color
}

struct ToolboxView: View {

    @EnvironmentObject private var model: LabAppModel
    /// 内核状态。工具箱页只读取、不修改。
    @ObservedObject private var mgr = LabMgr.shared

    /// 所有入口。新增分析模块时在这里加一行即可。
    private let items: [ToolboxItem] = [
        ToolboxItem(
            id: "diff",
            title: "IPA 差异分析",
            subtitle: "对比两个包的增删改",
            icon: "arrow.left.arrow.right.square",
            tint: LabTheme.accent
        ),
        ToolboxItem(
            id: "localization",
            title: "IPA 本地化管理",
            subtitle: "读取 .strings 文本资源",
            icon: "character.book.closed",
            tint: Color(red: 0.62, green: 0.45, blue: 0.93)
        ),
        ToolboxItem(
            id: "appanalysis",
            title: "应用行为分析",
            subtitle: "权限声明与结构",
            icon: "shippingbox",
            tint: Color(red: 0.95, green: 0.62, blue: 0.25)
        ),
        ToolboxItem(
            id: "runtimemonitor",
            title: "运行监控",
            subtitle: "解析崩溃日志",
            icon: "waveform.path.ecg",
            tint: Color(red: 0.30, green: 0.78, blue: 0.55)
        ),
        ToolboxItem(
            id: "capabilities",
            title: "系统能力检测",
            subtitle: "设备与内核状态",
            icon: "cpu",
            tint: Color(red: 0.95, green: 0.42, blue: 0.42)
        ),
    ]

    /// 两列自适应网格
    private let columns = [
        GridItem(.flexible(), spacing: 14),
        GridItem(.flexible(), spacing: 14)
    ]

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {

                    header

                    LazyVGrid(columns: columns, spacing: 14) {
                        ForEach(items) { item in
                            NavigationLink(value: item.id) {
                                ToolboxCard(item: item)
                            }
                            .buttonStyle(.plain)
                        }
                    }

                    kernelStatusCard

                    LabNoticeCard(
                        title: "这些功能不需要内核权限",
                        message: """
                        工具箱里的五个模块都只使用公开接口，不依赖漏洞利用是否成功。\
                        「系统能力检测」会实时显示内核读写通道的实际状态。
                        """
                    )
                }
                .padding(LabTheme.pagePadding)
            }
            .background(LabTheme.background.ignoresSafeArea())
            .navigationTitle("工具箱")
            .navigationDestination(for: String.self) { id in
                destination(for: id)
            }
        }
    }

    // MARK: - 头部

    private var header: some View {
        HStack(alignment: .top, spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .fill(LabTheme.accent.opacity(0.15))
                Image(systemName: "square.grid.2x2.fill")
                    .font(.title3)
                    .foregroundStyle(LabTheme.accent)
            }
            .frame(width: 48, height: 48)

            VStack(alignment: .leading, spacing: 4) {
                Text("工具箱")
                    .font(.title3.weight(.bold))
                    .foregroundStyle(LabTheme.primaryText)
                Text("IPA 分析与设备诊断工具")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
        }
    }

    // MARK: - 内核状态摘要

    /// 在工具箱顶部直接显示内核当前状态，省得来回切标签页确认。
    private var kernelStatusCard: some View {
        LabCard(title: "内核状态", icon: "lock.shield") {
            HStack(spacing: 10) {
                StatTile(
                    title: "漏洞利用",
                    value: mgr.dsready ? "已就绪" : "未运行",
                    tint: mgr.dsready ? LabTheme.success : LabTheme.warning
                )
                StatTile(
                    title: "偏移表",
                    value: mgr.hasOffsets ? "已获取" : "缺失",
                    tint: mgr.hasOffsets ? LabTheme.success : LabTheme.warning
                )
                StatTile(
                    title: "kernel_slide",
                    value: mgr.kernslide == 0 ? "—" : "0x" + String(format: "%llx", mgr.kernslide),
                    tint: LabTheme.accent
                )
            }
        }
    }

    // MARK: - 路由

    @ViewBuilder
    private func destination(for id: String) -> some View {
        switch id {
        case "diff":
            IPADiffView().environmentObject(model)
        case "localization":
            LocalizationManagerView().environmentObject(model)
        case "appanalysis":
            AppAnalyzerView().environmentObject(model)
        case "runtimemonitor":
            RuntimeMonitorView().environmentObject(model)
        case "capabilities":
            CapabilitiesView().environmentObject(model)
        default:
            EmptyView()
        }
    }
}

// MARK: - 卡片

private struct ToolboxCard: View {
    let item: ToolboxItem

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {

            ZStack {
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .fill(item.tint.opacity(0.16))
                Image(systemName: item.icon)
                    .font(.system(size: 22, weight: .medium))
                    .foregroundStyle(item.tint)
            }
            .frame(width: 46, height: 46)

            VStack(alignment: .leading, spacing: 3) {
                Text(item.title)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(LabTheme.primaryText)
                    .lineLimit(1)
                    .minimumScaleFactor(0.85)

                Text(item.subtitle)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)
            }

            Spacer(minLength: 0)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .frame(minHeight: 128)
        .background(LabTheme.card)
        .clipShape(RoundedRectangle(cornerRadius: LabTheme.cornerRadius, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: LabTheme.cornerRadius, style: .continuous)
                .stroke(LabTheme.stroke, lineWidth: 1)
        )
    }
}
