//
//  IPAArchive.swift
//  iOS Lab
//
//  纯 Swift / Foundation 实现的 ZIP 读取器。
//  不依赖任何第三方 Swift Package（因此不需要在 Xcode 里添加 SPM 依赖）。
//
//  支持：store(0) 与 deflate(8) 两种压缩方式，
//       本地文件头 + 中央目录解析，ZIP64 扩展字段。
//
//  注意：这是一个「只读」实现，用于分析 IPA 归档结构。
//

import Foundation
import Compression

struct IPAArchiveEntry {
    let path: String
    let compressedSize: UInt64
    let uncompressedSize: UInt64
    let crc32: UInt32
    let compressionMethod: UInt16
    let modDate: Date?
    let isDirectory: Bool
    /// 该条目在归档文件中的偏移（本地文件头之后的数据起点）
    let dataOffset: UInt64
    /// 本地文件头中的实际数据长度（用于流式读取；可能与中央目录不一致）
    let rawDataLength: UInt64

    var uncompressedDisplay: String {
        ByteCountFormatter.string(fromByteCount: Int64(uncompressedSize), countStyle: .file)
    }

    var compressionName: String {
        switch compressionMethod {
        case 0: return "Store"
        case 8: return "Deflate"
        case 12: return "BZip2"
        case 14: return "LZMA"
        default: return "#\(compressionMethod)"
        }
    }
}

enum IPAArchiveError: LocalizedError {
    case notAZipFile
    case truncated
    case unsupportedCompression(UInt16)
    case decompressionFailed(String)

    var errorDescription: String? {
        switch self {
        case .notAZipFile: return "不是有效的 ZIP / IPA 文件（未找到中央目录）"
        case .truncated: return "文件不完整或已被截断"
        case .unsupportedCompression(let m): return "暂不支持的压缩方式：#\(m)"
        case .decompressionFailed(let p): return "解压失败：\(p)"
        }
    }
}

final class IPAArchive {

    let url: URL
    private let handle: FileHandle
    private let fileSize: UInt64

    /// 中央目录中的全部条目，按归档内原始顺序排列
    private(set) var entries: [IPAArchiveEntry] = []

    /// 路径 → 条目
    private var entryMap: [String: IPAArchiveEntry] = [:]

    // MARK: - 初始化

    init(url: URL) throws {
        self.url = url
        let h = try FileHandle(forReadingFrom: url)
        self.handle = h

        let attrs = try FileManager.default.attributesOfItem(atPath: url.path)
        self.fileSize = (attrs[.size] as? NSNumber)?.uint64Value ?? 0

        try readCentralDirectory()
    }

    deinit {
        try? handle.close()
    }

    // MARK: - 中央目录解析

    private func readCentralDirectory() throws {
        guard fileSize > 22 else { throw IPAArchiveError.truncated }

        // 1. 从文件尾部向前搜索 EOCD 签名 0x06054b50
        let tailLength = Int(min(fileSize, 66_000)) // 注释最长 65535
        let tailStart = fileSize - UInt64(tailLength)
        let tail = try read(at: tailStart, length: tailLength)

        guard let eocdOffset = Self.lastIndex(of: [0x50, 0x4b, 0x05, 0x06], in: tail) else {
            throw IPAArchiveError.notAZipFile
        }

        let eocd = tail.subdata(in: eocdOffset..<tail.count)
        guard eocd.count >= 22 else { throw IPAArchiveError.truncated }

        var entryCount = UInt64(eocd.leUInt16(at: 10))
        var cdSize = UInt64(eocd.leUInt32(at: 12))
        var cdOffset = UInt64(eocd.leUInt32(at: 16))

        // 2. 检查 ZIP64 定位器 (0x07064b50)，紧邻 EOCD 之前
        if eocdOffset >= 20 {
            let locator = tail.subdata(in: (eocdOffset - 20)..<eocdOffset)
            if locator.count >= 20, locator.leUInt32(at: 0) == 0x07064b50 {
                let z64Offset = locator.leUInt64(at: 8)
                let z64 = try read(at: z64Offset, length: 56)
                if z64.count >= 56, z64.leUInt32(at: 0) == 0x06064b50 {
                    entryCount = z64.leUInt64(at: 32)
                    cdSize = z64.leUInt64(at: 40)
                    cdOffset = z64.leUInt64(at: 48)
                }
            }
        }

        guard cdOffset + cdSize <= fileSize else { throw IPAArchiveError.truncated }

        // 3. 读取中央目录区
        let cdData = try read(at: cdOffset, length: Int(cdSize))
        try parseCentralDirectory(cdData, expectedCount: Int(entryCount))
    }

    private func parseCentralDirectory(_ data: Data, expectedCount: Int) throws {
        var cursor = 0
        var parsed: [IPAArchiveEntry] = []
        parsed.reserveCapacity(expectedCount)

        while cursor + 46 <= data.count {
            guard data.leUInt32(at: cursor) == 0x02014b50 else { break }

            let method = data.leUInt16(at: cursor + 10)
            let modTime = data.leUInt16(at: cursor + 12)
            let modDateField = data.leUInt16(at: cursor + 14)
            let crc = data.leUInt32(at: cursor + 16)
            var compressed = UInt64(data.leUInt32(at: cursor + 20))
            var uncompressed = UInt64(data.leUInt32(at: cursor + 24))
            let nameLength = Int(data.leUInt16(at: cursor + 28))
            let extraLength = Int(data.leUInt16(at: cursor + 30))
            let commentLength = Int(data.leUInt16(at: cursor + 32))
            var localOffset = UInt64(data.leUInt32(at: cursor + 42))

            guard cursor + 46 + nameLength + extraLength + commentLength <= data.count else { break }

            let nameData = data.subdata(in: (cursor + 46)..<(cursor + 46 + nameLength))
            let extraData = data.subdata(in: (cursor + 46 + nameLength)..<(cursor + 46 + nameLength + extraLength))

            let name = Self.decodeName(nameData, flags: data.leUInt16(at: cursor + 8))

            // ZIP64 扩展字段 (0x0001)
            if compressed == 0xFFFF_FFFF || uncompressed == 0xFFFF_FFFF || localOffset == 0xFFFF_FFFF {
                var e = 0
                while e + 4 <= extraData.count {
                    let tag = extraData.leUInt16(at: e)
                    let size = Int(extraData.leUInt16(at: e + 2))
                    guard e + 4 + size <= extraData.count else { break }
                    if tag == 0x0001 {
                        var p = e + 4
                        if uncompressed == 0xFFFF_FFFF, p + 8 <= e + 4 + size {
                            uncompressed = extraData.leUInt64(at: p); p += 8
                        }
                        if compressed == 0xFFFF_FFFF, p + 8 <= e + 4 + size {
                            compressed = extraData.leUInt64(at: p); p += 8
                        }
                        if localOffset == 0xFFFF_FFFF, p + 8 <= e + 4 + size {
                            localOffset = extraData.leUInt64(at: p); p += 8
                        }
                    }
                    e += 4 + size
                }
            }

            // 读取本地文件头以获得真实数据偏移
            var dataOffset = localOffset
            var rawLength = compressed
            if localOffset + 30 <= fileSize {
                if let lh = try? read(at: localOffset, length: 30), lh.count == 30, lh.leUInt32(at: 0) == 0x04034b50 {
                    let lNameLen = Int(lh.leUInt16(at: 26))
                    let lExtraLen = Int(lh.leUInt16(at: 28))
                    dataOffset = localOffset + 30 + UInt64(lNameLen) + UInt64(lExtraLen)
                    // 本地头中的压缩长度若有效则以它为准（数据描述符模式下为 0）
                    let localCompressed = UInt64(lh.leUInt32(at: 18))
                    if localCompressed > 0 { rawLength = localCompressed }
                    if dataOffset + rawLength > fileSize {
                        rawLength = max(0, fileSize - dataOffset)
                    }
                }
            }

            cursor += 46 + nameLength + extraLength + commentLength

            let entry = IPAArchiveEntry(
                path: name,
                compressedSize: compressed,
                uncompressedSize: uncompressed,
                crc32: crc,
                compressionMethod: method,
                modDate: Self.dosDate(date: modDateField, time: modTime),
                isDirectory: name.hasSuffix("/"),
                dataOffset: dataOffset,
                rawDataLength: rawLength
            )
            parsed.append(entry)
        }

        self.entries = parsed
        self.entryMap = Dictionary(parsed.map { ($0.path, $0) }, uniquingKeysWith: { first, _ in first })
    }

    // MARK: - 读取条目内容

    func entry(at path: String) -> IPAArchiveEntry? {
        entryMap[path]
    }

    /// 读取并解压单个条目
    func data(for entry: IPAArchiveEntry) throws -> Data {
        guard entry.uncompressedSize <= UInt64(Int.max) else {
            throw IPAArchiveError.decompressionFailed("条目过大")
        }
        let compressedLength = Int(entry.rawDataLength)
        guard compressedLength >= 0, entry.dataOffset + UInt64(compressedLength) <= fileSize else {
            throw IPAArchiveError.truncated
        }

        let raw: Data
        if entry.compressionMethod == 0 {
            // store：中央目录里的 uncompressedSize 可能不可靠，以头部长度为准
            let length = compressedLength > 0 ? compressedLength : Int(entry.uncompressedSize)
            raw = try read(at: entry.dataOffset, length: length)
        } else {
            raw = try read(at: entry.dataOffset, length: compressedLength)
        }

        switch entry.compressionMethod {
        case 0:
            return raw
        case 8:
            return try Self.inflate(raw, expectedSize: Int(entry.uncompressedSize), name: entry.path)
        default:
            throw IPAArchiveError.unsupportedCompression(entry.compressionMethod)
        }
    }

    /// 读取条目并当作 UTF-8 文本返回
    func string(for path: String) throws -> String? {
        guard let e = entry(at: path) else { return nil }
        let d = try data(for: e)
        if let s = String(data: d, encoding: .utf8) { return s }
        if let s = String(data: d, encoding: .utf16) { return s }
        if let s = String(data: d, encoding: .isoLatin1) { return s }
        return nil
    }

    // MARK: - 低层读取

    private func read(at offset: UInt64, length: Int) throws -> Data {
        guard length > 0 else { return Data() }
        try handle.seek(toOffset: offset)
        let d = handle.readData(ofLength: length)
        if d.count < length { throw IPAArchiveError.truncated }
        return d
    }

    // MARK: - 解压 (raw deflate)

    static func inflate(_ data: Data, expectedSize: Int, name: String) throws -> Data {
        if data.isEmpty { return Data() }
        // 部分 IPA 使用 zlib 包装（带 2 字节头 + 4 字节 adler32），先尝试 raw deflate
        if let out = performDecompression(data: data, expectedSize: expectedSize) { return out }
        if data.count > 6 {
            let stripped = data.subdata(in: 2..<(data.count - 4))
            if let out = performDecompression(data: stripped, expectedSize: expectedSize) { return out }
        }
        throw IPAArchiveError.decompressionFailed(name)
    }

    private static func performDecompression(data: Data, expectedSize: Int) -> Data? {
        let capacity = max(expectedSize, 1)
        let destination = UnsafeMutablePointer<UInt8>.allocate(capacity: capacity)
        defer { destination.deallocate() }

        let produced: Int = data.withUnsafeBytes { raw -> Int in
            guard let base = raw.bindMemory(to: UInt8.self).baseAddress else { return 0 }
            return compression_decode_buffer(destination, capacity, base, data.count, nil, COMPRESSION_ZLIB)
        }

        guard produced > 0 else { return nil }
        return Data(bytes: destination, count: produced)
    }

    // MARK: - 工具

    static func lastIndex(of pattern: [UInt8], in data: Data) -> Int? {
        guard pattern.count <= data.count else { return nil }
        var i = data.count - pattern.count
        while i >= 0 {
            var match = true
            for j in 0..<pattern.count where data[data.startIndex + i + j] != pattern[j] {
                match = false
                break
            }
            if match { return i }
            if i == 0 { break }
            i -= 1
        }
        return nil
    }

    private static func decodeName(_ data: Data, flags: UInt16) -> String {
        // UTF-8 标志位 (bit 11)
        if flags & 0x0800 != 0, let s = String(data: data, encoding: .utf8) { return s }
        // 先试 UTF-8（绝大多数 IPA 是这样），失败再退回 CP437 近似
        if let s = String(data: data, encoding: .utf8) { return s }
        if let s = String(data: data, encoding: .isoLatin1) { return s }
        return String(decoding: data, as: UTF8.self)
    }

    private static func dosDate(date: UInt16, time: UInt16) -> Date? {
        guard date != 0 else { return nil }
        var c = DateComponents()
        c.year = Int((date >> 9) & 0x7F) + 1980
        c.month = Int((date >> 5) & 0x0F)
        c.day = Int(date & 0x1F)
        c.hour = Int((time >> 11) & 0x1F)
        c.minute = Int((time >> 5) & 0x3F)
        c.second = Int(time & 0x1F) * 2
        var cal = Calendar(identifier: .gregorian)
        cal.timeZone = TimeZone(secondsFromGMT: 0) ?? .current
        return cal.date(from: c)
    }
}

// MARK: - Data 小端读取辅助

extension Data {

    func leUInt16(at index: Int) -> UInt16 {
        guard index + 2 <= count else { return 0 }
        let i = startIndex + index
        return UInt16(self[i]) | (UInt16(self[i + 1]) << 8)
    }

    func leUInt32(at index: Int) -> UInt32 {
        guard index + 4 <= count else { return 0 }
        let i = startIndex + index
        return UInt32(self[i])
            | (UInt32(self[i + 1]) << 8)
            | (UInt32(self[i + 2]) << 16)
            | (UInt32(self[i + 3]) << 24)
    }

    func leUInt64(at index: Int) -> UInt64 {
        guard index + 8 <= count else { return 0 }
        return UInt64(leUInt32(at: index)) | (UInt64(leUInt32(at: index + 4)) << 32)
    }
}
