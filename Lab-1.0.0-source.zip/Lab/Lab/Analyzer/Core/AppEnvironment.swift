//
//  AppEnvironment.swift
//  iOS Lab
//
//  运行环境信息与能力检测结果的数据模型。
//  设计原则：任何一项"能力"都必须来自实际运行时探测，
//  不允许仅凭设备型号 / 系统版本 / 漏洞名称就推断能力可用。
//

import Foundation

// MARK: - 运行模式

enum RunMode: String, Codable {
    case standard   // 普通模式：普通签名安装即可
    case enhanced   // 增强模式：探测到额外系统能力后才开放

    var displayName: String {
        switch self {
        case .standard: return "普通模式"
        case .enhanced: return "增强模式"
        }
    }
}

// MARK: - 环境信息

struct EnvironmentInfo {

    let deviceModel: String          // 设备标识符，如 iPhone16,2
    let deviceMarketingName: String  // 营销名，如 iPhone 15 Pro Max
    let systemName: String
    let systemVersion: String
    let buildNumber: String
    let processorCount: Int
    let physicalMemoryBytes: UInt64
    let diskTotalBytes: Int64
    let diskFreeBytes: Int64
    let appVersion: String
    let appBuild: String

    static func current() -> EnvironmentInfo {
        let device = DeviceSupport.current()
        let disk = DiskSupport.usage()
        return EnvironmentInfo(
            deviceModel: DeviceSupport.machineIdentifier(),
            deviceMarketingName: device.marketingName,
            systemName: DeviceSupport.osName(),
            systemVersion: DeviceSupport.osVersion(),
            buildNumber: DeviceSupport.osBuild(),
            processorCount: ProcessInfo.processInfo.processorCount,
            physicalMemoryBytes: ProcessInfo.processInfo.physicalMemory,
            diskTotalBytes: disk.total,
            diskFreeBytes: disk.free,
            appVersion: DeviceSupport.appVersion(),
            appBuild: DeviceSupport.appBuild()
        )
    }

    var formattedDiskTotal: String { ByteCountFormatter.string(fromByteCount: diskTotalBytes, countStyle: .file) }
    var formattedDiskFree: String { ByteCountFormatter.string(fromByteCount: diskFreeBytes, countStyle: .file) }
    var formattedMemory: String { ByteCountFormatter.string(fromByteCount: Int64(physicalMemoryBytes), countStyle: .memory) }
    var formattedDevice: String { "\(deviceMarketingName)（\(deviceModel)）" }
    var formattedSystem: String { "\(systemName) \(systemVersion) (\(buildNumber))" }
}

// MARK: - 能力项

enum CapabilityAvailability: String, Codable {
    case available      // 已探测到，可用
    case unavailable    // 已探测，不可用
    case unverified     // 尚未验证 / 未实现，默认关闭

    var displayName: String {
        switch self {
        case .available: return "可用"
        case .unavailable: return "不可用"
        case .unverified: return "未验证"
        }
    }

    var symbolName: String {
        switch self {
        case .available: return "checkmark.seal.fill"
        case .unavailable: return "xmark.seal.fill"
        case .unverified: return "questionmark.seal"
        }
    }
}

struct CapabilityItem: Identifiable, Codable {
    let id: String
    let name: String
    let detail: String
    var availability: CapabilityAvailability
    let standardModeAvailable: Bool
    /// 该能力在增强模式中是否必须经过真机验证才能开启
    let requiresVerification: Bool
}

// MARK: - 诊断记录

enum LogLevel: String, Codable {
    case info, success, warning, error
}

struct DiagnosticEntry: Identifiable, Codable {
    let id: UUID
    let time: Date
    let level: LogLevel
    let module: String
    let message: String

    init(level: LogLevel, module: String, message: String) {
        self.id = UUID()
        self.time = Date()
        self.level = level
        self.module = module
        self.message = message
    }

    /// 从落盘数据还原时使用，保留原始时间戳
    init(time: Date, level: LogLevel, module: String, message: String) {
        self.id = UUID()
        self.time = time
        self.level = level
        self.module = module
        self.message = message
    }
}
