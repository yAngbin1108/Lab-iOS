//
//  DeviceNames.swift
//  iOS Lab
//
//  hw.machine 标识符 → 营销名映射表。
//  仅做展示用途；表中不存在的标识符会原样显示标识符本身。
//

import Foundation

enum DeviceNames {

    private static let table: [String: String] = [
        // iPhone 15 系列
        "iPhone16,1": "iPhone 15 Pro",
        "iPhone16,2": "iPhone 15 Pro Max",
        "iPhone15,4": "iPhone 15",
        "iPhone15,5": "iPhone 15 Plus",
        // iPhone 14 系列
        "iPhone15,2": "iPhone 14 Pro",
        "iPhone15,3": "iPhone 14 Pro Max",
        "iPhone14,7": "iPhone 14",
        "iPhone14,8": "iPhone 14 Plus",
        // iPhone 13 系列
        "iPhone14,4": "iPhone 13 mini",
        "iPhone14,5": "iPhone 13",
        "iPhone14,2": "iPhone 13 Pro",
        "iPhone14,3": "iPhone 13 Pro Max",
        // iPhone 12 系列
        "iPhone13,1": "iPhone 12 mini",
        "iPhone13,2": "iPhone 12",
        "iPhone13,3": "iPhone 12 Pro",
        "iPhone13,4": "iPhone 12 Pro Max",
        // iPhone 11 系列
        "iPhone12,1": "iPhone 11",
        "iPhone12,3": "iPhone 11 Pro",
        "iPhone12,5": "iPhone 11 Pro Max",
        "iPhone12,8": "iPhone SE (2nd)",
        // iPhone X 世代
        "iPhone11,2": "iPhone XS",
        "iPhone11,4": "iPhone XS Max",
        "iPhone11,6": "iPhone XS Max",
        "iPhone11,8": "iPhone XR",
        "iPhone10,3": "iPhone X",
        "iPhone10,6": "iPhone X",
        // SE / 8 / 7
        "iPhone14,6": "iPhone SE (3rd)",
        "iPhone12,8b": "iPhone SE (2nd)",
        "iPhone10,1": "iPhone 8",
        "iPhone10,4": "iPhone 8",
        "iPhone10,2": "iPhone 8 Plus",
        "iPhone10,5": "iPhone 8 Plus",
        "iPhone9,1": "iPhone 7",
        "iPhone9,3": "iPhone 7",
        "iPhone9,2": "iPhone 7 Plus",
        "iPhone9,4": "iPhone 7 Plus",
        // iPad
        "iPad14,3": "iPad Pro 11 (4th)",
        "iPad14,4": "iPad Pro 11 (4th)",
        "iPad14,5": "iPad Pro 12.9 (6th)",
        "iPad14,6": "iPad Pro 12.9 (6th)",
        "iPad13,18": "iPad 10",
        "iPad13,19": "iPad 10",
        "iPad13,1": "iPad Air 4",
        "iPad13,2": "iPad Air 4",
        // 模拟器 / 桌面
        "x86_64": "模拟器 (x86_64)",
        "arm64": "模拟器 (arm64)"
    ]

    static func marketingName(for identifier: String) -> String {
        if let name = table[identifier] { return name }
        // 未知标识符：按前缀给出粗略归类，仍然把原始标识符展示出来
        if identifier.hasPrefix("iPhone") { return "iPhone（\(identifier)）" }
        if identifier.hasPrefix("iPad") { return "iPad（\(identifier)）" }
        if identifier.hasPrefix("iPod") { return "iPod touch（\(identifier)）" }
        if identifier.hasPrefix("Mac") || identifier.hasPrefix("iMac") { return "Mac（\(identifier)）" }
        return identifier
    }
}
