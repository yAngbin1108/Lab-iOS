//
//  DiagnosticsManager.swift
//  iOS Lab
//
//  统一诊断日志与系统修改记录。
//  工具自身执行过的每一步操作都会被记录，便于事后排查异常。
//

import Foundation
import Combine

@MainActor
final class DiagnosticsManager: ObservableObject {

    @Published private(set) var entries: [DiagnosticEntry] = []

    /// 内存中最多保留的日志条数
    private let maxEntries = 2000

    /// 日志落盘位置（沙盒 Documents/Diagnostics）
    private lazy var storeURL: URL = {
        let fm = FileManager.default
        let base = fm.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? fm.temporaryDirectory
        let dir = base.appendingPathComponent("Diagnostics", isDirectory: true)
        try? fm.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir.appendingPathComponent("session.log")
    }()

    init() {
        loadFromDisk()
    }

    // MARK: - 写入

    func log(level: LogLevel, module: String, message: String) {
        let entry = DiagnosticEntry(level: level, module: module, message: message)
        entries.append(entry)
        if entries.count > maxEntries {
            entries.removeFirst(entries.count - maxEntries)
        }
        appendToDisk(entry)
    }

    func info(_ module: String, _ message: String) { log(level: .info, module: module, message: message) }
    func success(_ module: String, _ message: String) { log(level: .success, module: module, message: message) }
    func warning(_ module: String, _ message: String) { log(level: .warning, module: module, message: message) }
    func error(_ module: String, _ message: String) { log(level: .error, module: module, message: message) }

    func clear() {
        entries.removeAll()
        try? FileManager.default.removeItem(at: storeURL)
    }

    // MARK: - 导出

    func exportText() -> String {
        let df = DateFormatter()
        df.dateFormat = "yyyy-MM-dd HH:mm:ss"
        var lines: [String] = []
        lines.append("iOS Lab 诊断日志")
        lines.append("生成时间：\(df.string(from: Date()))")
        lines.append("记录条数：\(entries.count)")
        lines.append(String(repeating: "-", count: 40))
        for e in entries {
            lines.append("[\(df.string(from: e.time))] [\(e.level.rawValue.uppercased())] [\(e.module)] \(e.message)")
        }
        return lines.joined(separator: "\n")
    }

    // MARK: - 落盘

    private func appendToDisk(_ entry: DiagnosticEntry) {
        let df = ISO8601DateFormatter()
        let line = "\(df.string(from: entry.time))\t\(entry.level.rawValue)\t\(entry.module)\t\(entry.message)\n"
        guard let data = line.data(using: .utf8) else { return }

        if let handle = try? FileHandle(forWritingTo: storeURL) {
            defer { try? handle.close() }
            _ = try? handle.seekToEnd()
            try? handle.write(contentsOf: data)
        } else {
            try? data.write(to: storeURL, options: .atomic)
        }
    }

    private func loadFromDisk() {
        guard let data = try? Data(contentsOf: storeURL),
              let text = String(data: data, encoding: .utf8) else { return }

        let df = ISO8601DateFormatter()
        var loaded: [DiagnosticEntry] = []

        for raw in text.split(separator: "\n") {
            let parts = raw.split(separator: "\t", maxSplits: 3, omittingEmptySubsequences: false)
            guard parts.count == 4 else { continue }
            let date = df.date(from: String(parts[0])) ?? Date()
            let level = LogLevel(rawValue: String(parts[1])) ?? .info
            loaded.append(
                DiagnosticEntry(
                    time: date,
                    level: level,
                    module: String(parts[2]),
                    message: String(parts[3])
                )
            )
        }

        if !loaded.isEmpty {
            entries = Array(loaded.suffix(maxEntries))
        }
    }
}
