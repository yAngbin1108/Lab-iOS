//
//  Hashing.swift
//  iOS Lab
//
//  哈希工具。SHA-256 通过 CryptoKit 实现（iOS 13+，无需第三方依赖）。
//

import Foundation
import CryptoKit

enum Hashing {

    /// 计算数据 SHA-256，返回小写十六进制字符串
    static func sha256(_ data: Data) -> String {
        let digest = SHA256.hash(data: data)
        return digest.map { String(format: "%02x", $0) }.joined()
    }

    /// 流式计算文件 SHA-256，避免大文件一次性载入内存
    static func sha256(fileAt url: URL, chunkSize: Int = 1 << 20) throws -> String {
        let handle = try FileHandle(forReadingFrom: url)
        defer { try? handle.close() }

        var hasher = SHA256()
        while true {
            let chunk = handle.readData(ofLength: chunkSize)
            if chunk.isEmpty { break }
            hasher.update(data: chunk)
        }
        let digest = hasher.finalize()
        return digest.map { String(format: "%02x", $0) }.joined()
    }

    /// 简短的哈希前缀，用于界面展示
    static func short(_ hex: String, length: Int = 12) -> String {
        guard hex.count > length else { return hex }
        return String(hex.prefix(length)) + "…"
    }
}
