//
//  CapabilitiesView.swift
//  Lab
//
//  系统能力检测 —— 合并后的版本。
//
//  相比纯分析版本，这里额外说明了一件事：本应用**确实具备**内核读写能力
//  （由 DarkSword 漏洞利用提供），但这项能力是否在你的设备上可用，
//  取决于漏洞利用是否真的成功，而不是取决于设备型号或系统版本。
//  所以状态仍然由运行时探测决定。
//

import SwiftUI

struct CapabilitiesView: View {

    @EnvironmentObject private var model: LabAppModel
    @StateObject private var mgr = LabMgr.shared

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: LabTheme.sectionSpacing) {

                LabSectionHeader(
                    title: "系统能力检测",
                    subtitle: "设备信息、内核状态，以及各项能力的实际探测结果",
                    icon: "cpu"
                )

                deviceCard
                kernelCard

                capabilityCard(
                    title: "分析类能力",
                    subtitle: "不依赖内核漏洞，普通签名安装即可使用",
                    items: model.capabilities(inStandardMode: true)
                )
                capabilityCard(
                    title: "内核类能力",
                    subtitle: "由 DarkSword 漏洞利用提供",
                    items: liveKernelCapabilities
                )

                LabNoticeCard(
                    title: "能力判定原则",
                    message: """
                    内核能力的状态来自漏洞利用的**实际执行结果**，不是静态推断。

                    即使设备型号和系统版本都在支持列表里，漏洞利用也可能因为随机因素失败\
                    （iOS 的地址随机化、后台进程状态、内存布局都会影响成功率）。\
                    失败时这里会显示为不可用，重试是唯一的办法。
                    """
                )
            }
            .padding(LabTheme.pagePadding)
        }
        .background(LabTheme.background.ignoresSafeArea())
        .navigationTitle("系统能力检测")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    model.refresh()
                } label: {
                    Label("重新检测", systemImage: "arrow.clockwise")
                }
            }
        }
    }

    // MARK: - 设备信息

    /// 内核能力**实时**从 LabMgr 计算，不使用启动时的快照。
    ///
    /// 之前的 bug：内核状态在 App 启动的 onAppear 里注入一次，
    /// 那时漏洞利用还没跑，所以永远是「全不可用」。用户即使后来
    /// 成功运行了 exploit，这个页面也不会更新 —— 表现为
    /// 「内核页显示已成功，但能力检测显示全部不可用」的自相矛盾。
    private var liveKernelCapabilities: [CapabilityItem] {
        let exploitOK = mgr.dsready
        let offsetsOK = mgr.hasOffsets
        let writeOK = exploitOK && offsetsOK
        let rcOK = RemoteCall.isLiveContainerRuntime()

        return [
            CapabilityItem(
                id: "kernel.exploit",
                name: "内核漏洞利用",
                detail: exploitOK
                    ? "漏洞利用已成功执行，内核读写通道建立"
                    : "尚未成功执行。请在「内核」标签页运行漏洞利用；失败属正常现象，可重试。",
                availability: exploitOK ? .available : .unavailable,
                standardModeAvailable: false,
                requiresVerification: true
            ),
            CapabilityItem(
                id: "kernel.offsets",
                name: "内核偏移表",
                detail: offsetsOK
                    ? "偏移数据已就绪，可定位内核符号"
                    : "偏移数据缺失。需先成功运行漏洞利用，再获取内核缓存。",
                availability: offsetsOK ? .available : .unavailable,
                standardModeAvailable: false,
                requiresVerification: true
            ),
            CapabilityItem(
                id: "kernel.write",
                name: "内核内存写入",
                detail: writeOK
                    ? "具备内核内存写入能力。注意：任意写入会直接影响系统稳定性。"
                    : "未就绪。需要漏洞利用成功且偏移表就绪。",
                availability: writeOK ? .available : .unavailable,
                standardModeAvailable: false,
                requiresVerification: true
            )
        ]
    }

    private var deviceCard: some View {
        LabCard(title: "设备与系统", icon: "iphone.gen3") {
            let env = model.environment
            VStack(spacing: 0) {
                InfoRow(label: "设备", value: env.formattedDevice)
                InfoRow(label: "系统版本", value: env.formattedSystem)
                InfoRow(label: "内核构建", value: DeviceSupport.osBuild(), monospaced: true)
                InfoRow(label: "处理器核心", value: "\(env.processorCount)")
                InfoRow(label: "物理内存", value: env.formattedMemory)
                InfoRow(label: "存储容量", value: env.formattedDiskTotal)
                InfoRow(label: "可用空间", value: env.formattedDiskFree)
                InfoRow(label: "应用版本", value: "\(env.appVersion) (\(env.appBuild))")
            }
        }
    }

    // MARK: - 内核状态

    private var kernelCard: some View {
        LabCard(title: "内核状态", icon: "lock.open.trianglebadge.exclamationmark") {
            VStack(spacing: 0) {
                InfoRow(label: "偏移表", value: mgr.hasOffsets ? "已就绪" : "缺失（需先运行漏洞利用）")
                InfoRow(label: "漏洞利用", value: exploitStatus)
                InfoRow(label: "RemoteCall", value: remoteCallStatus)

                if mgr.kernbase != 0 {
                    InfoRow(
                        label: "kernel_base",
                        value: String(format: "0x%llx", mgr.kernbase),
                        monospaced: true
                    )
                }
                if mgr.kernslide != 0 {
                    InfoRow(
                        label: "kernel_slide",
                        value: String(format: "0x%llx", mgr.kernslide),
                        monospaced: true
                    )
                }

                if !mgr.hasOffsets {
                    LabMessageCard(
                        level: .warning,
                        title: "尚未获取内核偏移",
                        message: "请先到「内核」标签页点击「运行漏洞利用」，成功后即可读取上方内核地址。"
                    )
                    .padding(.top, 10)
                }
            }
        }
    }

    private var exploitStatus: String {
        if mgr.dsready { return "已完成" }
        if mgr.dsrunning { return String(format: "运行中 %.0f%%", mgr.dsprogress * 100) }
        if mgr.dsfailed { return "失败（可重试）" }
        if mgr.dsattempted { return "已尝试" }
        return "未运行"
    }

    private var remoteCallStatus: String {
        RemoteCall.isLiveContainerRuntime() ? "可用" : "未就绪"
    }

    // MARK: - 能力清单

    private func capabilityCard(
        title: String,
        subtitle: String,
        items: [CapabilityItem]
    ) -> some View {
        LabCard(title: title, icon: "checklist") {
            VStack(alignment: .leading, spacing: 12) {
                Text(subtitle)
                    .font(.caption)
                    .foregroundStyle(.secondary)

                ForEach(items) { item in
                    HStack(alignment: .top, spacing: 10) {
                        Image(systemName: item.availability.symbolName)
                            .font(.subheadline)
                            .foregroundStyle(color(for: item.availability))
                            .frame(width: 20)

                        VStack(alignment: .leading, spacing: 3) {
                            HStack(spacing: 6) {
                                Text(item.name)
                                    .font(.subheadline.weight(.medium))
                                    .foregroundStyle(LabTheme.primaryText)
                                Text(item.availability.displayName)
                                    .font(.caption2.weight(.medium))
                                    .padding(.horizontal, 6)
                                    .padding(.vertical, 2)
                                    .background(color(for: item.availability).opacity(0.15))
                                    .foregroundStyle(color(for: item.availability))
                                    .clipShape(Capsule())
                            }
                            Text(item.detail)
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    }
                    .padding(.vertical, 4)
                    .frame(maxWidth: .infinity, alignment: .leading)

                    if item.id != items.last?.id {
                        Divider().background(LabTheme.stroke)
                    }
                }
            }
        }
    }

    private func color(for availability: CapabilityAvailability) -> Color {
        switch availability {
        case .available: return LabTheme.success
        case .unavailable: return LabTheme.danger
        case .unverified: return LabTheme.warning
        }
    }
}
