//
//  LabAppModel.swift
//  Lab
//
//  分析类模块的全局状态，与内核状态（LabMgr）分开维护。
//
//  为什么分开：
//    内核状态（kernel_base / kernel_slide / 漏洞利用进度）来自 LabMgr，
//    它的生命周期与漏洞利用绑定。分析模块只需要设备信息与能力清单，
//    两者混在一个 ObservableObject 里会让「不跑漏洞利用就不能看设备信息」
//    这种错误设计出现。
//

import Foundation
import Combine

@MainActor
final class LabAppModel: ObservableObject {

    static let shared = LabAppModel()

    @Published private(set) var environment: EnvironmentInfo
    @Published private(set) var capabilities: [CapabilityItem] = []
    @Published private(set) var runMode: RunMode = .standard
    @Published private(set) var lastDetection: Date?

    let diagnostics = DiagnosticsManager()

    /// 内核状态由 App 入口在每次 refresh 前写入。
    /// 放在这里而不是直接引用 LabMgr，是为了让分析模块能在
    /// 内核功能不可用（不受支持的设备）时依然独立工作。
    var kernelExploitSucceeded = false
    var kernelOffsetsReady = false

    private init() {
        self.environment = EnvironmentInfo.current()
    }

    func refresh() {
        environment = EnvironmentInfo.current()

        // 注入内核实际状态。这一步是「探测」而不是「推断」：
        // 状态来自漏洞利用的真实执行结果，没用过就是不可用。
        CapabilityDetector.shared.updateKernelState(
            CapabilityDetector.KernelState(
                exploitSucceeded: kernelExploitSucceeded,
                offsetsReady: kernelOffsetsReady,
                kernelWriteReady: kernelExploitSucceeded && kernelOffsetsReady
            )
        )

        let detected = CapabilityDetector.shared.detect(environment: environment)
        capabilities = detected
        runMode = CapabilityDetector.shared.resolveMode(capabilities: detected)
        lastDetection = Date()

        let availableCount = detected.filter { $0.availability == .available }.count
        let unverifiedCount = detected.filter { $0.availability == .unverified }.count
        diagnostics.log(
            level: .info,
            module: "能力检测",
            message: "探测完成：\(availableCount) 项可用，\(unverifiedCount) 项未验证 → \(runMode.displayName)"
        )
    }

    func capabilities(inStandardMode: Bool) -> [CapabilityItem] {
        capabilities.filter { $0.standardModeAvailable == inStandardMode }
    }

    func isEnabled(capabilityID: String) -> Bool {
        guard let item = capabilities.first(where: { $0.id == capabilityID }) else { return false }
        return item.availability == .available
    }
}
