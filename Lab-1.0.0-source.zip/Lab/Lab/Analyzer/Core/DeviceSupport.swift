//
//  DeviceSupport.swift
//  iOS Lab
//
//  设备 / 系统信息读取封装。
//  只使用 Foundation 与 Darwin 提供的公开接口，不依赖任何私有 API。
//

import Foundation

enum DeviceSupport {

    // MARK: - 系统信息

    static func osName() -> String {
        var uts = utsname()
        uname(&uts)
        return withUnsafePointer(to: &uts.sysname) { ptr in
            ptr.withMemoryRebound(to: CChar.self, capacity: 256) {
                String(cString: $0)
            }
        }
    }

    static func osVersion() -> String {
        let v = ProcessInfo.processInfo.operatingSystemVersion
        return "\(v.majorVersion).\(v.minorVersion)"
    }

    static func osPatchVersion() -> String {
        return "\(ProcessInfo.processInfo.operatingSystemVersion.patchVersion)"
    }

    static func osBuild() -> String {
        sysctlString("kern.osversion") ?? "未知"
    }

    /// 机器标识符，例如 iPhone16,2
    static func machineIdentifier() -> String {
        sysctlString("hw.machine") ?? "未知设备"
    }

    // MARK: - App 信息

    static func appVersion() -> String {
        (Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String) ?? "—"
    }

    static func appBuild() -> String {
        (Bundle.main.infoDictionary?["CFBundleVersion"] as? String) ?? "—"
    }

    static func bundleIdentifier() -> String {
        Bundle.main.bundleIdentifier ?? "—"
    }

    /// 当前 App 自身容器相关的能力信息。
    ///
    /// 注意：`SecTaskCreateFromSelf` 属于 macOS Security 框架，iOS SDK 中不存在，
    /// 因此这里不使用它。iOS 上判断 App Group 是否可用，唯一可靠的手段是
    /// `FileManager.containerURL(forSecurityApplicationGroupIdentifier:)` 返回非 nil。
    static func appGroupContainers(identifiers: [String]) -> [String] {
        identifiers.filter { identifier in
            FileManager.default.containerURL(
                forSecurityApplicationGroupIdentifier: identifier
            ) != nil
        }
    }

    /// 当前应用是否具备任何 App Group 容器
    static func hasAnyAppGroup() -> Bool {
        // 没有内置的标识符列表时，尝试用 Info.plist 中的声明
        let declared = Bundle.main.infoDictionary?["AppGroupIdentifiers"] as? [String]
        guard let declared, !declared.isEmpty else { return false }
        return !appGroupContainers(identifiers: declared).isEmpty
    }

    // MARK: - sysctl 辅助

    static func sysctlString(_ name: String) -> String? {
        var size = 0
        guard sysctlbyname(name, nil, &size, nil, 0) == 0, size > 0 else { return nil }
        var buffer = [CChar](repeating: 0, count: size)
        guard sysctlbyname(name, &buffer, &size, nil, 0) == 0 else { return nil }
        return String(cString: buffer)
    }

    // MARK: - 营销名映射

    static func marketingName(for identifier: String) -> String {
        DeviceNames.marketingName(for: identifier)
    }

    static func current() -> (marketingName: String, identifier: String) {
        let id = machineIdentifier()
        return (marketingName(for: id), id)
    }
}

// MARK: - 磁盘占用

enum DiskSupport {

    static func usage() -> (total: Int64, free: Int64) {
        let url = URL(fileURLWithPath: NSHomeDirectory())
        var total: Int64 = 0
        var free: Int64 = 0
        if let values = try? url.resourceValues(forKeys: [.volumeTotalCapacityKey, .volumeAvailableCapacityForImportantUsageKey]) {
            total = Int64(values.volumeTotalCapacity ?? 0)
            free = values.volumeAvailableCapacityForImportantUsage ?? 0
        }
        return (total, free)
    }
}
