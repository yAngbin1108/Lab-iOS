//
//  InstallationCapability.swift
//  Lab
//
//  安装方式检测 —— 决定内核功能是否开放。
//
//  为什么需要这个：
//    Lab 的内核漏洞利用依赖几条私有 entitlements（platform-application、
//    no-sandbox、extended-virtual-addressing）。这些权限**只有**绕过签名校验
//    的安装方式（TrollStore 等）才能保留。
//
//    用普通开发者证书（免费或付费）安装时，这几条会被系统剥离。此时应用
//    仍然能启动、分析模块全部可用，但一碰内核功能就会：
//      · 读 /var/... 返回 EPERM，界面显示成空目录（有误导性）
//      · 漏洞利用跑到中途失败，日志里看不出真正原因
//
//    与其让用户对着「运行失败」猜半天，不如在启动时探测一次，
//    把真实原因直接告诉他。
//
//  探测原则：
//    只做**只读**探测，绝不为了「测试」去写系统文件。
//    任何一项探测失败都只是保守降级，不会产生副作用。
//

import Foundation
import Darwin

enum InstallationKind: String {
    case privileged     // 保留了私有 entitlements，内核功能可用
    case sandboxed      // 权限被剥离，只能用分析功能
    case unsupported    // 设备/系统不在支持范围

    var displayName: String {
        switch self {
        case .privileged: return "特权安装"
        case .sandboxed: return "普通安装"
        case .unsupported: return "不支持"
        }
    }

    /// 内核相关界面是否开放
    var kernelFeaturesAvailable: Bool {
        self == .privileged
    }
}

struct InstallationReport {

    let kind: InstallationKind
    /// 逐项探测结果，界面直接展示，便于用户自己判断
    let checks: [Check]

    struct Check {
        let name: String
        let passed: Bool
        /// 失败时给出的具体原因（含 errno）
        let detail: String
    }

    /// 失败项摘要，用于在内核页顶部显示
    var failedChecks: [Check] {
        checks.filter { !$0.passed }
    }

    var summary: String {
        if kind == .privileged {
            return "已检测到完整的系统权限，内核功能可用。"
        }
        if kind == .unsupported {
            return "当前设备或系统不在支持范围内。"
        }
        return """
        当前安装方式未保留系统级权限，内核功能不可用。
        通常原因是用普通开发者证书签名（AltStore / Sideloadly / 各类自签工具），\
        这类工具会重新签名并剥离私有 entitlements。

        请改用 TrollStore 或其它保留伪签名的安装方式。
        """
    }
}

enum InstallationCapability {

    // MARK: - 探测入口

    static func detect() -> InstallationReport {
        var checks: [InstallationReport.Check] = []

        checks.append(probeSystemPathReadable())
        checks.append(probeProcessInfoAccess())
        checks.append(probeTaskForPid())

        // 只要有一项关键权限探不到，就保守判定为普通安装。
        // 宁可少开放功能，也不要让用户以为能用却在半路炸掉。
        let allPassed = checks.allSatisfy { $0.passed }
        let kind: InstallationKind = allPassed ? .privileged : .sandboxed

        if isunsupported() {
            return InstallationReport(kind: .unsupported, checks: checks)
        }

        return InstallationReport(kind: kind, checks: checks)
    }

    // MARK: - 单项探测

    /// 能否读取 /var/mobile —— no-sandbox 的直接体现。
    ///
    /// 注意这里只做 opendir，不读内容、不写任何东西。
    /// 沙盒下会返回 EPERM(1) 或 ENOENT(2)。
    private static func probeSystemPathReadable() -> InstallationReport.Check {
        let path = "/var/mobile/Library/Preferences"

        var st = stat()
        let result = lstat(path, &st)

        if result == 0 {
            return InstallationReport.Check(
                name: "系统目录访问",
                passed: true,
                detail: "可访问 \(path)"
            )
        }

        let err = errno
        return InstallationReport.Check(
            name: "系统目录访问",
            passed: false,
            detail: "无法访问 \(path)：\(describe(errno: err))"
        )
    }

    /// 能否用 sysctl 枚举全系统进程。
    ///
    /// 沙盒应用只能看到自己的进程；proc_info-allow 打开后能列出全部。
    /// 这里只查总数，不遍历细节。
    private static func probeProcessInfoAccess() -> InstallationReport.Check {
        var mib: [Int32] = [CTL_KERN, KERN_PROC, KERN_PROC_ALL, 0]
        var size = 0

        let result = sysctl(&mib, 4, nil, &size, nil, 0)
        if result != 0 {
            return InstallationReport.Check(
                name: "进程枚举",
                passed: false,
                detail: "sysctl 失败：\(describe(errno: errno))"
            )
        }

        // kp_proc 结构大小约 648 字节（arm64），用它估算进程数
        let estimated = size / 648
        let passed = estimated > 150  // 沙盒下通常只能看到几十个

        return InstallationReport.Check(
            name: "进程枚举",
            passed: passed,
            detail: passed
                ? "可见约 \(estimated) 个进程，权限完整"
                : "仅可见约 \(estimated) 个进程，权限受限（沙盒下属正常）"
        )
    }

    /// 能否对其它进程调用 task_for_pid —— RemoteCall 的前置条件。
    ///
    /// 用一个绝不会被攻击的探测方式：查 pid 1（launchd）。
    /// 沙盒下返回 KERN_FAILURE；有 platform-application 时需要
    /// 目标进程可被 attach，探测本身可能因权限返回失败，
    /// 所以这一项只作为**参考**，不参与最终判定。
    private static func probeTaskForPid() -> InstallationReport.Check {
        var task: mach_port_t = 0
        let kr = task_for_pid(mach_task_self_, 1, &task)

        if kr == KERN_SUCCESS, task != 0 {
            mach_port_deallocate(mach_task_self_, task)
            return InstallationReport.Check(
                name: "跨进程任务访问",
                passed: true,
                detail: "可获取 launchd 的任务端口"
            )
        }

        return InstallationReport.Check(
            name: "跨进程任务访问",
            passed: false,
            detail: "无法获取目标任务端口（内核返回 \(kr)）"
                + "。此项失败不影响漏洞利用本身，但 RemoteCall 可能不可用。"
        )
    }

    // MARK: - 辅助

    private static func describe(errno code: Int32) -> String {
        switch code {
        case EPERM: return "权限不足 EPERM(1) —— 未获得 no-sandbox 权限"
        case EACCES: return "拒绝访问 EACCES(13)"
        case ENOENT: return "路径不存在或不可见 ENOENT(2) —— 可能被沙盒隔离"
        case 0: return "未知错误"
        default: return "errno \(code)"
        }
    }
}
