//
//  CapabilityDetector.swift
//  iOS Lab
//
//  能力检测层：整个工程唯一决定「某功能是否可以开放」的地方。
//
//  设计原则（重要）：
//  1. 每一项能力的结论只能来自运行时实际探测结果。
//  2. 不允许因为「设备是 iPhone 15 / 系统是 iOS 17.5.1」就推断某项能力可用。
//  3. 未实现或未验证的能力一律标记为 .unverified，界面上显示「未验证」并保持关闭，
//     绝不会因为检测到某个漏洞名称就自动开启增强模式。
//

import Foundation

final class CapabilityDetector {

    static let shared = CapabilityDetector()

    private init() {}

    /// 执行一次完整探测，返回当前环境的能力清单
    func detect(environment: EnvironmentInfo) -> [CapabilityItem] {
        var items: [CapabilityItem] = []

        items.append(contentsOf: probesForStandardMode(environment: environment))
        items.append(contentsOf: probesForEnhancedMode(environment: environment))

        return items
    }

    /// 根据能力清单推导当前应处的运行模式。
    ///
    /// 判定规则：只有当「至少一项内核能力」被实际探测为 available 时，
    /// 才进入增强模式。全部为 unavailable / unverified 时保持普通模式。
    func resolveMode(capabilities: [CapabilityItem]) -> RunMode {
        let enhanced = capabilities.filter { !$0.standardModeAvailable }
        let anyVerified = enhanced.contains { $0.availability == .available }
        return anyVerified ? .enhanced : .standard
    }

    /// 内核能力的外部状态注入点。
    ///
    /// 分析层不该直接依赖 LabMgr（那会让分析模块无法在漏洞利用不可用时独立工作），
    /// 所以由 App 入口在探测前把内核状态写进这里。
    /// 默认值是「未验证」，也就是说：没有注入 = 内核能力不可用。
    struct KernelState {
        var exploitSucceeded: Bool = false
        var offsetsReady: Bool = false
        var kernelWriteReady: Bool = false
    }

    private(set) var kernelState = KernelState()

    func updateKernelState(_ state: KernelState) {
        kernelState = state
    }

    // MARK: - 普通模式能力探测

    private func probesForStandardMode(environment: EnvironmentInfo) -> [CapabilityItem] {

        // 1. 沙盒内文件读写
        let sandboxWritable = probeSandboxWritable()

        // 2. ZIP / IPA 归档读取（内置纯 Swift 解析器，始终可用）
        let archiveReadable = probeArchiveReadable()

        // 3. plist 解析能力
        let plistReadable = probePlistReadable()

        // 4. 崩溃日志目录可读性（普通 App 只能读到自己容器内的日志）
        let crashLogReadable = probeCrashLogReadable()

        // 5. 公开的 sysctl 信息
        let sysctlAvailable = !DeviceSupport.machineIdentifier().isEmpty
            && DeviceSupport.machineIdentifier() != "未知设备"

        return [
            CapabilityItem(
                id: "sandbox.file",
                name: "沙盒文件读写",
                detail: sandboxWritable
                    ? "可在自身容器内创建、读取与删除文件"
                    : "沙盒目录不可写，请检查存储空间与权限",
                availability: sandboxWritable ? .available : .unavailable,
                standardModeAvailable: true,
                requiresVerification: false
            ),
            CapabilityItem(
                id: "archive.read",
                name: "IPA / ZIP 归档读取",
                detail: archiveReadable
                    ? "内置纯 Swift 解析器，支持 store / deflate"
                    : "内置归档解析器自检失败",
                availability: archiveReadable ? .available : .unavailable,
                standardModeAvailable: true,
                requiresVerification: false
            ),
            CapabilityItem(
                id: "plist.parse",
                name: "Info.plist 解析",
                detail: plistReadable
                    ? "支持 binary 与 XML 两种 plist，可读取密钥与 Entitlements"
                    : "plist 解析器自检失败",
                availability: plistReadable ? .available : .unavailable,
                standardModeAvailable: true,
                requiresVerification: false
            ),
            CapabilityItem(
                id: "diagnostics.crashlog",
                name: "崩溃日志读取",
                detail: crashLogReadable
                    ? "可读取本应用沙盒内导入的崩溃日志"
                    : "沙盒内暂无可读取的崩溃日志目录（属正常现象）",
                availability: crashLogReadable ? .available : .unavailable,
                standardModeAvailable: true,
                requiresVerification: false
            ),
            CapabilityItem(
                id: "system.sysctl",
                name: "系统信息接口",
                detail: sysctlAvailable
                    ? "可通过公开 sysctl 读取机型、内核构建号"
                    : "sysctl 读取受限",
                availability: sysctlAvailable ? .available : .unavailable,
                standardModeAvailable: true,
                requiresVerification: false
            )
        ]
    }

    // MARK: - 内核能力探测（状态由 LabMgr 注入，不做事后推断）

    private func probesForEnhancedMode(environment: EnvironmentInfo) -> [CapabilityItem] {
        let state = kernelState

        return [
            CapabilityItem(
                id: "kernel.exploit",
                name: "内核漏洞利用",
                detail: state.exploitSucceeded
                    ? "漏洞利用已成功执行，内核读写通道建立"
                    : "尚未成功执行。请在「内核」标签页运行漏洞利用；失败属正常现象，可重试。",
                availability: state.exploitSucceeded ? .available : .unavailable,
                standardModeAvailable: false,
                requiresVerification: true
            ),
            CapabilityItem(
                id: "kernel.offsets",
                name: "内核偏移表",
                detail: state.offsetsReady
                    ? "偏移数据已就绪，可定位内核符号"
                    : "偏移数据缺失。需先成功运行漏洞利用，再获取内核缓存。",
                availability: state.offsetsReady ? .available : .unavailable,
                standardModeAvailable: false,
                requiresVerification: true
            ),
            CapabilityItem(
                id: "kernel.write",
                name: "内核内存写入",
                detail: state.kernelWriteReady
                    ? "具备内核内存写入能力。注意：任意写入会直接影响系统稳定性。"
                    : "未就绪。此项决定系统级 tweak 是否可用，未就绪时相关入口保持关闭。",
                availability: state.kernelWriteReady ? .available : .unavailable,
                standardModeAvailable: false,
                requiresVerification: true
            ),
        ]
    }

    // MARK: - 单项探测实现

    private func probeSandboxWritable() -> Bool {
        let fm = FileManager.default
        guard let dir = fm.urls(for: .cachesDirectory, in: .userDomainMask).first else { return false }
        let probe = dir.appendingPathComponent(".ioslab_probe")
        let payload = Data([0x49, 0x4F, 0x53, 0x4C, 0x41, 0x42])
        do {
            try payload.write(to: probe, options: .atomic)
            let readBack = try Data(contentsOf: probe)
            try? fm.removeItem(at: probe)
            return readBack == payload
        } catch {
            return false
        }
    }

    private func probeArchiveReadable() -> Bool {
        // 就地构造一个最小 ZIP（store 方式，含 1 个条目）验证解析器可用
        let payload = Data("ioslab".utf8)
        var zip = Data()

        @inline(__always) func le16(_ v: UInt16) -> Data {
            Data([UInt8(v & 0xFF), UInt8((v >> 8) & 0xFF)])
        }
        @inline(__always) func le32(_ v: UInt32) -> Data {
            Data([UInt8(v & 0xFF), UInt8((v >> 8) & 0xFF),
                  UInt8((v >> 16) & 0xFF), UInt8((v >> 24) & 0xFF)])
        }

        let crc = IPACRC32.compute(payload)
        let name = Data("probe.txt".utf8)

        // 本地文件头
        let localHeaderStart: UInt32 = 0
        zip.append(le32(0x04034b50))
        zip.append(le16(20))            // version needed
        zip.append(le16(0))             // flags
        zip.append(le16(0))             // method = store
        zip.append(le16(0))             // time
        zip.append(le16(0x21))          // date
        zip.append(le32(crc))
        zip.append(le32(UInt32(payload.count)))
        zip.append(le32(UInt32(payload.count)))
        zip.append(le16(UInt16(name.count)))
        zip.append(le16(0))
        zip.append(name)
        zip.append(payload)

        let cdStart = UInt32(zip.count)

        // 中央目录
        zip.append(le32(0x02014b50))
        zip.append(le16(20))
        zip.append(le16(20))
        zip.append(le16(0))
        zip.append(le16(0))
        zip.append(le16(0))
        zip.append(le16(0x21))
        zip.append(le32(crc))
        zip.append(le32(UInt32(payload.count)))
        zip.append(le32(UInt32(payload.count)))
        zip.append(le16(UInt16(name.count)))
        zip.append(le16(0))
        zip.append(le16(0))
        zip.append(le16(0))
        zip.append(le16(0))
        zip.append(le32(0))
        zip.append(le32(localHeaderStart))
        zip.append(name)

        let cdSize = UInt32(zip.count) - cdStart

        // EOCD
        zip.append(le32(0x06054b50))
        zip.append(le16(0))
        zip.append(le16(0))
        zip.append(le16(1))
        zip.append(le16(1))
        zip.append(le32(cdSize))
        zip.append(le32(cdStart))
        zip.append(le16(0))

        let tmp = FileManager.default.temporaryDirectory
            .appendingPathComponent("ioslab_probe_\(UUID().uuidString).zip")
        defer { try? FileManager.default.removeItem(at: tmp) }

        do {
            try zip.write(to: tmp)
            let archive = try IPAArchive(url: tmp)
            guard archive.entries.count == 1, let entry = archive.entries.first else { return false }
            let data = try archive.data(for: entry)
            return data == payload
        } catch {
            return false
        }
    }

    private func probePlistReadable() -> Bool {
        let dict: [String: Any] = ["IOSLabProbe": true, "Count": 3]
        do {
            let data = try PropertyListSerialization.data(fromPropertyList: dict, format: .binary, options: 0)
            let back = try PropertyListSerialization.propertyList(from: data, options: [], format: nil)
            guard let result = back as? [String: Any] else { return false }
            return (result["IOSLabProbe"] as? Bool) == true && (result["Count"] as? Int) == 3
        } catch {
            return false
        }
    }

    private func probeCrashLogReadable() -> Bool {
        // 普通 App 无法读取 /var/mobile/Library/Logs/CrashReporter，
        // 只检查自身容器内是否存在可读的崩溃日志目录。
        let fm = FileManager.default
        let candidates = [
            fm.urls(for: .documentDirectory, in: .userDomainMask).first?.appendingPathComponent("CrashLogs"),
            fm.urls(for: .libraryDirectory, in: .userDomainMask).first?.appendingPathComponent("Logs")
        ].compactMap { $0 }

        for dir in candidates where fm.fileExists(atPath: dir.path) {
            if (try? fm.contentsOfDirectory(atPath: dir.path)) != nil { return true }
        }
        return false
    }
}

// MARK: - CRC32

enum IPACRC32 {

    private static let table: [UInt32] = {
        (0..<256).map { i -> UInt32 in
            var c = UInt32(i)
            for _ in 0..<8 {
                c = (c & 1) != 0 ? (0xEDB88320 ^ (c >> 1)) : (c >> 1)
            }
            return c
        }
    }()

    static func compute(_ data: Data) -> UInt32 {
        var crc: UInt32 = 0xFFFF_FFFF
        for byte in data {
            crc = table[Int((crc ^ UInt32(byte)) & 0xFF)] ^ (crc >> 8)
        }
        return crc ^ 0xFFFF_FFFF
    }
}
