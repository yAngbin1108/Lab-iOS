//
//  LocalizationManagerView.swift
//  iOS Lab — IPA 本地化管理
//
//  功能：从 IPA 中提取 .strings / .stringsdict 文件，查看、搜索、
//        编辑并导出为 plist / JSON / 纯文本对照表。
//

import SwiftUI
import UniformTypeIdentifiers

struct LocalizationManagerView: View {

    @EnvironmentObject private var model: LabAppModel
    @StateObject private var viewModel = LocalizationViewModel()

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: LabTheme.sectionSpacing) {

                LabSectionHeader(
                    title: "IPA 本地化管理",
                    subtitle: "读取并编辑 IPA 内的 .strings 文本资源",
                    icon: "character.book.closed"
                )

                pickerCard

                if viewModel.isWorking {
                    LabProgressCard(progress: viewModel.progress, message: viewModel.progressMessage)
                }

                if let error = viewModel.errorMessage {
                    LabMessageCard(level: .error, title: "读取失败", message: error)
                }

                if !viewModel.localizationFiles.isEmpty {
                    fileListCard
                }

                // 载入成功但一个本地化文件都没有 → 明确解释，而不是留空白
                if viewModel.package != nil,
                   viewModel.localizationFiles.isEmpty,
                   !viewModel.isWorking,
                   viewModel.errorMessage == nil {
                    emptyStateCard
                }

                if let table = viewModel.selectedTable {
                    editorCard(table)
                }

                LabNoticeCard(
                    title: "使用说明",
                    message: """
                    本模块读取 IPA 归档中的 .strings 与 .stringsdict 文件，支持 binary plist 与 \
                    UTF-8 / UTF-16 文本两种格式。

                    编辑结果会写入沙盒，可通过「导出」保存；当前版本不会回写进原始 IPA 包，\
                    避免生成签名失效的安装包。
                    """
                )
            }
            .padding(LabTheme.pagePadding)
        }
        .background(LabTheme.background.ignoresSafeArea())
        .navigationTitle("IPA 本地化管理")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Button("导出对照表（JSON）") { viewModel.exportJSON() }
                    Button("导出对照表（TXT）") { viewModel.exportText() }
                    Button("导出全部 .strings 原始文件") { viewModel.exportAll() }
                } label: {
                    Label("导出", systemImage: "square.and.arrow.up")
                }
                .disabled(viewModel.selectedTable == nil)
            }
        }
        .sheet(isPresented: $viewModel.isPicking) {
            DocumentPicker(contentTypes: [.item]) { urls in
                viewModel.isPicking = false
                if let url = urls.first {
                    viewModel.load(url: url, model: model)
                }
            }
        }
        .sheet(item: $viewModel.shareItem) { item in
            ShareSheetView(items: [item.url])
        }
    }

    // MARK: - 子视图

    private var pickerCard: some View {
        LabCard(title: "第 1 步：选择 IPA 文件", icon: "shippingbox") {
            VStack(alignment: .leading, spacing: 14) {
                if let pkg = viewModel.package {
                    HStack(spacing: 12) {
                        Image(systemName: "doc.zipper")
                            .font(.title3)
                            .foregroundStyle(LabTheme.accent)
                        VStack(alignment: .leading, spacing: 3) {
                            Text(pkg.fileName)
                                .font(.subheadline.weight(.medium))
                                .lineLimit(1)
                                .truncationMode(.middle)
                            Text(pkg.info.bundleIdentifier ?? "—")
                                .font(.caption)
                                .foregroundStyle(.secondary)

                            // 明确告诉用户「0 个」是什么意思，而不是留一片空白
                            if viewModel.foundStringFileCount > 0 {
                                Text("✅ 找到 \(viewModel.foundStringFileCount) 个本地化文件，见下方列表")
                                    .font(.caption2)
                                    .foregroundStyle(LabTheme.success)
                            } else if !viewModel.isWorking {
                                Text("⚠️ 这个包里没有 .strings 文件")
                                    .font(.caption2)
                                    .foregroundStyle(LabTheme.warning)
                            }
                        }
                        Spacer()
                    }
                } else {
                    // 还没选文件时的引导
                    VStack(alignment: .leading, spacing: 6) {
                        Text("点下面按钮选择一个 .ipa 文件")
                            .font(.subheadline.weight(.medium))
                            .foregroundStyle(LabTheme.primaryText)
                        Text("支持 .ipa 和 .zip。选完会自动扫描里面的 .strings / .stringsdict 文件。")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }

                Button {
                    viewModel.isPicking = true
                } label: {
                    Label(viewModel.package == nil ? "选择 IPA" : "重新选择", systemImage: "folder.badge.plus")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(LabPrimaryButtonStyle())
                .disabled(viewModel.isWorking)
            }
        }
    }

    /// 载入成功但一个 .strings 都没有时，给出明确的解释和下一步建议。
    /// 不这么做的话，用户看到「共 0 个」加一片空白，只会觉得「这个功能坏了」。
    private var emptyStateCard: some View {
        LabCard(title: "没有找到本地化文件", icon: "questionmark.folder") {
            VStack(alignment: .leading, spacing: 10) {
                Text("这个 IPA 里没有 .strings / .stringsdict 文件。")
                    .font(.subheadline.weight(.medium))
                    .foregroundStyle(LabTheme.warning)

                Text("很多应用把界面文字直接写在代码里，不使用本地化文件。这类应用无法用本模块编辑文字。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)

                Divider().background(LabTheme.stroke)

                Text("可以试试：")
                    .font(.caption.weight(.semibold))
                VStack(alignment: .leading, spacing: 4) {
                    bullet("换一个包含多语言支持的应用（在「文件」App 里看它的 IPA 大小，通常 50MB+ 的更可能有）")
                    bullet("先用「应用行为分析」查看包的资源结构，确认有没有 .strings")
                    bullet("系统应用、社交类、游戏类应用的本地化文件通常较多")
                }
            }
        }
    }

    private func bullet(_ text: String) -> some View {
        HStack(alignment: .top, spacing: 6) {
            Image(systemName: "circle.fill")
                .font(.system(size: 4))
                .foregroundStyle(LabTheme.accent)
                .padding(.top, 5)
            Text(text)
                .font(.caption2)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private var fileListCard: some View {
        LabCard(title: "第 2 步：点一个文件查看内容", icon: "doc.text.magnifyingglass") {
            VStack(alignment: .leading, spacing: 10) {
                HStack(spacing: 10) {
                    Image(systemName: "magnifyingglass")
                        .foregroundStyle(.tertiary)
                    TextField("搜索文件名或键名", text: $viewModel.searchText)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }
                .padding(10)
                .background(LabTheme.cardAlt)
                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))

                ForEach(viewModel.filteredFiles, id: \.path) { file in
                    Button {
                        viewModel.select(file: file, model: model)
                    } label: {
                        HStack(spacing: 10) {
                            Image(systemName: file.path.hasSuffix(".stringsdict") ? "list.bullet.indent" : "text.alignleft")
                                .font(.caption)
                                .foregroundStyle(LabTheme.accent)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(file.path)
                                    .font(.caption.monospaced())
                                    .foregroundStyle(LabTheme.primaryText)
                                    .lineLimit(2)
                                    .truncationMode(.middle)
                                if let count = viewModel.entryCounts[file.path] {
                                    Text("\(count) 条")
                                        .font(.caption2)
                                        .foregroundStyle(.tertiary)
                                }
                            }
                            Spacer()
                            if viewModel.selectedTable?.path == file.path {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundStyle(LabTheme.accent)
                            }
                        }
                        .padding(.vertical, 6)
                    }
                    .buttonStyle(.plain)
                    Divider().background(LabTheme.stroke)
                }

                if viewModel.filteredFiles.isEmpty {
                    Text("没有匹配的本地化文件")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
        }
    }

    private func editorCard(_ table: LocalizationTable) -> some View {
        LabCard(title: "第 3 步：内容（可复制）", icon: "square.and.pencil") {
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    Text(table.path)
                        .font(.caption.monospaced())
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                        .truncationMode(.middle)
                    Spacer()
                    Text("\(table.entries.count) 条")
                        .font(.caption2)
                        .foregroundStyle(.tertiary)
                }

                Divider().background(LabTheme.stroke)

                ForEach(viewModel.filteredEntries(for: table), id: \.key) { entry in
                    VStack(alignment: .leading, spacing: 4) {
                        Text(entry.key)
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(LabTheme.accent)
                            .textSelection(.enabled)
                        Text(entry.value)
                            .font(.footnote)
                            .foregroundStyle(LabTheme.primaryText)
                            .textSelection(.enabled)
                    }
                    .padding(.vertical, 6)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    Divider().background(LabTheme.stroke)
                }

                if table.entries.count > 100 {
                    Text("仅显示前 100 条，完整内容请导出对照表")
                        .font(.caption2)
                        .foregroundStyle(.tertiary)
                }

                if table.isBinaryPlist {
                    Text("该文件为 binary plist 格式，界面展示的是解析后的结果。")
                        .font(.caption2)
                        .foregroundStyle(.tertiary)
                }
            }
        }
    }
}

// MARK: - 数据模型

struct LocalizationFileRef: Hashable {
    let path: String
    let size: UInt64
}

struct LocalizationEntry: Hashable {
    let key: String
    let value: String
}

struct LocalizationTable {
    let path: String
    let entries: [LocalizationEntry]
    let isBinaryPlist: Bool
    let parseNote: String?
}
