//
//  LocalizationManagerView.swift
//  iOS Lab — IPA 本地化管理
//
//  功能：从 IPA 中提取 .strings / .stringsdict 文件，查看、搜索、
//        编辑并导出为 plist / JSON / 纯文本对照表。
//

import SwiftUI
import UniformTypeIdentifiers

struct LocalizationManagerView: View {

    @EnvironmentObject private var model: LabAppModel
    @StateObject private var viewModel = LocalizationViewModel()

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: LabTheme.sectionSpacing) {

                LabSectionHeader(
                    title: "IPA 本地化管理",
                    subtitle: "读取并编辑 IPA 内的 .strings 文本资源",
                    icon: "character.book.closed"
                )

                pickerCard

                if viewModel.isWorking {
                    LabProgressCard(progress: viewModel.progress, message: viewModel.progressMessage)
                }

                if let error = viewModel.errorMessage {
                    LabMessageCard(level: .error, title: "读取失败", message: error)
                }

                if !viewModel.localizationFiles.isEmpty {
                    fileListCard
                }

                if let table = viewModel.selectedTable {
                    editorCard(table)
                }

                LabNoticeCard(
                    title: "使用说明",
                    body: """
                    本模块读取 IPA 归档中的 .strings 与 .stringsdict 文件，支持 binary plist 与 \
                    UTF-8 / UTF-16 文本两种格式。

                    编辑结果会写入沙盒，可通过「导出」保存；当前版本不会回写进原始 IPA 包，\
                    避免生成签名失效的安装包。
                    """
                )
            }
            .padding(LabTheme.pagePadding)
        }
        .background(LabTheme.background.ignoresSafeArea())
        .navigationTitle("IPA 本地化管理")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Button("导出对照表（JSON）") { viewModel.exportJSON() }
                    Button("导出对照表（TXT）") { viewModel.exportText() }
                    Button("导出全部 .strings 原始文件") { viewModel.exportAll() }
                } label: {
                    Label("导出", systemImage: "square.and.arrow.up")
                }
                .disabled(viewModel.selectedTable == nil)
            }
        }
        .fileImporter(
            isPresented: $viewModel.isPicking,
            allowedContentTypes: viewModel.allowedTypes,
            allowsMultipleSelection: false
        ) { outcome in
            switch outcome {
            case .success(let urls):
                if let url = urls.first { viewModel.load(url: url, model: model) }
            case .failure(let error):
                viewModel.errorMessage = error.localizedDescription
            }
        }
        .sheet(item: $viewModel.shareItem) { item in
            ShareSheetView(items: [item.url])
        }
    }

    // MARK: - 子视图

    private var pickerCard: some View {
        LabCard(title: "选择 IPA 文件", icon: "shippingbox") {
            VStack(alignment: .leading, spacing: 14) {
                if let pkg = viewModel.package {
                    HStack(spacing: 12) {
                        Image(systemName: "doc.zipper")
                            .font(.title3)
                            .foregroundStyle(LabTheme.accent)
                        VStack(alignment: .leading, spacing: 3) {
                            Text(pkg.fileName)
                                .font(.subheadline.weight(.medium))
                                .lineLimit(1)
                                .truncationMode(.middle)
                            Text("\(pkg.info.bundleIdentifier ?? "—") · 共 \(viewModel.foundStringFileCount) 个本地化文件")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                    }
                }

                Button {
                    viewModel.isPicking = true
                } label: {
                    Label(viewModel.package == nil ? "选择 IPA" : "重新选择", systemImage: "folder.badge.plus")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(LabPrimaryButtonStyle())
                .disabled(viewModel.isWorking)
            }
        }
    }

    private var fileListCard: some View {
        LabCard(title: "本地化文件", icon: "doc.text.magnifyingglass") {
            VStack(alignment: .leading, spacing: 10) {
                HStack(spacing: 10) {
                    Image(systemName: "magnifyingglass")
                        .foregroundStyle(.tertiary)
                    TextField("搜索文件名或键名", text: $viewModel.searchText)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }
                .padding(10)
                .background(LabTheme.cardAlt)
                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))

                ForEach(viewModel.filteredFiles, id: \.path) { file in
                    Button {
                        viewModel.select(file: file, model: model)
                    } label: {
                        HStack(spacing: 10) {
                            Image(systemName: file.path.hasSuffix(".stringsdict") ? "list.bullet.indent" : "text.alignleft")
                                .font(.caption)
                                .foregroundStyle(LabTheme.accent)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(file.path)
                                    .font(.caption.monospaced())
                                    .foregroundStyle(LabTheme.primaryText)
                                    .lineLimit(2)
                                    .truncationMode(.middle)
                                if let count = viewModel.entryCounts[file.path] {
                                    Text("\(count) 条")
                                        .font(.caption2)
                                        .foregroundStyle(.tertiary)
                                }
                            }
                            Spacer()
                            if viewModel.selectedTable?.path == file.path {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundStyle(LabTheme.accent)
                            }
                        }
                        .padding(.vertical, 6)
                    }
                    .buttonStyle(.plain)
                    Divider().background(LabTheme.stroke)
                }

                if viewModel.filteredFiles.isEmpty {
                    Text("没有匹配的本地化文件")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
        }
    }

    private func editorCard(_ table: LocalizationTable) -> some View {
        LabCard(title: "内容查看", icon: "square.and.pencil") {
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    Text(table.path)
                        .font(.caption.monospaced())
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                        .truncationMode(.middle)
                    Spacer()
                    Text("\(table.entries.count) 条")
                        .font(.caption2)
                        .foregroundStyle(.tertiary)
                }

                Divider().background(LabTheme.stroke)

                ForEach(viewModel.filteredEntries(for: table), id: \.key) { entry in
                    VStack(alignment: .leading, spacing: 4) {
                        Text(entry.key)
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(LabTheme.accent)
                            .textSelection(.enabled)
                        Text(entry.value)
                            .font(.footnote)
                            .foregroundStyle(LabTheme.primaryText)
                            .textSelection(.enabled)
                    }
                    .padding(.vertical, 6)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    Divider().background(LabTheme.stroke)
                }

                if table.entries.count > 100 {
                    Text("仅显示前 100 条，完整内容请导出对照表")
                        .font(.caption2)
                        .foregroundStyle(.tertiary)
                }

                if table.isBinaryPlist {
                    Text("该文件为 binary plist 格式，界面展示的是解析后的结果。")
                        .font(.caption2)
                        .foregroundStyle(.tertiary)
                }
            }
        }
    }
}

// MARK: - 数据模型

struct LocalizationFileRef: Hashable {
    let path: String
    let size: UInt64
}

struct LocalizationEntry: Hashable {
    let key: String
    let value: String
}

struct LocalizationTable {
    let path: String
    let entries: [LocalizationEntry]
    let isBinaryPlist: Bool
    let parseNote: String?
}
