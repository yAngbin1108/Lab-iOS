//
//  LocalizationViewModel.swift
//  iOS Lab — IPA 本地化管理状态
//

import Foundation
import Combine
import SwiftUI
import UniformTypeIdentifiers

@MainActor
final class LocalizationViewModel: ObservableObject {

    @Published var package: IPAPackage?
    @Published var localizationFiles: [LocalizationFileRef] = []
    @Published var entryCounts: [String: Int] = [:]
    @Published var selectedTable: LocalizationTable?
    @Published var searchText = ""
    @Published var entryFilter = ""
    @Published var isWorking = false
    @Published var progress: Double = 0
    @Published var progressMessage = ""
    @Published var errorMessage: String?
    @Published var isPicking = false
    @Published var shareItem: ShareItem?

    private var archive: IPAArchive?
    private var importedURL: URL?

    /// 文件选择器允许的类型。
    ///
    /// 这里**不能**只用 `UTType(filenameExtension: "ipa")`。
    /// iOS 没有注册 `.ipa` 这种系统类型，那个调用返回的是动态生成的
    /// `dyn.*` 类型，和系统实际给 `.ipa` 文件标注的 UTI 不匹配 ——
    /// 结果就是文件选择器里 `.ipa` 文件被**灰掉、点不动**。
    /// （这是真机上「左侧文件（旧）点不动」的原因）
    ///
    /// 解法：放宽到 `.item`（任何文件都可选），扩展名校验放到解析阶段做。
    var allowedTypes: [UTType] {
        [.item, .data, .zip]
    }

    /// 解析阶段的扩展名校验：不是 IPA/ZIP 就给出明确提示，
    /// 而不是让用户对着一个读不出来的包猜。
    static func validateExtension(_ url: URL) -> String? {
        let ext = url.pathExtension.lowercased()
        guard ext == "ipa" || ext == "zip" else {
            return "请选择 .ipa 或 .zip 文件（当前是 \(ext.isEmpty ? "无扩展名" : "." + ext)）"
        }
        return nil
    }

    var foundStringFileCount: Int { localizationFiles.count }

    var filteredFiles: [LocalizationFileRef] {
        guard !searchText.isEmpty else { return localizationFiles }
        let needle = searchText.lowercased()
        return localizationFiles.filter { $0.path.lowercased().contains(needle) }
    }

    func filteredEntries(for table: LocalizationTable) -> [LocalizationEntry] {
        let base = Array(table.entries.prefix(100))
        guard !entryFilter.isEmpty else { return base }
        let needle = entryFilter.lowercased()
        return base.filter {
            $0.key.lowercased().contains(needle) || $0.value.lowercased().contains(needle)
        }
    }

    // MARK: - 载入

    func load(url: URL, model: LabAppModel) {
        let name = url.lastPathComponent

        if let problem = Self.validateExtension(url) {
            errorMessage = problem
            return
        }

        model.diagnostics.info("本地化管理", "载入 IPA：\(name)")

        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }

        isWorking = true
        progress = 0
        progressMessage = "正在读取归档…"
        errorMessage = nil
        selectedTable = nil
        localizationFiles = []
        entryCounts = [:]

        // 关键：整个「复制文件 → 解析归档 → 逐个解压 .strings」都是重活，
        // 必须放到后台线程，否则会在主线程卡死整个界面。
        // （这是之前「本地化管理用不了」的直接原因 —— 同步解析把 UI 卡死了）
        let backgroundURL = url
        Task.detached(priority: .userInitiated) { [weak self] in
            guard let self else { return }

            do {
                // 复制到沙盒 + 解析归档（都在后台线程）
                let local = try Self.importToSandbox(url: backgroundURL)
                let pkg = try IPALoader.load(url: local, computeHashes: false) { pct, msg in
                    Task { @MainActor in
                        self.progress = pct * 0.5
                        self.progressMessage = msg
                    }
                }
                let arc = try IPAArchive(url: local)

                let refs = arc.entries
                    .filter { $0.path.hasSuffix(".strings") || $0.path.hasSuffix(".stringsdict") }
                    .map { LocalizationFileRef(path: $0.path, size: $0.uncompressedSize) }
                    .sorted { $0.path < $1.path }

                await MainActor.run {
                    self.package = pkg
                    self.archive = arc
                    self.importedURL = local
                    self.localizationFiles = refs
                    self.progress = 0.6
                    self.progressMessage = "正在统计条目…"
                }

                // 逐个解压并统计条目数（后台线程，只把进度回主线程）
                for (i, ref) in refs.prefix(200).enumerated() {
                    let pct = 0.7 + 0.28 * (Double(i) / Double(max(min(refs.count, 200), 1)))
                    if let entry = arc.entry(at: ref.path),
                       let data = try? arc.data(for: entry),
                       let parsed = Self.parseStrings(data: data, path: ref.path) {
                        await MainActor.run {
                            self.entryCounts[ref.path] = parsed.entries.count
                        }
                    }
                    if i % 8 == 0 || i == min(refs.count, 200) - 1 {
                        await MainActor.run {
                            self.progress = pct
                            self.progressMessage = "正在统计条目 \(i + 1)/\(min(refs.count, 200))…"
                        }
                    }
                }

                await MainActor.run {
                    self.isWorking = false
                    self.progress = 0
                    self.progressMessage = ""
                    model.diagnostics.success("本地化管理", "找到 \(refs.count) 个本地化文件")
                }

            } catch {
                await MainActor.run {
                    self.isWorking = false
                    self.errorMessage = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
                    model.diagnostics.error("本地化管理", "载入失败：\(error.localizedDescription)")
                }
            }
        }
    }

    func select(file: LocalizationFileRef, model: LabAppModel) {
        guard let arc = archive, let entry = arc.entry(at: file.path) else {
            errorMessage = "无法读取该文件"
            return
        }
        // 解压单个 .strings 也可能是大文件，放后台，避免点一下卡一下
        let path = file.path
        Task.detached(priority: .userInitiated) { [weak self] in
            guard let self else { return }
            do {
                let data = try arc.data(for: entry)
                guard let table = Self.parseStrings(data: data, path: path) else {
                    await MainActor.run {
                        self.errorMessage = "「\(path)」解析失败，可能是加密或非标准格式"
                    }
                    return
                }
                await MainActor.run {
                    self.selectedTable = table
                    self.entryFilter = ""
                    model.diagnostics.info("本地化管理", "打开 \(path)（\(table.entries.count) 条）")
                }
            } catch {
                await MainActor.run {
                    self.errorMessage = "读取失败：\(error.localizedDescription)"
                }
            }
        }
    }

    // MARK: - 解析

    /// 解析 .strings / .stringsdict。支持 binary plist、XML plist、纯文本三种形态。
    nonisolated static func parseStrings(data: Data, path: String) -> LocalizationTable? {
        guard !data.isEmpty else {
            return LocalizationTable(path: path, entries: [], isBinaryPlist: false, parseNote: "文件为空")
        }

        // 1. binary / XML plist
        let header = [UInt8](data.prefix(8))
        let isBinary = header.starts(with: [0x62, 0x70, 0x6C, 0x69, 0x73, 0x74]) // "bplist"
        let isXML = data.starts(with: Data("<?xml".utf8)) || data.starts(with: Data("<!DOCTYPE".utf8))

        if isBinary || isXML {
            if let plist = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil),
               let dict = plist as? [String: Any] {
                let entries = dict.keys.sorted().map {
                    LocalizationEntry(key: $0, value: IPALoader.stringify(dict[$0]!))
                }
                return LocalizationTable(
                    path: path,
                    entries: entries,
                    isBinaryPlist: isBinary,
                    parseNote: isBinary ? "binary plist" : "XML plist"
                )
            }
            if isBinary {
                return LocalizationTable(
                    path: path,
                    entries: [],
                    isBinaryPlist: true,
                    parseNote: "binary plist 解析失败"
                )
            }
        }

        // 2. 纯文本 .strings
        guard let text = Self.decodeText(data) else {
            return LocalizationTable(path: path, entries: [], isBinaryPlist: false, parseNote: "编码无法识别")
        }

        let entries = parseLegacyStrings(text)
        return LocalizationTable(
            path: path,
            entries: entries,
            isBinaryPlist: false,
            parseNote: entries.isEmpty ? "未解析出条目" : nil
        )
    }

    /// 手工解析传统 `"key" = "value";` 文本格式（避免依赖可能失败的 plist 解析）
    nonisolated static func parseLegacyStrings(_ text: String) -> [LocalizationEntry] {
        var entries: [LocalizationEntry] = []
        var index = text.startIndex

        func skipWhitespaceAndComments() {
            while index < text.endIndex {
                let ch = text[index]
                if ch.isWhitespace {
                    index = text.index(after: index)
                } else if ch == "/" {
                    let next = text.index(after: index)
                    if next < text.endIndex, text[next] == "/" {
                        while index < text.endIndex, text[index] != "\n" {
                            index = text.index(after: index)
                        }
                    } else if next < text.endIndex, text[next] == "*" {
                        index = text.index(after: next)
                        while index < text.endIndex {
                            if text[index] == "*" {
                                let n = text.index(after: index)
                                if n < text.endIndex, text[n] == "/" {
                                    index = text.index(after: n)
                                    break
                                }
                            }
                            index = text.index(after: index)
                        }
                    } else {
                        break
                    }
                } else {
                    break
                }
            }
        }

        func readQuoted() -> String? {
            guard index < text.endIndex, text[index] == "\"" else { return nil }
            index = text.index(after: index)
            var result = ""
            while index < text.endIndex {
                let ch = text[index]
                if ch == "\\" {
                    let next = text.index(after: index)
                    guard next < text.endIndex else { break }
                    switch text[next] {
                    case "n": result.append("\n")
                    case "t": result.append("\t")
                    case "\"": result.append("\"")
                    case "\\": result.append("\\")
                    case "r": result.append("\r")
                    default: result.append(text[next])
                    }
                    index = text.index(after: next)
                } else if ch == "\"" {
                    index = text.index(after: index)
                    return result
                } else {
                    result.append(ch)
                    index = text.index(after: index)
                }
            }
            return result.isEmpty ? nil : result
        }

        var guardCounter = 0
        while index < text.endIndex, guardCounter < 200_000 {
            guardCounter += 1
            skipWhitespaceAndComments()
            guard index < text.endIndex else { break }

            guard let key = readQuoted() else { break }
            skipWhitespaceAndComments()

            var value = ""
            if index < text.endIndex, text[index] == "=" {
                index = text.index(after: index)
                skipWhitespaceAndComments()
                value = readQuoted() ?? ""
            }

            // 跳过分号
            skipWhitespaceAndComments()
            if index < text.endIndex, text[index] == ";" {
                index = text.index(after: index)
            }

            if !key.isEmpty {
                entries.append(LocalizationEntry(key: key, value: value))
            }
        }

        return entries
    }

    nonisolated static func decodeText(_ data: Data) -> String? {
        if let s = String(data: data, encoding: .utf8) { return s }
        if data.count >= 2 {
            let bom = [UInt8](data.prefix(2))
            if bom == [0xFF, 0xFE] { return String(data: data, encoding: .utf16LittleEndian) }
            if bom == [0xFE, 0xFF] { return String(data: data, encoding: .utf16BigEndian) }
        }
        if let s = String(data: data, encoding: .utf16) { return s }
        return String(data: data, encoding: .isoLatin1)
    }

    // MARK: - 导出

    func exportJSON() {
        guard let table = selectedTable else { return }
        var dict: [String: String] = [:]
        for e in table.entries { dict[e.key] = e.value }
        guard let data = try? JSONSerialization.data(
            withJSONObject: dict,
            options: [.prettyPrinted, .sortedKeys, .withoutEscapingSlashes]
        ), let text = String(data: data, encoding: .utf8) else { return }
        shareItem = write(text, name: baseName(table.path) + "_对照表", ext: "json")
    }

    func exportText() {
        guard let table = selectedTable else { return }
        var lines = ["// 来源：\(table.path)", "// 条目数：\(table.entries.count)", ""]
        for e in table.entries {
            lines.append("\"\(e.key)\" = \"\(e.value)\";")
        }
        shareItem = write(lines.joined(separator: "\n"), name: baseName(table.path) + "_对照表", ext: "txt")
    }

    func exportAll() {
        guard !entryCounts.isEmpty else { return }
        let fm = FileManager.default
        let base = fm.urls(for: .cachesDirectory, in: .userDomainMask).first ?? fm.temporaryDirectory
        let dir = base.appendingPathComponent("LocalizationExport", isDirectory: true)
        try? fm.createDirectory(at: dir, withIntermediateDirectories: true)

        var manifest = ["iOS Lab — 本地化文件导出", "文件总数：\(localizationFiles.count)", ""]
        for ref in localizationFiles {
            manifest.append("\(ref.path)　\(ByteCountFormatter.string(fromByteCount: Int64(ref.size), countStyle: .file))")
            guard let arc = archive, let entry = arc.entry(at: ref.path),
                  let data = try? arc.data(for: entry) else { continue }
            let outURL = dir.appendingPathComponent(ref.path.replacingOccurrences(of: "/", with: "__"))
            try? data.write(to: outURL)
        }
        let manifestURL = dir.appendingPathComponent("_清单.txt")
        try? manifest.joined(separator: "\n").write(to: manifestURL, atomically: true, encoding: .utf8)

        shareItem = ShareItem(url: manifestURL)
    }

    private func write(_ text: String, name: String, ext: String) -> ShareItem? {
        let fm = FileManager.default
        let base = fm.urls(for: .cachesDirectory, in: .userDomainMask).first ?? fm.temporaryDirectory
        let dir = base.appendingPathComponent("LocalizationExport", isDirectory: true)
        try? fm.createDirectory(at: dir, withIntermediateDirectories: true)
        let url = dir.appendingPathComponent("\(name).\(ext)")
        do {
            try text.write(to: url, atomically: true, encoding: .utf8)
            return ShareItem(url: url)
        } catch {
            return nil
        }
    }

    private func baseName(_ path: String) -> String {
        ((path as NSString).lastPathComponent as NSString).deletingPathExtension
    }

    nonisolated private static func importToSandbox(url: URL) throws -> URL {
        let fm = FileManager.default
        let base = fm.urls(for: .cachesDirectory, in: .userDomainMask).first ?? fm.temporaryDirectory
        let dir = base.appendingPathComponent("IPAImports", isDirectory: true)
        try fm.createDirectory(at: dir, withIntermediateDirectories: true)
        let target = dir.appendingPathComponent(UUID().uuidString + "_" + url.lastPathComponent)
        if fm.fileExists(atPath: target.path) { try fm.removeItem(at: target) }
        try fm.copyItem(at: url, to: target)
        return target
    }
}
