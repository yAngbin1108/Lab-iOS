//
//  CrashLogParser.swift
//  iOS Lab
//
//  崩溃日志解析。支持两种常见形态：
//   1. .ips（iOS 15+ 的 JSON 头部 + 文本体）
//   2. 传统 .crash（纯文本 key: value + 调用栈）
//
//  解析目标不是完整还原符号，而是给出人可读的归类结论：
//  是内存问题、权限问题、线程问题，还是外部库问题。
//
//  实现说明：正则一律使用普通的双引号字符串（@"" 转义），
//  不使用 Swift 的原始字符串字面量，避免源码被各种工具加工时
//  破坏分隔符导致编译失败。
//

import Foundation

enum CrashLogParser {

    // MARK: - 入口

    static func parse(fileName: String, text: String) -> CrashReport {
        var report = CrashReport(fileName: fileName, rawText: text)

        if looksLikeIPS(text) {
            fillFromIPS(&report, text: text)
        } else {
            fillFromLegacy(&report, text: text)
        }

        // 通用兜底提取
        if report.exceptionType == nil {
            report.exceptionType = firstMatch(in: text, patterns: [
                "Exception Type: *(.+)",
                "Exception Codes: *(.+)",
                "\"exception\\s*:\\s*\\{?\\s*\"type\"\\s*:\\s*\"([^\"]+)\""
            ])
        }
        if report.timestamp == nil {
            report.timestamp = firstMatch(in: text, patterns: [
                "\"timestamp\"\\s*:\\s*\"([^\"]+)\"",
                "Date/Time: *(.+)",
                "Incident Identifier: *(.+)"
            ])
        }

        report.keyFrames = extractFrames(from: text)
        report.categories = categorize(report: report, text: text)
        return report
    }

    // MARK: - 形态判定

    private static func looksLikeIPS(_ text: String) -> Bool {
        let head = String(text.prefix(400))
        return head.contains("\"bug_type\"") || head.contains("\"app_name\"")
            || head.contains("\"incident\"")
            || (head.hasPrefix("{") && head.contains("\"timestamp\""))
    }

    // MARK: - IPS 解析

    private static func fillFromIPS(_ report: inout CrashReport, text: String) {
        // IPS 第一行是 JSON 头部，之后是文本体
        if let newline = text.firstIndex(of: "\n") {
            let jsonPart = String(text[text.startIndex..<newline])
            let body = String(text[text.index(after: newline)...])

            if let data = jsonPart.data(using: .utf8),
               let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                report.processName = (obj["app_name"] as? String) ?? (obj["procName"] as? String)
                report.osVersion = (obj["os_version"] as? String) ?? (obj["osVersion"] as? String)
                report.deviceModel = (obj["modelCode"] as? String) ?? (obj["device"] as? String)
                report.timestamp = (obj["timestamp"] as? String) ?? (obj["captureTime"] as? String)

                if let exception = obj["exception"] as? [String: Any] {
                    report.exceptionType = (exception["type"] as? String)
                        ?? (exception["codes"] as? [String])?.first
                }
                if let term = obj["termination"] as? [String: Any] {
                    report.terminationReason = (term["reason"] as? String)
                        ?? (term["namespace"] as? String)
                }
            }

            fillFromLegacy(&report, text: body)
        }
    }

    // MARK: - 传统文本解析

    private static func fillFromLegacy(_ report: inout CrashReport, text: String) {
        if report.processName == nil {
            report.processName = firstMatch(in: text, patterns: [
                "Process: *([^\\[\\n]+)",
                "Path: */Applications/([^/]+)\\.app",
                "\"app_name\"\\s*:\\s*\"([^\"]+)\""
            ])
        }
        if report.osVersion == nil {
            report.osVersion = firstMatch(in: text, patterns: [
                "OS Version: *(.+)",
                "iOS +([0-9]+\\.[0-9]+(?:\\.[0-9]+)?)",
                "\"os_version\"\\s*:\\s*\"([^\"]+)\""
            ])
        }
        if report.deviceModel == nil {
            report.deviceModel = firstMatch(in: text, patterns: [
                "Hardware Model: *(.+)",
                "Code Type:.*?\\(([^)]+)\\)",
                "\"modelCode\"\\s*:\\s*\"([^\"]+)\""
            ])
        }
        if report.exceptionType == nil {
            report.exceptionType = firstMatch(in: text, patterns: [
                "Exception Type: *(.+)"
            ])
        }
        if report.terminationReason == nil {
            report.terminationReason = firstMatch(in: text, patterns: [
                "Termination Reason: *(.+)",
                "Termination Description: *(.+)"
            ])
        }
    }

    // MARK: - 调用栈

    private static func extractFrames(from text: String) -> [String] {
        var frames: [String] = []
        for line in text.split(separator: "\n", omittingEmptySubsequences: false) {
            let s = String(line).trimmingCharacters(in: .whitespaces)
            // 形如：2   AppName    0x0000000104a1b2c3  -[Class method] + 123
            guard s.contains("0x") else { continue }
            guard s.contains(" + ") else { continue }

            let firstToken = s.split(separator: " ").first.map(String.init) ?? ""
            if firstToken.isEmpty { continue }
            if Int(firstToken) == nil && !firstToken.hasSuffix(":") { continue }

            frames.append(s)
            if frames.count >= 60 { break }
        }
        return frames
    }

    // MARK: - 归类

    private static func categorize(report: CrashReport, text: String) -> [String] {
        var categories: [String] = []
        let lower = text.lowercased()

        let exception = (report.exceptionType ?? "").lowercased()
        let termination = (report.terminationReason ?? "").lowercased()

        // 内存
        if exception.contains("bad_access") || exception.contains("exc_crash") {
            categories.append("内存访问异常：访问了已释放或越界的地址，常见于强引用循环或悬垂指针")
        }
        if exception.contains("breakpoint") || termination.contains("watchdog") {
            categories.append("看门狗 / 断点中断：主线程长时间阻塞会被系统强制终止，检查主线程耗时操作")
        }
        if lower.contains("out of memory") || lower.contains("jetsam")
            || lower.contains("memory pressure") || exception.contains("resource") {
            categories.append("内存压力终止：应用占用超出系统上限，需检查大图、缓存与循环引用")
        }

        // 异常与断言
        if lower.contains("nsexception") || lower.contains("nsinvalidargumentexception")
            || lower.contains("nsrangeexception") {
            categories.append("Objective-C 异常：参数非法或越界，日志中的 Reason 一段通常直接指出原因")
        }
        if lower.contains("fatal error") || lower.contains("precondition") || lower.contains("assertion") {
            categories.append("断言失败：代码中的 precondition / 强制解包触发，属于可定位的编程错误")
        }

        // 启动 / 链接
        if lower.contains("dyld") || lower.contains("library not loaded")
            || lower.contains("symbol not found") {
            categories.append("动态链接失败：缺少依赖库或符号，多见于重签名或修改了 Framework 之后")
        }
        if termination.contains("launch") || lower.contains("failed to launch") {
            categories.append("启动阶段终止：可能在 +load 或全局初始化中崩溃")
        }

        // 后台与权限
        if termination.contains("background") {
            categories.append("后台任务超时：未及时调用后台任务结束回调")
        }
        if lower.contains("privacy") || termination.contains("tcc") {
            categories.append("权限相关终止：访问了未声明的隐私数据，检查 Info.plist 用途说明")
        }

        // 第三方注入痕迹
        if lower.contains("substrate") || lower.contains("libhooker")
            || lower.contains("ellekit") || lower.contains("substitute") {
            categories.append("第三方注入相关：日志中出现注入框架痕迹，可能影响崩溃归因")
        }

        // 信号
        if lower.contains("sigsegv") || lower.contains("sigabrt") || lower.contains("sigbus") {
            categories.append("收到系统信号：SIGABRT 多为断言或异常，SIGSEGV / SIGBUS 多为内存问题")
        }

        // 卡顿
        if lower.contains("hang") || lower.contains("stall") || lower.contains("spin") {
            categories.append("卡顿或死锁：线程等待超时，检查锁的使用与同步逻辑")
        }

        if categories.isEmpty {
            categories.append("未匹配到常见模式，建议结合完整调用栈与复现步骤进一步定位")
        }

        return categories
    }

    // MARK: - 正则辅助

    private static func firstMatch(in text: String, patterns: [String]) -> String? {
        let ns = text as NSString
        for pattern in patterns {
            guard let regex = try? NSRegularExpression(
                pattern: pattern,
                options: [.anchorsMatchLines, .caseInsensitive]
            ) else { continue }

            guard let match = regex.firstMatch(
                in: text,
                options: [],
                range: NSRange(location: 0, length: ns.length)
            ) else { continue }

            let range = match.numberOfRanges > 1 ? match.range(at: 1) : match.range
            guard range.location != NSNotFound, range.length > 0 else { continue }

            let value = ns.substring(with: range).trimmingCharacters(in: .whitespacesAndNewlines)
            if !value.isEmpty { return value }
        }
        return nil
    }
}
