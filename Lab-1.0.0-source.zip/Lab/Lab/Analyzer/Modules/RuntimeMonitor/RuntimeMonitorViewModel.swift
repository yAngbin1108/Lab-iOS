//
//  RuntimeMonitorViewModel.swift
//  iOS Lab — 运行时监控状态
//

import Foundation
import SwiftUI
import UniformTypeIdentifiers

@MainActor
final class RuntimeMonitorViewModel: ObservableObject {

    @Published var reports: [CrashReport] = []
    @Published var isWorking = false
    @Published var progress: Double = 0
    @Published var progressMessage = ""
    @Published var errorMessage: String?
    @Published var isPicking = false
    @Published var shareItem: ShareItem?

    var allowedTypes: [UTType] {
        [.plainText, .text, .json, .data, .item]
    }

    var totalCrashCount: Int { reports.count }

    var affectedProcesses: Set<String> {
        Set(reports.compactMap { $0.processName })
    }

    var categoryCounts: [String: Int] {
        var counts: [String: Int] = [:]
        for report in reports {
            for category in report.categories {
                // 取分类描述的前 12 个字符作为分组键
                let key = String(category.prefix(12))
                counts[key, default: 0] += 1
            }
        }
        return counts
    }

    // MARK: - 导入

    func importLogs(urls: [URL], model: LabAppModel) {
        guard !urls.isEmpty else { return }

        isWorking = true
        progress = 0
        progressMessage = "正在读取日志…"
        errorMessage = nil

        Task.detached(priority: .userInitiated) {
            var parsed: [CrashReport] = []
            var failures: [String] = []

            for (index, url) in urls.enumerated() {
                let pct = Double(index) / Double(max(urls.count, 1))
                await MainActor.run {
                    self.progress = pct
                    self.progressMessage = "正在解析 \(url.lastPathComponent)…"
                }

                let access = url.startAccessingSecurityScopedResource()
                defer { if access { url.stopAccessingSecurityScopedResource() } }

                do {
                    let data = try Data(contentsOf: url, options: .mappedIfSafe)
                    guard let text = Self.decode(data) else {
                        failures.append("\(url.lastPathComponent)：编码无法识别")
                        continue
                    }
                    let report = CrashLogParser.parse(fileName: url.lastPathComponent, text: text)
                    parsed.append(report)
                } catch {
                    failures.append("\(url.lastPathComponent)：\(error.localizedDescription)")
                }
            }

            await MainActor.run {
                self.reports.append(contentsOf: parsed)
                self.isWorking = false
                self.progress = 1
                self.progressMessage = ""

                if parsed.isEmpty {
                    self.errorMessage = failures.isEmpty
                        ? "没有解析出可用的崩溃日志"
                        : "解析失败：\n" + failures.joined(separator: "\n")
                } else {
                    model.diagnostics.success("运行时监控", "解析 \(parsed.count) 个日志文件")
                    if !failures.isEmpty {
                        self.errorMessage = "部分文件未能解析：\n" + failures.joined(separator: "\n")
                    }
                }
                self.progress = 0
            }
        }
    }

    nonisolated private static func decode(_ data: Data) -> String? {
        if let s = String(data: data, encoding: .utf8) { return s }
        if let s = String(data: data, encoding: .utf16) { return s }
        if let s = String(data: data, encoding: .isoLatin1) { return s }
        return nil
    }

    // MARK: - 导出

    func shareDiagnostics() {
        var lines: [String] = []
        let df = DateFormatter()
        df.dateFormat = "yyyy-MM-dd HH:mm:ss"
        lines.append("iOS Lab — 崩溃诊断报告")
        lines.append("生成时间：\(df.string(from: Date()))")
        lines.append("日志文件数：\(reports.count)")
        lines.append("涉及进程：\(affectedProcesses.sorted().joined(separator: ", "))")
        lines.append(String(repeating: "=", count: 50))

        for report in reports {
            lines.append("")
            lines.append("【\(report.fileName)】")
            lines.append("  进程　　：\(report.processName ?? "—")")
            lines.append("  系统　　：\(report.osVersion ?? "—")")
            lines.append("  设备　　：\(report.deviceModel ?? "—")")
            lines.append("  时间　　：\(report.timestamp ?? "—")")
            lines.append("  异常类型：\(report.exceptionType ?? "—")")
            if let t = report.terminationReason {
                lines.append("  终止原因：\(t)")
            }
            lines.append("  归类分析：")
            for category in report.categories {
                lines.append("    · \(category)")
            }
            if !report.keyFrames.isEmpty {
                lines.append("  关键调用栈：")
                for frame in report.keyFrames.prefix(12) {
                    lines.append("    \(frame)")
                }
            }
        }

        lines.append("")
        lines.append(String(repeating: "=", count: 50))
        lines.append("说明：归类结果基于日志中的异常类型、终止原因与关键字匹配，")
        lines.append("属于辅助定位手段，不能替代在调试器中的实际复现与符号化分析。")

        let fm = FileManager.default
        let base = fm.urls(for: .cachesDirectory, in: .userDomainMask).first ?? fm.temporaryDirectory
        let dir = base.appendingPathComponent("Reports", isDirectory: true)
        try? fm.createDirectory(at: dir, withIntermediateDirectories: true)
        let df2 = DateFormatter()
        df2.dateFormat = "yyyyMMdd_HHmmss"
        let url = dir.appendingPathComponent("崩溃诊断报告_\(df2.string(from: Date())).txt")

        if (try? lines.joined(separator: "\n").write(to: url, atomically: true, encoding: .utf8)) != nil {
            shareItem = ShareItem(url: url)
        }
    }

    func clear() {
        reports.removeAll()
        errorMessage = nil
    }
}
