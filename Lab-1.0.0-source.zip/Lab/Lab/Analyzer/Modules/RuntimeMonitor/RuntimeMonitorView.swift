//
//  RuntimeMonitorView.swift
//  iOS Lab — 应用运行时监控
//
//  导入崩溃日志（.ips / .crash / .txt），解析异常类型并生成诊断报告。
//  说明：普通签名应用只能读取用户手动导入的日志文件。
//        读取系统级全量崩溃日志需要额外能力，当前版本未接入。
//

import SwiftUI
import UniformTypeIdentifiers

struct RuntimeMonitorView: View {

    @EnvironmentObject private var model: LabAppModel
    @StateObject private var viewModel = RuntimeMonitorViewModel()

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: LabTheme.sectionSpacing) {

                LabSectionHeader(
                    title: "应用运行时监控",
                    subtitle: "解析崩溃报告与系统日志，归类异常原因",
                    icon: "waveform.path.ecg"
                )

                importCard

                if viewModel.isWorking {
                    LabProgressCard(progress: viewModel.progress, message: viewModel.progressMessage)
                }

                if let error = viewModel.errorMessage {
                    LabMessageCard(level: .error, title: "解析失败", message: error)
                }

                if !viewModel.reports.isEmpty {
                    summaryCard
                    ForEach(viewModel.reports) { report in
                        reportCard(report)
                    }
                }

                LabNoticeCard(
                    title: "能力边界说明",
                    body: """
                    普通签名应用受沙盒限制，只能分析由你手动导入的日志文件。\
                    系统级的全量崩溃日志、其他应用的运行记录，都属于需要额外系统能力才能访问的范畴。

                    本模块不会尝试绕过沙盒读取 /var/mobile 下的日志目录；\
                    相关能力在「系统能力检测」中显示为「未验证」。
                    """
                )
            }
            .padding(LabTheme.pagePadding)
        }
        .background(LabTheme.background.ignoresSafeArea())
        .navigationTitle("应用运行时监控")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Button("分享诊断报告") { viewModel.shareDiagnostics() }
                    Button("清空已导入日志", role: .destructive) { viewModel.clear() }
                } label: {
                    Label("操作", systemImage: "ellipsis.circle")
                }
                .disabled(viewModel.reports.isEmpty)
            }
        }
        .fileImporter(
            isPresented: $viewModel.isPicking,
            allowedContentTypes: viewModel.allowedTypes,
            allowsMultipleSelection: true
        ) { outcome in
            switch outcome {
            case .success(let urls):
                viewModel.importLogs(urls: urls, model: model)
            case .failure(let error):
                viewModel.errorMessage = error.localizedDescription
            }
        }
        .sheet(item: $viewModel.shareItem) { item in
            ShareSheetView(items: [item.url])
        }
    }

    private var importCard: some View {
        LabCard(title: "导入日志", icon: "tray.and.arrow.down") {
            VStack(alignment: .leading, spacing: 12) {
                Text("支持 .ips、.crash、.txt、.log 格式，可一次选择多个文件。")
                    .font(.caption)
                    .foregroundStyle(.secondary)

                Button {
                    viewModel.isPicking = true
                } label: {
                    Label("选择崩溃日志文件", systemImage: "doc.badge.plus")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(LabPrimaryButtonStyle())
                .disabled(viewModel.isWorking)
            }
        }
    }

    private var summaryCard: some View {
        LabCard(title: "解析汇总", icon: "chart.pie") {
            VStack(spacing: 12) {
                HStack(spacing: 10) {
                    StatTile(title: "日志文件", value: "\(viewModel.reports.count)", tint: LabTheme.accent)
                    StatTile(title: "崩溃事件", value: "\(viewModel.totalCrashCount)", tint: LabTheme.danger)
                    StatTile(title: "涉及应用", value: "\(viewModel.affectedProcesses.count)", tint: LabTheme.warning)
                }
                if !viewModel.categoryCounts.isEmpty {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("异常类型分布")
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(.secondary)
                        ForEach(viewModel.categoryCounts.sorted(by: { $0.value > $1.value }), id: \.key) { item in
                            HStack {
                                Text(item.key)
                                    .font(.caption)
                                Spacer()
                                Text("\(item.value)")
                                    .font(.caption.monospacedDigit())
                                    .foregroundStyle(.secondary)
                            }
                            Divider().background(LabTheme.stroke)
                        }
                    }
                }
            }
        }
    }

    private func reportCard(_ report: CrashReport) -> some View {
        LabCard(title: report.fileName, icon: "doc.text.magnifyingglass") {
            VStack(alignment: .leading, spacing: 10) {
                InfoRow(label: "进程", value: report.processName ?? "—")
                InfoRow(label: "系统", value: report.osVersion ?? "—")
                InfoRow(label: "设备", value: report.deviceModel ?? "—")
                InfoRow(label: "时间", value: report.timestamp ?? "—")
                InfoRow(label: "异常类型", value: report.exceptionType ?? "—")

                if let signal = report.terminationReason {
                    InfoRow(label: "终止原因", value: signal)
                }

                if !report.categories.isEmpty {
                    Divider().background(LabTheme.stroke)
                    Text("归类分析")
                        .font(.caption.weight(.semibold))
                    ForEach(report.categories, id: \.self) { category in
                        HStack(alignment: .top, spacing: 6) {
                            Image(systemName: "circle.fill")
                                .font(.system(size: 5))
                                .foregroundStyle(LabTheme.warning)
                                .padding(.top, 5)
                            Text(category)
                                .font(.caption)
                                .foregroundStyle(LabTheme.primaryText)
                        }
                    }
                }

                if !report.keyFrames.isEmpty {
                    Divider().background(LabTheme.stroke)
                    Text("关键调用栈")
                        .font(.caption.weight(.semibold))
                    ForEach(report.keyFrames.prefix(8), id: \.self) { frame in
                        Text(frame)
                            .font(.caption2.monospaced())
                            .foregroundStyle(.secondary)
                            .lineLimit(2)
                            .truncationMode(.middle)
                            .textSelection(.enabled)
                    }
                }
            }
        }
    }
}

// MARK: - 数据模型

struct CrashReport: Identifiable {
    let id = UUID()
    let fileName: String
    var processName: String?
    var osVersion: String?
    var deviceModel: String?
    var timestamp: String?
    var exceptionType: String?
    var terminationReason: String?
    var categories: [String] = []
    var keyFrames: [String] = []
    let rawText: String
}
