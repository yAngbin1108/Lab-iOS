//
//  AppAnalyzerView.swift
//  iOS Lab — 应用行为分析
//
//  静态分析 IPA 的 Info.plist、Entitlements、动态库与资源清单。
//  注意：读取签名与 Entitlements 不等于验证签名安全属性，
//       分析结果仅反映归档中可读到的声明内容。
//

import SwiftUI
import UniformTypeIdentifiers

struct AppAnalyzerView: View {

    @EnvironmentObject private var model: LabAppModel
    @StateObject private var viewModel = AppAnalyzerViewModel()

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: LabTheme.sectionSpacing) {

                LabSectionHeader(
                    title: "应用行为分析",
                    subtitle: "静态解析 Info.plist、权限声明、动态库与资源结构",
                    icon: "shippingbox.circle"
                )

                pickerCard

                if viewModel.isWorking {
                    LabProgressCard(progress: viewModel.progress, message: viewModel.progressMessage)
                }

                if let error = viewModel.errorMessage {
                    LabMessageCard(level: .error, title: "分析失败", message: error)
                }

                if let pkg = viewModel.package {
                    basicCard(pkg)
                    if let analysis = viewModel.analysis {
                        entitlementsCard(analysis)
                        librariesCard(analysis)
                        resourcesCard(analysis)
                        plistCard(pkg)
                    }
                }

                LabNoticeCard(
                    title: "关于分析范围的说明",
                    message: """
                    本模块仅做静态分析：读取归档中的 Info.plist 与 embedded.mobileprovision 中可见的声明内容。

                    普通签名应用无法读取其他应用的完整授权链，也无法验证签名是否被篡改。\
                    因此「读到了某个 Entitlement」不代表该权限在运行时一定能生效，\
                    反之亦不代表应用一定不行使该权限。
                    """
                )
            }
            .padding(LabTheme.pagePadding)
        }
        .background(LabTheme.background.ignoresSafeArea())
        .navigationTitle("应用行为分析")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                if viewModel.analysis != nil {
                    Button {
                        viewModel.shareReport()
                    } label: {
                        Label("分享报告", systemImage: "square.and.arrow.up")
                    }
                }
            }
        }
        .sheet(isPresented: $viewModel.isPicking) {
            DocumentPicker(contentTypes: [.item]) { urls in
                viewModel.isPicking = false
                if let url = urls.first {
                    viewModel.analyze(url: url, model: model)
                }
            }
        }
        .sheet(item: $viewModel.shareItem) { item in
            ShareSheetView(items: [item.url])
        }
    }

    // MARK: - 子视图

    private var pickerCard: some View {
        LabCard(title: "选择 IPA 文件", icon: "folder.badge.plus") {
            VStack(alignment: .leading, spacing: 14) {
                if let pkg = viewModel.package {
                    HStack(spacing: 12) {
                        Image(systemName: "app.badge.checkmark")
                            .font(.title3)
                            .foregroundStyle(LabTheme.accent)
                        VStack(alignment: .leading, spacing: 3) {
                            Text(pkg.info.displayName ?? pkg.fileName)
                                .font(.subheadline.weight(.medium))
                            Text(pkg.info.bundleIdentifier ?? "—")
                                .font(.caption.monospaced())
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                    }
                }

                Button {
                    viewModel.isPicking = true
                } label: {
                    Label(viewModel.package == nil ? "选择 IPA" : "重新选择", systemImage: "doc.zipper")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(LabPrimaryButtonStyle())
                .disabled(viewModel.isWorking)
            }
        }
    }

    private func basicCard(_ pkg: IPAPackage) -> some View {
        LabCard(title: "应用信息", icon: "info.circle") {
            VStack(spacing: 0) {
                InfoRow(label: "名称", value: pkg.info.displayName ?? "—")
                InfoRow(label: "Bundle ID", value: pkg.info.bundleIdentifier ?? "—", monospaced: true)
                InfoRow(label: "版本", value: "\(pkg.info.version ?? "—") (\(pkg.info.build ?? "—"))")
                InfoRow(label: "最低系统版本", value: pkg.info.minimumOSVersion ?? "—")
                InfoRow(label: "主可执行文件", value: pkg.info.executableName ?? "—", monospaced: true)
                InfoRow(label: "包大小", value: "\(pkg.compressedSizeDisplay) → 解压 \(pkg.uncompressedSizeDisplay)")
                InfoRow(label: "文件总数", value: "\(pkg.fileCount)")
                InfoRow(label: "包 SHA-256", value: Hashing.short(pkg.sha256, length: 24), monospaced: true)
            }
        }
    }

    private func entitlementsCard(_ analysis: AppAnalyzer.Analysis) -> some View {
        LabCard(title: "权限声明与签名信息", icon: "checkmark.shield") {
            VStack(alignment: .leading, spacing: 10) {
                if analysis.provision.isEmpty {
                    Text("未在归档中找到 embedded.mobileprovision，或该文件不含可解析的授权信息。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(Array(analysis.provision.keys.sorted()), id: \.self) { key in
                        VStack(alignment: .leading, spacing: 3) {
                            Text(key)
                                .font(.caption.weight(.semibold))
                                .foregroundStyle(key.hasPrefix("Entitlement") ? LabTheme.accent : LabTheme.primaryText)
                            Text(analysis.provision[key] ?? "")
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                                .textSelection(.enabled)
                        }
                        .padding(.vertical, 3)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }

                if !analysis.declaredPermissions.isEmpty {
                    Divider().background(LabTheme.stroke)
                    Text("Info.plist 中声明的隐私用途说明")
                        .font(.caption.weight(.semibold))
                    ForEach(analysis.declaredPermissions, id: \.key) { item in
                        VStack(alignment: .leading, spacing: 2) {
                            Text(item.key)
                                .font(.caption2.monospaced())
                                .foregroundStyle(LabTheme.accent)
                            Text(item.value)
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        }
                        .padding(.vertical, 2)
                    }
                }
            }
        }
    }

    private func librariesCard(_ analysis: AppAnalyzer.Analysis) -> some View {
        LabCard(title: "动态库与 Framework（\(analysis.libraries.count)）", icon: "square.stack.3d.up") {
            VStack(alignment: .leading, spacing: 8) {
                if analysis.libraries.isEmpty {
                    Text("归档中未发现动态库或 Framework。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(analysis.libraries.prefix(80), id: \.path) { lib in
                        HStack(alignment: .top, spacing: 8) {
                            Image(systemName: lib.path.lowercased().hasSuffix(".dylib") ? "doc.badge.gearshape" : "cube.box")
                                .font(.caption2)
                                .foregroundStyle(LabTheme.warning)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(lib.path)
                                    .font(.caption2.monospaced())
                                    .lineLimit(2)
                                    .truncationMode(.middle)
                                Text(lib.sizeDisplay)
                                    .font(.caption2)
                                    .foregroundStyle(.tertiary)
                            }
                        }
                    }
                    if analysis.libraries.count > 80 {
                        Text("另有 \(analysis.libraries.count - 80) 项未显示")
                            .font(.caption2)
                            .foregroundStyle(.tertiary)
                    }
                }
            }
        }
    }

    private func resourcesCard(_ analysis: AppAnalyzer.Analysis) -> some View {
        LabCard(title: "资源结构", icon: "square.grid.2x2") {
            VStack(alignment: .leading, spacing: 8) {
                ForEach(analysis.typeBreakdown.prefix(20), id: \.ext) { item in
                    HStack {
                        Text(".\(item.ext)")
                            .font(.caption.monospaced())
                            .foregroundStyle(LabTheme.accent)
                            .frame(width: 70, alignment: .leading)
                        Text("\(item.count) 个")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        Spacer()
                        Text(ByteCountFormatter.string(fromByteCount: Int64(item.bytes), countStyle: .file))
                            .font(.caption.monospacedDigit())
                            .foregroundStyle(.tertiary)
                    }
                    Divider().background(LabTheme.stroke)
                }

                if !analysis.suspiciousPaths.isEmpty {
                    Text("需要注意的路径")
                        .font(.caption.weight(.semibold))
                        .padding(.top, 4)
                    ForEach(analysis.suspiciousPaths, id: \.self) { path in
                        HStack(spacing: 6) {
                            Image(systemName: "exclamationmark.triangle")
                                .font(.caption2)
                                .foregroundStyle(LabTheme.warning)
                            Text(path)
                                .font(.caption2.monospaced())
                                .lineLimit(1)
                                .truncationMode(.middle)
                        }
                    }
                }
            }
        }
    }

    private func plistCard(_ pkg: IPAPackage) -> some View {
        LabCard(title: "Info.plist 全部键（\(pkg.info.rawEntries.count)）", icon: "list.bullet") {
            VStack(alignment: .leading, spacing: 6) {
                ForEach(pkg.info.rawEntries.prefix(60), id: \.key) { item in
                    VStack(alignment: .leading, spacing: 2) {
                        Text(item.key)
                            .font(.caption2.monospaced())
                            .foregroundStyle(LabTheme.accent)
                        Text(item.value)
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                            .lineLimit(3)
                            .textSelection(.enabled)
                    }
                    .padding(.vertical, 2)
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
                if pkg.info.rawEntries.count > 60 {
                    Text("另有 \(pkg.info.rawEntries.count - 60) 个键未显示")
                        .font(.caption2)
                        .foregroundStyle(.tertiary)
                }
            }
        }
    }
}
