//
//  AppAnalyzerViewModel.swift
//  iOS Lab — 应用行为分析状态
//

import Foundation
import Combine
import SwiftUI
import UniformTypeIdentifiers

enum AppAnalyzer {

    struct Analysis {
        var provision: [String: String] = [:]
        var libraries: [IPAFileItem] = []
        var typeBreakdown: [(ext: String, count: Int, bytes: UInt64)] = []
        var suspiciousPaths: [String] = []
        var declaredPermissions: [(key: String, value: String)] = []
        var reportText: String = ""
    }

    /// 隐私用途说明键 → 中文含义
    static let privacyKeys: [String: String] = [
        "NSCameraUsageDescription": "相机",
        "NSMicrophoneUsageDescription": "麦克风",
        "NSPhotoLibraryUsageDescription": "照片库读取",
        "NSPhotoLibraryAddUsageDescription": "照片库写入",
        "NSContactsUsageDescription": "通讯录",
        "NSCalendarsUsageDescription": "日历",
        "NSRemindersUsageDescription": "提醒事项",
        "NSLocationWhenInUseUsageDescription": "使用期间定位",
        "NSLocationAlwaysAndWhenInUseUsageDescription": "始终定位",
        "NSLocationAlwaysUsageDescription": "始终定位（旧）",
        "NSBluetoothAlwaysUsageDescription": "蓝牙",
        "NSBluetoothPeripheralUsageDescription": "蓝牙（外设）",
        "NSMotionUsageDescription": "运动与健身",
        "NSHealthShareUsageDescription": "健康数据读取",
        "NSHealthUpdateUsageDescription": "健康数据写入",
        "NSFaceIDUsageDescription": "面容 ID",
        "NSSpeechRecognitionUsageDescription": "语音识别",
        "NSUserTrackingUsageDescription": "跨 App 跟踪",
        "NSLocalNetworkUsageDescription": "本地网络",
        "NSNearbyInteractionUsageDescription": "附近交互",
        "NSFileProviderDomainUsageDescription": "文件提供程序"
    ]

    /// 静态分析中值得留意的路径特征
    static let suspiciousPatterns: [(pattern: String, reason: String)] = [
        ("/Library/MobileSubstrate/", "越狱环境插件路径"),
        ("MobileSubstrate", "越狱环境插件引用"),
        ("CydiaSubstrate", "越狱环境插件引用"),
        ("substitute", "越狱环境插件引用"),
        ("libhooker", "越狱环境插件引用"),
        ("ellekit", "越狱环境插件引用"),
        ("Extensions/", "App Extension 入口"),
        ("Watch/", "Watch App 内容"),
        ("PlugIns/", "插件目录"),
        ("embedded.mobileprovision", "内嵌描述文件"),
        (".dylib", "动态库")
    ]
}

@MainActor
final class AppAnalyzerViewModel: ObservableObject {

    @Published var package: IPAPackage?
    @Published var analysis: AppAnalyzer.Analysis?
    @Published var isWorking = false
    @Published var progress: Double = 0
    @Published var progressMessage = ""
    @Published var errorMessage: String?
    @Published var isPicking = false
    @Published var shareItem: ShareItem?

    private var reportURL: URL?

    var allowedTypes: [UTType] {
        var types: [UTType] = []
        if let ipa = UTType(filenameExtension: "ipa") { types.append(ipa) }
        if let zip = UTType(filenameExtension: "zip") { types.append(zip) }
        types.append(.data)
        return types
    }

    func analyze(url: URL, model: LabAppModel) {
        let name = url.lastPathComponent
        model.diagnostics.info("应用分析", "开始分析：\(name)")

        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }

        isWorking = true
        progress = 0
        progressMessage = "正在读取归档…"
        errorMessage = nil
        analysis = nil

        Task.detached(priority: .userInitiated) {
            do {
                let local = try Self.importToSandbox(url: url)

                let pkg = try IPALoader.load(url: local, computeHashes: false) { pct, msg in
                    Task { @MainActor in
                        self.progress = pct * 0.7
                        self.progressMessage = msg
                    }
                }
                let archive = try IPAArchive(url: local)

                await MainActor.run {
                    self.progress = 0.75
                    self.progressMessage = "正在解析签名与权限声明…"
                }

                var result = AppAnalyzer.Analysis()
                result.provision = IPALoader.extractProvisionEntitlements(archive: archive)
                result.libraries = pkg.dynamicLibraries
                result.typeBreakdown = pkg.typeBreakdown()

                // 隐私用途说明
                if let app = pkg.appDirectory, let entry = archive.entry(at: app + "/Info.plist"),
                   let data = try? archive.data(for: entry),
                   let plist = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil),
                   let dict = plist as? [String: Any] {
                    for key in AppAnalyzer.privacyKeys.keys.sorted() {
                        if let value = dict[key] as? String {
                            result.declaredPermissions.append((
                                key: "\(key)（\(AppAnalyzer.privacyKeys[key] ?? "")）",
                                value: value
                            ))
                        }
                    }
                }

                // 需要注意的路径
                var flagged: [String] = []
                for file in pkg.files {
                    for pattern in AppAnalyzer.suspiciousPatterns
                    where file.path.contains(pattern.pattern) && !flagged.contains(file.path) {
                        flagged.append(file.path)
                        break
                    }
                }
                result.suspiciousPaths = Array(flagged.prefix(50))
                result.reportText = Self.makeReport(pkg: pkg, analysis: result)

                let report = Self.writeReport(result.reportText)

                await MainActor.run {
                    self.package = pkg
                    self.analysis = result
                    self.reportURL = report
                    self.isWorking = false
                    self.progress = 0
                    self.progressMessage = ""
                    model.diagnostics.success(
                        "应用分析",
                        "完成：\(pkg.info.bundleIdentifier ?? name)，动态库 \(result.libraries.count) 项，"
                            + "权限声明 \(result.declaredPermissions.count) 项"
                    )
                }

            } catch {
                await MainActor.run {
                    self.isWorking = false
                    self.errorMessage = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
                    model.diagnostics.error("应用分析", "失败：\(error.localizedDescription)")
                }
            }
        }
    }

    func shareReport() {
        guard let url = reportURL else { return }
        shareItem = ShareItem(url: url)
    }

    // MARK: - 报告

    nonisolated private static func makeReport(pkg: IPAPackage, analysis: AppAnalyzer.Analysis) -> String {
        let df = DateFormatter()
        df.dateFormat = "yyyy-MM-dd HH:mm:ss"

        var lines: [String] = []
        lines.append("iOS Lab — 应用行为分析报告")
        lines.append("生成时间：\(df.string(from: Date()))")
        lines.append(String(repeating: "=", count: 50))
        lines.append("")
        lines.append("【应用信息】")
        lines.append("  文件名　　：\(pkg.fileName)")
        lines.append("  显示名称　：\(pkg.info.displayName ?? "—")")
        lines.append("  Bundle ID ：\(pkg.info.bundleIdentifier ?? "—")")
        lines.append("  版本　　　：\(pkg.info.version ?? "—") (\(pkg.info.build ?? "—"))")
        lines.append("  最低系统　：\(pkg.info.minimumOSVersion ?? "—")")
        lines.append("  可执行文件：\(pkg.info.executableName ?? "—")")
        lines.append("  包大小　　：\(pkg.compressedSizeDisplay)（解压后 \(pkg.uncompressedSizeDisplay)）")
        lines.append("  文件总数　：\(pkg.fileCount)")
        lines.append("  包 SHA-256：\(pkg.sha256)")
        lines.append("")
        lines.append("【签名与授权信息】")
        if analysis.provision.isEmpty {
            lines.append("  未解析到 embedded.mobileprovision 中的授权信息")
        } else {
            for key in analysis.provision.keys.sorted() {
                lines.append("  \(key): \(analysis.provision[key] ?? "")")
            }
        }
        lines.append("")
        lines.append("【隐私权限声明（\(analysis.declaredPermissions.count) 项）】")
        if analysis.declaredPermissions.isEmpty {
            lines.append("  无")
        } else {
            for item in analysis.declaredPermissions {
                lines.append("  \(item.key)")
                lines.append("      \(item.value)")
            }
        }
        lines.append("")
        lines.append("【动态库与 Framework（\(analysis.libraries.count) 项）】")
        if analysis.libraries.isEmpty {
            lines.append("  无")
        } else {
            for lib in analysis.libraries {
                lines.append("  \(lib.path)　\(lib.sizeDisplay)")
            }
        }
        lines.append("")
        lines.append("【资源类型分布】")
        for item in analysis.typeBreakdown.prefix(40) {
            lines.append("  .\(item.ext)　\(item.count) 个　"
                + ByteCountFormatter.string(fromByteCount: Int64(item.bytes), countStyle: .file))
        }
        lines.append("")
        lines.append("【需要留意的路径（\(analysis.suspiciousPaths.count) 项）】")
        if analysis.suspiciousPaths.isEmpty {
            lines.append("  无")
        } else {
            for path in analysis.suspiciousPaths {
                lines.append("  \(path)")
            }
        }
        lines.append("")
        lines.append(String(repeating: "=", count: 50))
        lines.append("说明：以上均为静态分析结果，来源于归档内可读的声明内容。")
        lines.append("读取到某项权限声明，不代表该权限在运行时生效；")
        lines.append("本报告不构成对签名有效性的验证结论。")

        return lines.joined(separator: "\n")
    }

    nonisolated private static func writeReport(_ text: String) -> URL? {
        let fm = FileManager.default
        let base = fm.urls(for: .cachesDirectory, in: .userDomainMask).first ?? fm.temporaryDirectory
        let dir = base.appendingPathComponent("Reports", isDirectory: true)
        try? fm.createDirectory(at: dir, withIntermediateDirectories: true)
        let df = DateFormatter()
        df.dateFormat = "yyyyMMdd_HHmmss"
        let url = dir.appendingPathComponent("应用分析报告_\(df.string(from: Date())).txt")
        do {
            try text.write(to: url, atomically: true, encoding: .utf8)
            return url
        } catch {
            return nil
        }
    }

    nonisolated private static func importToSandbox(url: URL) throws -> URL {
        let fm = FileManager.default
        let base = fm.urls(for: .cachesDirectory, in: .userDomainMask).first ?? fm.temporaryDirectory
        let dir = base.appendingPathComponent("IPAImports", isDirectory: true)
        try fm.createDirectory(at: dir, withIntermediateDirectories: true)
        let target = dir.appendingPathComponent(UUID().uuidString + "_" + url.lastPathComponent)
        if fm.fileExists(atPath: target.path) { try fm.removeItem(at: target) }
        try fm.copyItem(at: url, to: target)
        return target
    }
}
