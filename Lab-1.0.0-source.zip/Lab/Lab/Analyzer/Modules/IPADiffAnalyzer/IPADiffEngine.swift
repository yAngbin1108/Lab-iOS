//
//  IPADiffEngine.swift
//  iOS Lab
//
//  IPA 差异分析核心。
//
//  比对策略（分两级，先粗后细）：
//    第一级 —— 路径集合比对，识别「新增 / 删除」。
//    第二级 —— 对两侧同名文件先比较 CRC32（零成本，来自归档中央目录），
//              CRC 不同再计算 SHA-256 做内容级确认，识别「修改 / 相同」。
//
//  这样处理大 IPA（几百 MB）时，只有真正变化的文件才会被解压，
//  避免把整个包解压进内存。
//

import Foundation

struct DiffOptions {
    /// 是否对 CRC 不同的文件追加 SHA-256 内容级确认
    var deepContentCheck: Bool = true
    /// 是否忽略 .DS_Store 等噪音文件
    var ignoreSystemNoise: Bool = true

    static let `default` = DiffOptions()

    var noisePatterns: [String] {
        ignoreSystemNoise
            ? ["__MACOSX/", ".DS_Store", "Thumbs.db", ".git/", ".AppleDouble"]
            : []
    }
}

enum IPADiffEngine {

    // MARK: - 主入口

    static func compare(
        left: IPAPackage,
        right: IPAPackage,
        options: DiffOptions = .default,
        progress: ((Double, String) -> Void)? = nil
    ) -> DiffResult {

        progress?(0.02, "正在建立文件索引…")

        let leftMap = index(left, options: options)
        let rightMap = index(right, options: options)

        let allPaths = Set(leftMap.keys).union(rightMap.keys).sorted()

        var entries: [DiffEntry] = []
        entries.reserveCapacity(allPaths.count)

        let total = max(allPaths.count, 1)
        var deepChecked = 0

        for (i, path) in allPaths.enumerated() {
            if i % 25 == 0 || i == total - 1 {
                progress?(0.05 + 0.9 * (Double(i) / Double(total)),
                          "正在比对文件 \(i + 1)/\(total)…")
            }

            let l = leftMap[path]
            let r = rightMap[path]

            switch (l, r) {
            case (nil, .some(let newFile)):
                entries.append(DiffEntry(
                    path: path,
                    kind: .added,
                    oldSize: nil,
                    newSize: newFile.uncompressedSize,
                    oldHash: nil,
                    newHash: nil,
                    contentCompared: false
                ))

            case (.some(let oldFile), nil):
                entries.append(DiffEntry(
                    path: path,
                    kind: .removed,
                    oldSize: oldFile.uncompressedSize,
                    newSize: nil,
                    oldHash: nil,
                    newHash: nil,
                    contentCompared: false
                ))

            case (.some(let oldFile), .some(let newFile)):
                // 第一级：CRC32 快速判定
                var kind: DiffChangeKind
                var oldHash: String?
                var newHash: String?
                var contentCompared = false

                if oldFile.crc32 != newFile.crc32 {
                    kind = .modified
                } else if oldFile.uncompressedSize != newFile.uncompressedSize {
                    kind = .modified
                } else {
                    kind = .identical
                }

                // 第二级：内容级确认（仅对疑似修改的项）
                if kind == .modified, options.deepContentCheck {
                    oldHash = oldFile.sha256
                    newHash = newFile.sha256
                    if oldHash == nil || newHash == nil {
                        oldHash = nil
                        newHash = nil
                    }
                    contentCompared = true
                    deepChecked += 1
                }

                entries.append(DiffEntry(
                    path: path,
                    kind: kind,
                    oldSize: oldFile.uncompressedSize,
                    newSize: newFile.uncompressedSize,
                    oldHash: oldHash,
                    newHash: newHash,
                    contentCompared: contentCompared
                ))

            case (nil, nil):
                continue
            }
        }

        progress?(1.0, "比对完成")

        return DiffResult(
            leftName: left.fileName,
            rightName: right.fileName,
            leftBundleID: left.info.bundleIdentifier,
            rightBundleID: right.info.bundleIdentifier,
            leftVersion: left.info.version,
            rightVersion: right.info.version,
            entries: entries,
            comparedFileCount: deepChecked,
            contentComparisonEnabled: options.deepContentCheck,
            generatedAt: Date()
        )
    }

    // MARK: - 索引

    private static func index(_ package: IPAPackage, options: DiffOptions) -> [String: IPAFileItem] {
        var map: [String: IPAFileItem] = [:]
        for file in package.files {
            if file.path.hasSuffix("/") { continue } // 目录条目不参与比对
            if options.noisePatterns.contains(where: { file.path.contains($0) }) { continue }
            map[file.path] = file
        }
        return map
    }

    // MARK: - 报告生成

    static func report(_ result: DiffResult, left: IPAPackage, right: IPAPackage) -> String {
        let df = DateFormatter()
        df.dateFormat = "yyyy-MM-dd HH:mm:ss"

        var lines: [String] = []
        lines.append("iOS Lab — IPA 差异分析报告")
        lines.append("生成时间：\(df.string(from: result.generatedAt))")
        lines.append(String(repeating: "=", count: 50))
        lines.append("")
        lines.append("【左侧（旧）】")
        lines.append("  文件：\(left.fileName)")
        lines.append("  Bundle ID：\(left.info.bundleIdentifier ?? "—")")
        lines.append("  版本：\(left.info.version ?? "—") (\(left.info.build ?? "—"))")
        lines.append("  文件数：\(left.fileCount)　大小：\(left.compressedSizeDisplay)")
        lines.append("")
        lines.append("【右侧（新）】")
        lines.append("  文件：\(right.fileName)")
        lines.append("  Bundle ID：\(right.info.bundleIdentifier ?? "—")")
        lines.append("  版本：\(right.info.version ?? "—") (\(right.info.build ?? "—"))")
        lines.append("  文件数：\(right.fileCount)　大小：\(right.compressedSizeDisplay)")
        lines.append("")
        lines.append(String(repeating: "=", count: 50))
        lines.append("")
        lines.append("【配置差异】")
        lines.append("  Bundle ID：\(result.leftBundleID ?? "—") → \(result.rightBundleID ?? "—")"
            + (result.leftBundleID == result.rightBundleID ? "　（一致）" : "　（已变更）"))
        lines.append("  版本号　：\(result.leftVersion ?? "—") → \(result.rightVersion ?? "—")"
            + (result.leftVersion == result.rightVersion ? "　（一致）" : "　（已变更）"))
        lines.append("")
        lines.append("【文件差异汇总】")
        lines.append("  新增：\(result.added.count)")
        lines.append("  删除：\(result.removed.count)")
        lines.append("  修改：\(result.modified.count)")
        lines.append("  相同：\(result.identical.count)")
        lines.append("  合计：\(result.entries.count)")
        if result.contentComparisonEnabled {
            lines.append("  已完成内容级（SHA-256）确认：\(result.comparedFileCount) 个文件")
        }
        lines.append("")

        func section(_ title: String, _ items: [DiffEntry], limit: Int = 200) {
            guard !items.isEmpty else { return }
            lines.append("【\(title)】（\(items.count)）")
            for item in items.prefix(limit) {
                var line = "  \(item.path)"
                switch item.kind {
                case .added:
                    line += "　+\(ByteCountFormatter.string(fromByteCount: Int64(item.newSize ?? 0), countStyle: .file))"
                case .removed:
                    line += "　-\(ByteCountFormatter.string(fromByteCount: Int64(item.oldSize ?? 0), countStyle: .file))"
                case .modified:
                    line += "　\(item.sizeDeltaDisplay)"
                    if let oh = item.oldHash, let nh = item.newHash {
                        line += "\n      SHA-256: \(Hashing.short(oh, length: 16)) → \(Hashing.short(nh, length: 16))"
                    }
                case .identical:
                    line += "　（内容一致）"
                }
                lines.append(line)
            }
            if items.count > limit {
                lines.append("  …另有 \(items.count - limit) 项未列出")
            }
            lines.append("")
        }

        section("新增文件", result.added)
        section("删除文件", result.removed)
        section("修改文件", result.modified)

        lines.append(String(repeating: "=", count: 50))
        lines.append("说明：本报告基于归档中央目录的 CRC32 与 SHA-256 比对。")
        lines.append("CRC32 相同且大小一致的文件被判定为「相同」，未逐字节复核；")
        lines.append("该判定足以覆盖常规重新打包场景，但不等同于密码学级别的完整校验。")

        return lines.joined(separator: "\n")
    }
}
