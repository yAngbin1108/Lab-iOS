//
//  IPADiffView.swift
//  iOS Lab — IPA 差异分析模块
//

import SwiftUI
import UniformTypeIdentifiers

struct IPADiffView: View {

    @EnvironmentObject private var model: LabAppModel
    @StateObject private var viewModel = IPADiffViewModel()

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: LabTheme.sectionSpacing) {

                LabSectionHeader(
                    title: "IPA 差异分析",
                    subtitle: "比较两个 IPA 的文件增删改，输出可分享的差异报告",
                    icon: "arrow.left.arrow.right.square"
                )

                filePickers

                optionsCard

                actionRow

                if viewModel.isWorking {
                    LabProgressCard(
                        progress: viewModel.progress,
                        message: viewModel.progressMessage
                    )
                }

                if let error = viewModel.errorMessage {
                    LabMessageCard(level: .error, title: "分析失败", message: error)
                }

                if let result = viewModel.result {
                    summaryCard(result)
                    changesCard(result)
                }

                LabNoticeCard(
                    title: "关于比对精度的说明",
                    message: """
                    比对分两级：先按路径集合识别新增/删除；再对同名文件比较归档中的 CRC32 与大小，\
                    CRC 不同的文件会进一步计算 SHA-256 做内容级确认。

                    CRC32 相同且大小一致的文件被判定为「相同」，不逐字节复核。\
                    这足以覆盖常规重新打包、改配置、换资源的场景，但不等同于密码学级别的完整校验。
                    """
                )
            }
            .padding(LabTheme.pagePadding)
        }
        .background(LabTheme.background.ignoresSafeArea())
        .navigationTitle("IPA 差异分析")
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                if viewModel.result != nil {
                    Button {
                        viewModel.shareReport()
                    } label: {
                        Label("分享报告", systemImage: "square.and.arrow.up")
                    }
                }
            }
        }
        .sheet(isPresented: $viewModel.isPickingLeft) {
            DocumentPicker(contentTypes: [.item]) { urls in
                viewModel.isPickingLeft = false
                if let url = urls.first {
                    viewModel.attach(url: url, isLeft: true, model: model)
                }
            }
        }
        .sheet(isPresented: $viewModel.isPickingRight) {
            DocumentPicker(contentTypes: [.item]) { urls in
                viewModel.isPickingRight = false
                if let url = urls.first {
                    viewModel.attach(url: url, isLeft: false, model: model)
                }
            }
        }
        .sheet(item: $viewModel.shareItem) { item in
            ShareSheetView(items: [item.url])
        }
    }

    // MARK: - 子视图

    private var filePickers: some View {
        VStack(spacing: 12) {
            FilePickerRow(
                title: "左侧文件（旧）",
                sideLabel: "旧",
                fileName: viewModel.leftPackage?.fileName,
                detail: leftDetail,
                isBusy: viewModel.isWorking,
                action: { viewModel.isPickingLeft = true }
            )

            HStack {
                Spacer()
                Image(systemName: "arrow.down")
                    .font(.footnote.weight(.semibold))
                    .foregroundStyle(.tertiary)
                Spacer()
            }

            FilePickerRow(
                title: "右侧文件（新）",
                sideLabel: "新",
                fileName: viewModel.rightPackage?.fileName,
                detail: rightDetail,
                isBusy: viewModel.isWorking,
                action: { viewModel.isPickingRight = true }
            )
        }
    }

    private var leftDetail: String? {
        guard let p = viewModel.leftPackage else { return nil }
        return "\(p.fileCount) 个文件 · \(p.compressedSizeDisplay) · v\(p.info.version ?? "—")"
    }

    private var rightDetail: String? {
        guard let p = viewModel.rightPackage else { return nil }
        return "\(p.fileCount) 个文件 · \(p.compressedSizeDisplay) · v\(p.info.version ?? "—")"
    }

    private var optionsCard: some View {
        LabCard(title: "分析选项", icon: "slider.horizontal.3") {
            VStack(alignment: .leading, spacing: 14) {
                Toggle(isOn: $viewModel.deepContentCheck) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("内容级确认（SHA-256）")
                            .font(.subheadline.weight(.medium))
                        Text("对 CRC 不同的文件计算内容哈希，结论更可靠，速度略慢")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
                .tint(LabTheme.accent)
                .disabled(viewModel.isWorking)

                Divider().background(LabTheme.stroke)

                Toggle(isOn: $viewModel.ignoreNoise) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("忽略系统噪音文件")
                            .font(.subheadline.weight(.medium))
                        Text("跳过 __MACOSX、.DS_Store、.git 等非应用内容")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
                .tint(LabTheme.accent)
                .disabled(viewModel.isWorking)
            }
        }
    }

    private var actionRow: some View {
        VStack(spacing: 10) {
            // 告诉用户下一步该干什么，而不是让按钮一直灰着让人猜
            if let hint = nextStepHint {
                HStack(spacing: 6) {
                    Image(systemName: "info.circle")
                        .font(.caption2)
                    Text(hint)
                        .font(.caption2)
                    Spacer()
                }
                .foregroundStyle(LabTheme.secondaryText)
            }

            HStack(spacing: 12) {
                Button {
                    viewModel.startComparison(model: model)
                } label: {
                    Label("开始比对", systemImage: "play.fill")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(LabPrimaryButtonStyle())
                .disabled(!viewModel.canCompare)

                Button {
                    viewModel.reset()
                } label: {
                    Label("重置", systemImage: "arrow.counterclockwise")
                }
                .buttonStyle(LabSecondaryButtonStyle())
                .disabled(viewModel.isWorking)
            }
        }
    }

    /// 根据当前选了几个文件，提示下一步该做什么
    private var nextStepHint: String? {
        if viewModel.isWorking { return nil }
        switch (viewModel.leftPackage != nil, viewModel.rightPackage != nil) {
        case (false, false):
            return "先选左侧的文件（旧版本）"
        case (true, false):
            return "左侧已就绪，再选右侧的文件（新版本）"
        case (false, true):
            return "右侧已就绪，再选左侧的文件（旧版本）"
        case (true, true):
            return viewModel.result == nil ? "两个文件都选好了，点「开始比对」" : nil
        }
    }

    private func summaryCard(_ result: DiffResult) -> some View {
        LabCard(title: "比对结果", icon: "chart.bar.doc.horizontal") {
            VStack(spacing: 12) {
                HStack(spacing: 10) {
                    StatTile(title: "新增", value: "\(result.added.count)", tint: LabTheme.success)
                    StatTile(title: "删除", value: "\(result.removed.count)", tint: LabTheme.danger)
                    StatTile(title: "修改", value: "\(result.modified.count)", tint: LabTheme.warning)
                }
                HStack(spacing: 10) {
                    StatTile(title: "相同", value: "\(result.identical.count)", tint: LabTheme.secondaryText)
                    StatTile(title: "内容级确认", value: "\(result.comparedFileCount)", tint: LabTheme.accent)
                }

                if result.configChanged {
                    LabMessageCard(
                        level: .warning,
                        title: "配置已变更",
                        message: "Bundle ID：\(result.leftBundleID ?? "—") → \(result.rightBundleID ?? "—")\n"
                            + "版本号：\(result.leftVersion ?? "—") → \(result.rightVersion ?? "—")"
                    )
                }
            }
        }
    }

    private func changesCard(_ result: DiffResult) -> some View {
        LabCard(title: "差异明细", icon: "list.bullet.rectangle") {
            VStack(alignment: .leading, spacing: 16) {
                if result.entries.isEmpty {
                    Text("两个包的文件结构完全一致。")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                } else {
                    changeGroup("新增文件", result.added, tint: LabTheme.success)
                    changeGroup("删除文件", result.removed, tint: LabTheme.danger)
                    changeGroup("修改文件", result.modified, tint: LabTheme.warning)
                }
            }
        }
    }

    @ViewBuilder
    private func changeGroup(_ title: String, _ items: [DiffEntry], tint: Color) -> some View {
        if !items.isEmpty {
            VStack(alignment: .leading, spacing: 8) {
                HStack(spacing: 6) {
                    Text(title)
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(tint)
                    Text("\(items.count)")
                        .font(.caption.monospacedDigit())
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(tint.opacity(0.15))
                        .clipShape(Capsule())
                        .foregroundStyle(tint)
                }
                ForEach(items.prefix(60)) { item in
                    DiffRow(item: item)
                }
                if items.count > 60 {
                    Text("另有 \(items.count - 60) 项未显示，完整列表见导出的报告")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
        }
    }

    // MARK: - 文件选择

}

// MARK: - 差异行

private struct DiffRow: View {
    let item: DiffEntry

    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            HStack(alignment: .top, spacing: 6) {
                Image(systemName: item.kind.symbol)
                    .font(.caption)
                    .foregroundStyle(tint)
                Text(item.path)
                    .font(.caption.monospaced())
                    .foregroundStyle(LabTheme.primaryText)
                    .lineLimit(2)
                    .truncationMode(.middle)
            }
            HStack(spacing: 10) {
                Text(item.kind.rawValue)
                    .font(.caption2.weight(.medium))
                    .foregroundStyle(tint)
                if item.kind == .modified || item.kind == .added || item.kind == .removed {
                    Text(item.sizeDeltaDisplay)
                        .font(.caption2.monospacedDigit())
                        .foregroundStyle(.secondary)
                }
                if let oh = item.oldHash, let nh = item.newHash {
                    Text("\(Hashing.short(oh, length: 8)) → \(Hashing.short(nh, length: 8))")
                        .font(.caption2.monospaced())
                        .foregroundStyle(.tertiary)
                }
            }
            .padding(.leading, 18)
        }
        .padding(.vertical, 4)
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var tint: Color {
        switch item.kind {
        case .added: return LabTheme.success
        case .removed: return LabTheme.danger
        case .modified: return LabTheme.warning
        case .identical: return LabTheme.secondaryText
        }
    }
}

// MARK: - 文件选择行

private struct FilePickerRow: View {
    let title: String
    let sideLabel: String
    let fileName: String?
    let detail: String?
    let isBusy: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 14) {
                ZStack {
                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                        .fill(fileName == nil ? LabTheme.cardAlt : LabTheme.accent.opacity(0.18))
                    Text(sideLabel)
                        .font(.caption.weight(.bold))
                        .foregroundStyle(fileName == nil ? LabTheme.secondaryText : LabTheme.accent)
                }
                .frame(width: 44, height: 44)

                VStack(alignment: .leading, spacing: 3) {
                    Text(title)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Text(fileName ?? "点击选择 .ipa 文件")
                        .font(.subheadline.weight(.medium))
                        .foregroundStyle(fileName == nil ? LabTheme.secondaryText : LabTheme.primaryText)
                        .lineLimit(1)
                        .truncationMode(.middle)
                    if let detail {
                        Text(detail)
                            .font(.caption2)
                            .foregroundStyle(.tertiary)
                    }
                }

                Spacer()

                Image(systemName: "chevron.right")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.tertiary)
            }
            .padding(14)
            .background(LabTheme.card)
            .clipShape(RoundedRectangle(cornerRadius: LabTheme.cornerRadius, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: LabTheme.cornerRadius, style: .continuous)
                    .stroke(LabTheme.stroke, lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
        .disabled(isBusy)
        .opacity(isBusy ? 0.6 : 1)
    }
}
