//
//  IPAModel.swift
//  iOS Lab
//
//  IPA / App 包的结构化描述。
//

import Foundation

// MARK: - 单个文件条目

struct IPAFileItem: Identifiable, Hashable {
    let id = UUID()
    let path: String
    let compressedSize: UInt64
    let uncompressedSize: UInt64
    let crc32: UInt32
    let compressionMethod: UInt16
    let modDate: Date?
    /// 内容 SHA-256。仅对已计算过的条目有值
    var sha256: String?

    var sizeDisplay: String {
        ByteCountFormatter.string(fromByteCount: Int64(uncompressedSize), countStyle: .file)
    }

    var compressionDisplay: String {
        switch compressionMethod {
        case 0: return "Store"
        case 8: return "Deflate"
        default: return "#\(compressionMethod)"
        }
    }

    var fileExtension: String {
        let ext = (path as NSString).pathExtension.lowercased()
        return ext.isEmpty ? "（无扩展名）" : ext
    }

    var isExecutable: Bool {
        let lower = path.lowercased()
        return lower.hasSuffix(".dylib") || lower.hasSuffix(".framework")
            || lower.contains(".app/") && !lower.contains(".")
    }

    var shortHash: String? { sha256.map { Hashing.short($0) } }
}

// MARK: - Info.plist 摘要

struct IPAInfoSummary {
    var displayName: String?
    var bundleIdentifier: String?
    var version: String?
    var build: String?
    var minimumOSVersion: String?
    var platform: String?
    var executableName: String?
    var supportedDevices: [String] = []
    var urlSchemes: [String] = []
    var requiredCapabilities: [String] = []
    /// 原始 plist 全部键，供「应用行为分析」展开查看
    var rawKeys: [String] = []
    /// 二进制 plist 里出现的 Info.plist 相关键值对（字符串化）
    var rawEntries: [(key: String, value: String)] = []

    var isUsable: Bool { bundleIdentifier != nil || displayName != nil }
}

// MARK: - 解析后的 IPA 包

struct IPAPackage {
    let url: URL
    let fileName: String
    let fileSize: UInt64
    let sha256: String
    let files: [IPAFileItem]
    let info: IPAInfoSummary
    /// 入口 .app 目录，例如 Payload/iOSLab.app
    let appDirectory: String?

    var fileCount: Int { files.count }

    var compressedSizeDisplay: String {
        ByteCountFormatter.string(fromByteCount: Int64(fileSize), countStyle: .file)
    }

    var uncompressedSize: UInt64 {
        files.reduce(0) { $0 + $1.uncompressedSize }
    }

    var uncompressedSizeDisplay: String {
        ByteCountFormatter.string(fromByteCount: Int64(uncompressedSize), countStyle: .file)
    }

    var compressionRatioDisplay: String {
        guard uncompressedSize > 0 else { return "—" }
        let ratio = Double(fileSize) / Double(uncompressedSize) * 100
        return String(format: "%.1f%%", ratio)
    }

    /// 按扩展名分组统计
    func typeBreakdown() -> [(ext: String, count: Int, bytes: UInt64)] {
        var map: [String: (Int, UInt64)] = [:]
        for f in files where !f.path.hasSuffix("/") {
            let key = f.fileExtension
            var current = map[key] ?? (0, 0)
            current.0 += 1
            current.1 += f.uncompressedSize
            map[key] = current
        }
        return map.map { (ext: $0.key, count: $0.value.0, bytes: $0.value.1) }
            .sorted { $0.count > $1.count }
    }

    /// 动态库 / Framework 清单
    var dynamicLibraries: [IPAFileItem] {
        files.filter {
            let l = $0.path.lowercased()
            return l.hasSuffix(".dylib") || (l.contains(".framework/") && !l.hasSuffix("/"))
        }
    }

    /// 可执行文件候选
    var executables: [IPAFileItem] {
        files.filter { f in
            guard !f.path.hasSuffix("/") else { return false }
            let lower = f.path.lowercased()
            guard let app = appDirectory?.lowercased() else { return false }
            // .app 根目录下没有扩展名的文件通常是主可执行文件
            let relative = lower.replacingOccurrences(of: app + "/", with: "")
            return !relative.contains("/") && !relative.contains(".")
        }
    }
}

// MARK: - 差异结果

enum DiffChangeKind: String {
    case added = "新增"
    case removed = "删除"
    case modified = "修改"
    case identical = "相同"

    var symbol: String {
        switch self {
        case .added: return "plus.circle.fill"
        case .removed: return "minus.circle.fill"
        case .modified: return "pencil.circle.fill"
        case .identical: return "equal.circle"
        }
    }
}

struct DiffEntry: Identifiable {
    let id = UUID()
    let path: String
    let kind: DiffChangeKind
    /// 左（旧）大小
    let oldSize: UInt64?
    /// 右（新）大小
    let newSize: UInt64?
    let oldHash: String?
    let newHash: String?
    /// 是否已完成内容级（SHA-256）比对
    let contentCompared: Bool

    var sizeDeltaDisplay: String {
        guard let o = oldSize, let n = newSize else { return "—" }
        let delta = Int64(n) - Int64(o)
        if delta == 0 { return "无变化" }
        let sign = delta > 0 ? "+" : "-"
        return sign + ByteCountFormatter.string(fromByteCount: abs(delta), countStyle: .file)
    }
}

struct DiffResult {
    let leftName: String
    let rightName: String
    let leftBundleID: String?
    let rightBundleID: String?
    let leftVersion: String?
    let rightVersion: String?
    let entries: [DiffEntry]
    let comparedFileCount: Int
    let contentComparisonEnabled: Bool
    let generatedAt: Date

    var added: [DiffEntry] { entries.filter { $0.kind == .added } }
    var removed: [DiffEntry] { entries.filter { $0.kind == .removed } }
    var modified: [DiffEntry] { entries.filter { $0.kind == .modified } }
    var identical: [DiffEntry] { entries.filter { $0.kind == .identical } }

    var configChanged: Bool {
        leftBundleID != rightBundleID || leftVersion != rightVersion
    }
}
