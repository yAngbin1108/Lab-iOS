//
//  IPALoader.swift
//  iOS Lab
//
//  IPA 包读取与解析：文件清单、Info.plist 摘要、哈希计算。
//

import Foundation

enum IPALoaderError: LocalizedError {
    case archive(IPAArchiveError)
    case noPayload(String)
    case noInfoPlist
    case plistUnreadable

    var errorDescription: String? {
        switch self {
        case .archive(let e): return e.localizedDescription
        case .noPayload(let name): return "「\(name)」中没有找到 Payload/ 目录，可能不是有效的 IPA"
        case .noInfoPlist: return "未找到 Info.plist，无法读取应用信息"
        case .plistUnreadable: return "Info.plist 无法解析（格式不受支持或已加密）"
        }
    }
}

enum IPALoader {

    /// 读取 IPA 并生成结构化描述。
    /// - Parameters:
    ///   - url: IPA 文件地址
    ///   - computeHashes: 是否计算每个文件内容的 SHA-256（大包会较慢）
    ///   - hashFilter: 需要进行哈希比对的路径集合；为空表示全部计算
    ///   - progress: 进度回调（0…1，描述文本）
    static func load(
        url: URL,
        computeHashes: Bool,
        hashFilter: Set<String>? = nil,
        progress: ((Double, String) -> Void)? = nil
    ) throws -> IPAPackage {

        progress?(0.02, "正在读取归档目录…")

        let archive: IPAArchive
        do {
            archive = try IPAArchive(url: url)
        } catch let e as IPAArchiveError {
            throw IPALoaderError.archive(e)
        }

        let attrs = try? FileManager.default.attributesOfItem(atPath: url.path)
        let fileSize = (attrs?[.size] as? NSNumber)?.uint64Value ?? 0

        let payloadPrefix = "Payload/"
        guard archive.entries.contains(where: { $0.path.hasPrefix(payloadPrefix) }) else {
            throw IPALoaderError.noPayload(url.lastPathComponent)
        }

        // 1. 文件清单
        progress?(0.05, "正在整理文件清单…")
        var files: [IPAFileItem] = archive.entries.map { e in
            IPAFileItem(
                path: e.path,
                compressedSize: e.compressedSize,
                uncompressedSize: e.uncompressedSize,
                crc32: e.crc32,
                compressionMethod: e.compressionMethod,
                modDate: e.modDate,
                sha256: nil
            )
        }

        // 2. 找到 Payload/*.app
        let appDirectory = archive.entries
            .first { $0.path.hasPrefix(payloadPrefix) && $0.path.hasSuffix(".app/") }?
            .path
            .trimmingCharacters(in: CharacterSet(charactersIn: "/"))

        // 3. Info.plist 摘要
        progress?(0.12, "正在解析 Info.plist…")
        let info = try parseInfoPlist(archive: archive, appDirectory: appDirectory)

        // 4. 哈希计算
        if computeHashes {
            let targets = files.filter { item in
                guard !item.path.hasSuffix("/") else { return false }
                if let filter = hashFilter { return filter.contains(item.path) }
                return true
            }
            let total = max(targets.count, 1)
            for (index, item) in targets.enumerated() {
                if index % 8 == 0 || index == total - 1 {
                    let pct = 0.15 + 0.83 * (Double(index) / Double(total))
                    progress?(pct, "正在计算文件哈希 \(index + 1)/\(total)…")
                }
                guard let entry = archive.entry(at: item.path) else { continue }
                if let data = try? archive.data(for: entry),
                   let position = files.firstIndex(where: { $0.path == item.path }) {
                    files[position].sha256 = Hashing.sha256(data)
                }
            }
        }

        progress?(1.0, "解析完成")

        let fileHash: String
        if let attrs = try? FileManager.default.attributesOfItem(atPath: url.path),
           (attrs[.size] as? NSNumber)?.uint64Value ?? 0 < 40 * 1024 * 1024 {
            // 小文件直接整体哈希
            fileHash = (try? Hashing.sha256(fileAt: url)) ?? "—"
        } else {
            fileHash = (try? Hashing.sha256(fileAt: url)) ?? "—"
        }

        return IPAPackage(
            url: url,
            fileName: url.lastPathComponent,
            fileSize: fileSize,
            sha256: fileHash,
            files: files,
            info: info,
            appDirectory: appDirectory
        )
    }

    // MARK: - Info.plist

    static func parseInfoPlist(archive: IPAArchive, appDirectory: String?) throws -> IPAInfoSummary {
        var candidates: [String] = []
        if let app = appDirectory {
            candidates.append(app + "/Info.plist")
        }
        candidates.append(contentsOf: archive.entries
            .filter { $0.path.hasSuffix(".app/Info.plist") }
            .map { $0.path })

        guard let path = candidates.first(where: { archive.entry(at: $0) != nil }),
              let entry = archive.entry(at: path),
              let data = try? archive.data(for: entry) else {
            throw IPALoaderError.noInfoPlist
        }

        guard let plist = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil),
              let dict = plist as? [String: Any] else {
            throw IPALoaderError.plistUnreadable
        }

        var summary = IPAInfoSummary()
        summary.displayName = firstString(in: dict, keys: [
            "CFBundleDisplayName", "CFBundleName"
        ])
        summary.bundleIdentifier = dict["CFBundleIdentifier"] as? String
        summary.version = dict["CFBundleShortVersionString"] as? String
        summary.build = dict["CFBundleVersion"] as? String
        summary.minimumOSVersion = dict["MinimumOSVersion"] as? String
        summary.platform = firstString(in: dict, keys: [
            "CFBundleSupportedPlatforms", "DTPlatformName"
        ])
        summary.executableName = dict["CFBundleExecutable"] as? String
        summary.supportedDevices = dict["UISupportedDevices"] as? [String] ?? []
        summary.requiredCapabilities = dict["UIRequiredDeviceCapabilities"] as? [String] ?? []

        if let types = dict["CFBundleURLTypes"] as? [[String: Any]] {
            for type in types {
                if let schemes = type["CFBundleURLSchemes"] as? [String] {
                    summary.urlSchemes.append(contentsOf: schemes)
                }
            }
        }

        summary.rawKeys = dict.keys.sorted()

        // 关键键值对字符串化，供界面展示
        let interestingKeys = [
            "CFBundleIdentifier", "CFBundleShortVersionString", "CFBundleVersion",
            "CFBundleDisplayName", "CFBundleName", "CFBundleExecutable",
            "MinimumOSVersion", "CFBundleSupportedPlatforms", "CFBundlePackageType",
            "LSRequiresIPhoneOS", "UIRequiredDeviceCapabilities", "UISupportedDevices",
            "CFBundleURLTypes", "UIBackgroundModes", "NSAppTransportSecurity",
            "UIApplicationSceneManifest", "get-task-allow", "application-identifier",
            "com.apple.developer.team-identifier", "com.apple.developer.entitlements"
        ]

        for key in interestingKeys where dict[key] != nil {
            summary.rawEntries.append((key: key, value: stringify(dict[key]!)))
        }
        for key in summary.rawKeys where !interestingKeys.contains(key) {
            summary.rawEntries.append((key: key, value: stringify(dict[key]!)))
        }

        return summary
    }

    // MARK: - Entitlements（从嵌入的 mobileprovision / 归档中提取）

    /// 尝试从 IPA 中读取 embedded.mobileprovision 的 Entitlements 段
    static func extractProvisionEntitlements(archive: IPAArchive) -> [String: String] {
        guard let entry = archive.entries.first(where: { $0.path.hasSuffix("embedded.mobileprovision") }),
              let data = try? archive.data(for: entry) else { return [:] }

        // mobileprovision 是 CMS 包裹的 plist，定位 "<plist" ... "</plist>"
        guard let startRange = data.range(of: Data("<plist".utf8)),
              let endRange = data.range(of: Data("</plist>".utf8), options: [], in: startRange.lowerBound..<data.endIndex) else {
            return [:]
        }
        let plistData = data.subdata(in: startRange.lowerBound..<endRange.upperBound)
        guard let plist = try? PropertyListSerialization.propertyList(from: plistData, options: [], format: nil),
              let root = plist as? [String: Any] else { return [:] }

        var result: [String: String] = [:]
        if let name = root["Name"] as? String { result["名称"] = name }
        if let team = root["TeamIdentifier"] as? [String] { result["团队标识"] = team.joined(separator: ", ") }
        if let uuid = root["UUID"] as? String { result["UUID"] = uuid }
        if let exp = root["ExpirationDate"] as? Date {
            result["过期时间"] = DateFormatter.localizedString(from: exp, dateStyle: .medium, timeStyle: .short)
        }
        if let created = root["CreationDate"] as? Date {
            result["创建时间"] = DateFormatter.localizedString(from: created, dateStyle: .medium, timeStyle: .short)
        }
        if let platform = root["Platform"] as? [String] { result["平台"] = platform.joined(separator: ", ") }
        if let provisions = root["ProvisionedDevices"] as? [String] {
            result["设备数量"] = "\(provisions.count)"
        }
        if let entitlements = root["Entitlements"] as? [String: Any] {
            for key in entitlements.keys.sorted() {
                result["Entitlement: \(key)"] = stringify(entitlements[key]!)
            }
        }
        return result
    }

    // MARK: - 工具

    private static func firstString(in dict: [String: Any], keys: [String]) -> String? {
        for key in keys {
            if let array = dict[key] as? [String], let first = array.first { return first }
            if let s = dict[key] as? String { return s }
        }
        return nil
    }

    static func stringify(_ value: Any) -> String {
        switch value {
        case let s as String: return s
        case let b as Bool: return b ? "true" : "false"
        case let n as NSNumber: return n.stringValue
        case let a as [Any]:
            return a.map { stringify($0) }.joined(separator: ", ")
        case let d as [String: Any]:
            return d.keys.sorted().map { "\($0)=\(stringify(d[$0]!))" }.joined(separator: "; ")
        case let d as Date:
            return DateFormatter.localizedString(from: d, dateStyle: .medium, timeStyle: .short)
        default: return String(describing: value)
        }
    }
}
