//
//  IPADiffViewModel.swift
//  iOS Lab — IPA 差异分析状态机
//

import Foundation
import SwiftUI
import UniformTypeIdentifiers

@MainActor
final class IPADiffViewModel: ObservableObject {

    @Published var leftPackage: IPAPackage?
    @Published var rightPackage: IPAPackage?
    @Published var result: DiffResult?
    @Published var isWorking = false
    @Published var progress: Double = 0
    @Published var progressMessage = ""
    @Published var errorMessage: String?
    @Published var shareItem: ShareItem?

    @Published var isPickingLeft = false
    @Published var isPickingRight = false

    @Published var deepContentCheck = true
    @Published var ignoreNoise = true

    /// 最近一次生成的报告文件地址。
    /// shareReport() 用它来弹出分享面板，reset() 会清空。
    private var reportURL: URL?

    var allowedTypes: [UTType] {
        var types: [UTType] = []
        if let ipa = UTType(filenameExtension: "ipa") { types.append(ipa) }
        if let zip = UTType(filenameExtension: "zip") { types.append(zip) }
        types.append(.data)
        return types
    }

    var canCompare: Bool {
        leftPackage != nil && rightPackage != nil && !isWorking
    }

    // MARK: - 载入文件

    func attach(url: URL, isLeft: Bool, model: LabAppModel) {
        let name = url.lastPathComponent
        model.diagnostics.info("IPA 差异", "载入\(isLeft ? "旧" : "新")包：\(name)")

        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }

        // 复制到沙盒，避免离开选择器后失去访问权限
        let local: URL
        do {
            local = try Self.importToSandbox(url: url)
        } catch {
            errorMessage = "无法读取该文件：\(error.localizedDescription)"
            model.diagnostics.error("IPA 差异", "导入失败：\(error.localizedDescription)")
            return
        }

        isWorking = true
        progress = 0
        progressMessage = "正在解析…"
        errorMessage = nil

        Task.detached(priority: .userInitiated) {
            do {
                let package = try IPALoader.load(
                    url: local,
                    computeHashes: true
                ) { pct, msg in
                    Task { @MainActor in
                        self.progress = pct
                        self.progressMessage = msg
                    }
                }
                await MainActor.run {
                    if isLeft { self.leftPackage = package } else { self.rightPackage = package }
                    self.isWorking = false
                    self.progress = 0
                    self.progressMessage = ""
                    model.diagnostics.success(
                        "IPA 差异",
                        "解析完成：\(name)（\(package.fileCount) 个文件，\(package.compressedSizeDisplay)）"
                    )
                }
            } catch {
                await MainActor.run {
                    self.isWorking = false
                    self.errorMessage = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
                    model.diagnostics.error("IPA 差异", "解析失败：\(name) — \(error.localizedDescription)")
                }
            }
        }
    }

    nonisolated private static func importToSandbox(url: URL) throws -> URL {
        let fm = FileManager.default
        let base = fm.urls(for: .cachesDirectory, in: .userDomainMask).first ?? fm.temporaryDirectory
        let dir = base.appendingPathComponent("IPAImports", isDirectory: true)
        try fm.createDirectory(at: dir, withIntermediateDirectories: true)

        let target = dir.appendingPathComponent(UUID().uuidString + "_" + url.lastPathComponent)
        if fm.fileExists(atPath: target.path) {
            try fm.removeItem(at: target)
        }
        try fm.copyItem(at: url, to: target)
        return target
    }

    // MARK: - 比对

    func startComparison(model: LabAppModel) {
        guard let left = leftPackage, let right = rightPackage else { return }

        isWorking = true
        progress = 0
        progressMessage = "准备比对…"
        errorMessage = nil
        result = nil

        let options = DiffOptions(
            deepContentCheck: deepContentCheck,
            ignoreSystemNoise: ignoreNoise
        )

        model.diagnostics.info("IPA 差异", "开始比对：\(left.fileName) ⇄ \(right.fileName)")

        Task.detached(priority: .userInitiated) {
            let diff = IPADiffEngine.compare(left: left, right: right, options: options) { pct, msg in
                Task { @MainActor in
                    self.progress = pct
                    self.progressMessage = msg
                }
            }

            let reportURL = Self.writeReport(
                IPADiffEngine.report(diff, left: left, right: right),
                name: "IPA差异报告"
            )

            await MainActor.run {
                self.result = diff
                self.isWorking = false
                self.progress = 0
                self.progressMessage = ""
                self.reportURL = reportURL
                model.diagnostics.success(
                    "IPA 差异",
                    "比对完成：新增 \(diff.added.count)，删除 \(diff.removed.count)，修改 \(diff.modified.count)，相同 \(diff.identical.count)"
                )
            }
        }
    }

    func shareReport() {
        guard let url = reportURL else { return }
        shareItem = ShareItem(url: url)
    }

    nonisolated private static func writeReport(_ text: String, name: String) -> URL? {
        let fm = FileManager.default
        let base = fm.urls(for: .cachesDirectory, in: .userDomainMask).first ?? fm.temporaryDirectory
        let dir = base.appendingPathComponent("Reports", isDirectory: true)
        try? fm.createDirectory(at: dir, withIntermediateDirectories: true)

        let df = DateFormatter()
        df.dateFormat = "yyyyMMdd_HHmmss"
        let url = dir.appendingPathComponent("\(name)_\(df.string(from: Date())).txt")
        do {
            try text.write(to: url, atomically: true, encoding: .utf8)
            return url
        } catch {
            return nil
        }
    }

    func reset() {
        leftPackage = nil
        rightPackage = nil
        result = nil
        errorMessage = nil
        progress = 0
        progressMessage = ""
        reportURL = nil
    }
}

// MARK: - 分享封装

struct ShareItem: Identifiable {
    let id = UUID()
    let url: URL
}
