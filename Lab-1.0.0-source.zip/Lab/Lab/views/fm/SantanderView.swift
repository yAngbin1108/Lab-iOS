//
//  SantanderView.swift
//  symlin2k
//
//  Created by ruter on 15.02.26.
//

import SwiftUI
import Combine

struct SantanderView: View {
    let startpath: String

    @AppStorage("selectedmethod") private var selectedmethod: method = .hybrid
    @ObservedObject private var mgr = LabMgr.shared
    
    @State private var showsecret: Bool = false

    init(startPath: String = "/") {
        self.startpath = startPath.isEmpty ? "/" : startPath
    }

    private var readsbx: Bool {
        selectedmethod != .vfs
    }

    private var writevfs: Bool {
        selectedmethod != .sbx
    }

    private var ready: Bool {
        switch selectedmethod {
        case .sbx:
            return mgr.sbxready
        case .vfs:
            return mgr.vfsready
        case .hybrid:
            return mgr.sbxready && mgr.vfsready
        }
    }

    var body: some View {
        Group {
            if ready {
                santanderroot(startpath: startpath, readsbx: readsbx, writevfs: writevfs)
            } else {
                // 恢复 lara 官方的提示：文件管理器未就绪，提示先跑漏洞利用，
                // 不区分「没跑 exploit」和「权限没拿到」——因为 lara 的
                // 机制是运行时靠 sbx_escape 逃出沙盒，不依赖安装时的签名权限。
                NavigationStack {
                    VStack(spacing: 12) {
                        Image(systemName: "externaldrive.trianglebadge.exclamationmark")
                            .imageScale(.large)
                        Text("文件管理器未就绪")
                            .font(.headline)
                        Text("请回到「内核」标签页，点击「运行漏洞利用」，"
                             + "成功后再点击「初始化系统」。")
                            .multilineTextAlignment(.center)
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    .padding()
                }
            }
        }
    }
}

private struct santanderroot: View {
    let readsbx: Bool
    let writevfs: Bool

    @StateObject private var nav: santandernav

    init(startpath: String, readsbx: Bool, writevfs: Bool) {
        self.readsbx = readsbx
        self.writevfs = writevfs
        _nav = StateObject(wrappedValue: santandernav(root: santanderitem(path: startpath, isdir: true)))
    }

    var body: some View {
        NavigationStack(path: $nav.stack) {
            santanderdirview(item: nav.root, readsbx: readsbx, writevfs: writevfs)
                .environmentObject(nav)
                .navigationDestination(for: santanderitem.self) { item in
                    if item.isdir {
                        santanderdirview(item: item, readsbx: readsbx, writevfs: writevfs)
                            .environmentObject(nav)
                    } else {
                        santanderfileview(item: item, readsbx: readsbx, writevfs: writevfs)
                    }
                }
        }
    }
}

final class santandernav: ObservableObject {
    @Published var root: santanderitem
    @Published var stack: [santanderitem] = []

    init(root: santanderitem) {
        self.root = root
    }

    func go(_ item: santanderitem) {
        root = item
        stack.removeAll()
    }
}

extension UIViewController {
    func topMostViewController() -> UIViewController {
        if let presented = presentedViewController {
            return presented.topMostViewController()
        }
        return self
    }
}
