//
//  SantanderView.swift
//  symlin2k
//
//  Created by ruter on 15.02.26.
//

import SwiftUI
import Combine

struct SantanderView: View {
    let startpath: String

    @AppStorage("selectedmethod") private var selectedmethod: method = .hybrid
    @ObservedObject private var mgr = LabMgr.shared
    
    @State private var showsecret: Bool = false

    /// 安装方式：决定「未就绪」是真没跑漏洞利用，还是权限根本没拿到。
    /// 这两种情况用户该做的事完全不同，所以提示语必须区分。
    @State private var installation: InstallationReport = InstallationReport(kind: .sandboxed, checks: [])
    @State private var didProbe = false

    init(startPath: String = "/") {
        self.startpath = startPath.isEmpty ? "/" : startPath
    }

    private var readsbx: Bool {
        selectedmethod != .vfs
    }

    private var writevfs: Bool {
        selectedmethod != .sbx
    }

    private var ready: Bool {
        switch selectedmethod {
        case .sbx:
            return mgr.sbxready
        case .vfs:
            return mgr.vfsready
        case .hybrid:
            return mgr.sbxready && mgr.vfsready
        }
    }

    var body: some View {
        Group {
            if ready {
                santanderroot(startpath: startpath, readsbx: readsbx, writevfs: writevfs)
            } else {
                NavigationStack {
                    VStack(spacing: 12) {
                        Image(systemName: "externaldrive.trianglebadge.exclamationmark")
                            .imageScale(.large)

                        if installation.kind.kernelFeaturesAvailable {
                            Text("文件管理器未就绪")
                                .font(.headline)
                            Text("请回到「内核」标签页，点击「运行漏洞利用」，"
                                 + "成功后再点击「初始化系统」。")
                                .multilineTextAlignment(.center)
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        } else {
                            // 这是权限被剥离的情况 —— 光靠重跑漏洞利用解决不了，
                            // 必须换安装方式。所以不能沿用上面那句提示。
                            Text("文件管理器不可用")
                                .font(.headline)
                            Text("当前安装方式（\(installation.kind.displayName)）"
                                 + "没有沙盒外路径的访问权限，"
                                 + "重跑漏洞利用也无法解决。")
                                .multilineTextAlignment(.center)
                                .font(.subheadline)
                                .foregroundStyle(.secondary)

                            Text("请改用 TrollStore 或其它保留伪签名的安装方式。")
                                .multilineTextAlignment(.center)
                                .font(.caption)
                                .foregroundStyle(.tertiary)
                        }
                    }
                    .padding()
                }
            }
        }
        .onAppear {
            guard !didProbe else { return }
            didProbe = true
            installation = InstallationCapability.detect()
        }
    }
}

private struct santanderroot: View {
    let readsbx: Bool
    let writevfs: Bool

    @StateObject private var nav: santandernav

    init(startpath: String, readsbx: Bool, writevfs: Bool) {
        self.readsbx = readsbx
        self.writevfs = writevfs
        _nav = StateObject(wrappedValue: santandernav(root: santanderitem(path: startpath, isdir: true)))
    }

    var body: some View {
        NavigationStack(path: $nav.stack) {
            santanderdirview(item: nav.root, readsbx: readsbx, writevfs: writevfs)
                .environmentObject(nav)
                .navigationDestination(for: santanderitem.self) { item in
                    if item.isdir {
                        santanderdirview(item: item, readsbx: readsbx, writevfs: writevfs)
                            .environmentObject(nav)
                    } else {
                        santanderfileview(item: item, readsbx: readsbx, writevfs: writevfs)
                    }
                }
        }
    }
}

final class santandernav: ObservableObject {
    @Published var root: santanderitem
    @Published var stack: [santanderitem] = []

    init(root: santanderitem) {
        self.root = root
    }

    func go(_ item: santanderitem) {
        root = item
        stack.removeAll()
    }
}

extension UIViewController {
    func topMostViewController() -> UIViewController {
        if let presented = presentedViewController {
            return presented.topMostViewController()
        }
        return self
    }
}
