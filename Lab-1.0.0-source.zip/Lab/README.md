<div align="center">

# Lab

**iOS 内核工具箱 + IPA 分析工具**

基于 [lara](https://github.com/rooootdev/lara) 二次开发

</div>

---

## ⚠️ 先读这一节

**这是一个越狱工具，不是普通 App。**

它包含 DarkSword 内核漏洞利用代码，可以读写内核内存、访问沙盒外文件系统、修改系统行为。这意味着：

- 漏洞利用**有失败概率**，失败通常无害，重试即可
- 界面上有「触发 panic」按钮，点了手机会**立即重启**
- 内核内存写入操作如果越界，最坏情况是设备需要恢复模式重刷
- 不保证在任何固件更新后仍然可用

**请自行评估风险。** 如果这台设备对你有不可替代的数据，先备份。

---

## 支持范围

| 项目 | 状态 |
|---|---|
| iOS 版本 | 16.0 – 18.7.1，以及 26.0.x |
| 例外 | 不支持 M5 与 A19 及更新芯片（含 MIE 保护） |
| 已测试 | iPhone XS Max (A12) @ iOS 16.7.2 |
| 目标设备 | iPhone 15 @ iOS 17.5.1 |

不在支持列表内的设备启动时会看到提示，但**分析类功能仍然可用**。

---

## 安装方式（重要）

### 内核功能只能用 TrollStore 类安装器

Lab 依赖一整套私有 entitlements 才能工作：

```xml
platform-application                    <!-- 平台级权限 -->
com.apple.private.security.no-sandbox   <!-- 脱离沙盒 -->
com.apple.developer.kernel.extended-virtual-addressing
com.apple.security.exception.iokit-user-client-class
```

这些**不在 Apple 开发者门户的 capabilities 列表里**。无论免费还是付费开发者账号，
都无法生成包含它们的描述文件 —— 用开发者证书签出来的包，这几条会被系统剥离。

构建流程用 `ldid` 做伪签名注入，只有绕过签名校验的安装器能保留它们：

| 安装方式 | 内核功能 | 分析功能 |
|---|---|---|
| **TrollStore** | ✅ 可用 | ✅ 可用 |
| 开发者证书自签（AltStore / Sideloadly / ESign 等） | ❌ 不可用 | ✅ 可用 |

### 应用会自己检测并降级

Lab 在启动时探测一次实际拿到的权限（只读探测，不写任何系统文件）。
拿不到就**隐藏内核界面并说明原因**，而不是让你对着「运行失败」的日志猜。

检测结果显示在「内核」标签页顶部的「环境」一栏，逐项列出每项权限的状态。

**用开发者证书安装时看到的现象是**：应用正常启动，分析功能全部可用，
内核标签页显示「系统权限受限，内核功能已隐藏」并给出具体原因。

---

## 功能

### 内核（源自 lara）

| 功能 | 说明 |
|---|---|
| 运行漏洞利用 | 建立内核读写通道 |
| 获取内核缓存 | 从系统提取内核缓存并解析偏移 |
| 初始化 RemoteCall | 在目标进程中执行代码（不稳定，需 PAC 上下文） |
| 注销设备 | 软重启 SpringBoard |
| 触发 panic | 强制内核崩溃 → 设备重启 |

### 文件管理器

可浏览沙盒外路径（`/System`、`/var` 等），查看文件信息、读写、删除。

### 分析工具（本分支新增）

| 模块 | 说明 |
|---|---|
| IPA 差异分析 | 比较两个 IPA 的增删改，CRC32 二级比对 + SHA-256 确认，输出报告 |
| IPA 本地化管理 | 读取 `.strings` / `.stringsdict`，导出对照表 |
| 应用行为分析 | 解析 Info.plist、权限声明、Entitlements、动态库清单 |
| 运行监控 | 解析 `.ips` / `.crash` 日志，归类异常原因 |
| 系统能力检测 | 设备信息 + 内核实际状态 |

分析模块**不依赖内核漏洞利用**，漏洞利用失败也能正常使用。

---

## 编译

### GitHub Actions

推到 GitHub 后 Actions 自动构建，产物在 Artifacts：`Lab-ipa`。

手动触发：Actions → Build Lab IPA → Run workflow。两个选项：

| 选项 | 说明 |
|---|---|
| `configuration` | Release（默认）或 Debug |
| `ldid_sign` | **默认 true**。用 ldid 注入私有 entitlements，产出可直接用 TrollStore 安装 |

把 `ldid_sign` 设成 false 会产出纯净未签名包 —— 应用能装能跑，但内核界面会自动隐藏。

流水线分两步：

1. **validate**（ubuntu，几秒）—— 结构自检、桥接头一致性、workflow 一致性
2. **build**（macos-15）—— `xcodebuild archive` → `ldid` 注入 entitlements → 打包 IPA

### 本地编译

```bash
./scripts/build_ipa.sh              # Release + ldid 伪签名
./scripts/build_ipa.sh --debug      # Debug 构建
./scripts/build_ipa.sh --no-ldid    # 不注入私有 entitlements
```

需要 `brew install ldid`。产物在 `build/Lab.ipa`。

### 环境要求

| 项目 | 要求 |
|---|---|
| Xcode | 16.0+（工程 `objectVersion = 77`） |
| 最低部署版本 | iOS 16.0 |
| 构建架构 | arm64e |

---

## 工程结构

```
Lab/
├── Lab.xcodeproj/            工程（文件系统同步组，新增文件无需改 pbxproj）
├── Lab/
│   ├── Lab.swift             入口，标签页装配
│   ├── Lab-Bridging-Header.h Swift ↔ ObjC 桥接
│   ├── Info.plist
│   ├── kexploit/             内核漏洞利用
│   │   ├── darksword.m       主漏洞利用
│   │   ├── offsets.m         内核偏移解析
│   │   ├── TaskRop/          RemoteCall 与线程/VM 原语
│   │   └── pe/               后利用阶段（apfs / vnode / vfs / sbx / rc）
│   ├── classes/
│   │   ├── LabMgr.swift      内核状态与操作入口
│   │   ├── IPAArchive.swift  纯 Swift ZIP 读取器
│   │   └── Logger.swift
│   ├── views/                内核侧界面
│   ├── PartyUI/              设计系统
│   └── Analyzer/             ★ 分析模块（本分支新增）
│       ├── Core/             能力检测、设备信息、诊断日志
│       ├── Modules/          五大分析模块
│       └── Shared/           主题与组件
├── Config/Lab.entitlements   伪签名用的 entitlements
├── Checks/                    CI 自检脚本
└── .github/workflows/
```

---

## 与上游 lara 的差异

本分支只保留**录屏中出现过的功能**，其余 tweak 全部移除：

**已移除**：字体替换、表情符号、IPA 解密、OTA 延迟、屏幕使用时间、
DarkBoard 图标主题、锁屏密码主题、LiquidGlass、dirtyZero、
SpringBoard 自定义、MobileGestalt 修改、var 清理、白名单、JIT、各类图库。

**已新增**：五个 IPA 分析模块、系统能力检测、纯 Swift ZIP 解析器、
结构性 CI 自检。

**已修复**（上游存在的构建问题）：

- `CURRENT_PROJECT_VERSION` 被写成 `Release`（应为数字）
- 项目级 `IPHONEOS_DEPLOYMENT_TARGET = 26.0`（未来版本，会直接构建失败）
- 缺失共享 scheme，CI 里 `xcodebuild -scheme` 会失败

---

## 许可证与致谢

本项目基于 [lara](https://github.com/rooootdev/lara) 二次开发，原项目以 **AGPL-3.0** 授权。
按许可证要求，本项目同样以 AGPL-3.0 分发，**原作者署名与 LICENSE 文件必须保留**。

### 原始项目贡献者

- **rooootdev** — lara 原作者
- **ruter** — lara 主程序
- **neon** — respring 脚本、zipmgr、锁屏密码主题修复、应用解密
- 以及 lara 仓库 README 中列出的全部贡献者

### 底层依赖

| 组件 | 用途 | 许可证 |
|---|---|---|
| [ChOma](https://github.com/alfiecg24/ChOma) | Mach-O / 代码签名解析 | MIT |
| [libgrabkernel2](https://github.com/wh1te4ever/libgrabkernel2) | 内核缓存抓取 | 见 `Lab/licenses/` |
| [XPF](https://github.com/0xH1v3/XPF) | 内核补丁框架 | 见 `Lab/licenses/` |
| DarkSword | 内核漏洞利用 | — |

完整许可证文本见 `Lab/licenses/`。

### 分发要求

如果你分发本项目的修改版本或编译产物，**必须**：

1. 保留本 README 的致谢章节与上游链接
2. 保留 `LICENSE` 文件
3. 以 AGPL-3.0 授权你的修改
4. 提供完整的对应源码

---

## 免责声明

本工具仅供**在你自己的设备上**研究与学习使用。

内核漏洞利用会直接影响系统稳定性，任何数据丢失或设备损坏由使用者自行承担。
本项目不提供任何明示或暗示的担保。

请遵守你所在地区的法律法规。
